"""Static/source and mathematical bevel geometry checks (not Godot engine tests)."""
from pathlib import Path
import math
import unittest

ROOT = Path(__file__).resolve().parents[1]
ROOM = (ROOT / "scripts/room_builder.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")

class BevelVisualContract(unittest.TestCase):
    def test_bevels_are_selective_and_apply_to_all_three_rooms(self):
        for word in ('"BedFrame"', '"Headboard"', '"OldDesk"',
                     '"FuseCabinet"', '"SealPedestal"', '"SchoolDesk"'):
            self.assertIn(word, ROOM)
        self.assertIn('label.begins_with("Locker_")', ROOM)
        self.assertIn('if _use_bevel_visual(label):', ROOM)
        self.assertIn('mesh.mesh = _beveled_box_mesh(size)', ROOM)
        self.assertIn('var box := BoxMesh.new()', ROOM)  # cheap shell/trim path retained

    def test_collision_is_independent_from_bevel_mesh(self):
        cuboid = ROOM.split("static func cuboid(", 1)[1].split("static func rounded_detail", 1)[0]
        self.assertIn('shape.size = size', cuboid)
        self.assertIn('root.set_meta("action", action)', cuboid)
        self.assertIn('mesh.material_override = _pbr_material(label, tint)', cuboid)
        self.assertIn('root.add_child(hit)', cuboid)
        self.assertNotIn('hit.shape = mesh.mesh', cuboid)

    def test_bevel_mesh_has_cache_outward_normals_and_indices(self):
        generator = ROOM.split('static func _beveled_box_mesh(', 1)[1].split('static func _use_bevel_visual', 1)[0]
        for expected in ('_bevel_mesh_cache.has(cache_key)',
                         '_bevel_mesh_cache[cache_key] = result',
                         'var outward := (box_point - core).normalized()',
                         'vertices.append(core + outward * bevel)',
                         'Mesh.ARRAY_VERTEX', 'Mesh.ARRAY_NORMAL', 'Mesh.ARRAY_TEX_UV',
                         'Mesh.ARRAY_INDEX', 'Mesh.PRIMITIVE_TRIANGLES'):
            self.assertIn(expected, generator)

    def test_math_reference_normals_are_finite_and_within_collision_box(self):
        # Independent Python reference of the rounding projection. This only
        # checks the mathematics, not whether Godot parses/uses the code.
        half = (1.3, .36, 2.0)
        bevel = min(.075, min(half)*.44)
        for direction in ((1, 0, 0),(-1, 0, 0),(0, 1, 0),(0, -1, 0),(0,0,1),(0,0,-1)):
            for u in (-1,0,1):
                for v in (-1,0,1):
                    # Reproduce endpoints on the appropriate face.
                    axes = [axis for axis, value in enumerate(direction) if value == 0]
                    p = [0.0,0.0,0.0]
                    fixed = next(axis for axis,value in enumerate(direction) if value)
                    p[fixed] = direction[fixed]*half[fixed]
                    p[axes[0]] = u*half[axes[0]]
                    p[axes[1]] = v*half[axes[1]]
                    core = [min(max(p[i], -half[i] + bevel), half[i] - bevel) for i in range(3)]
                    diff = [p[i] - core[i] for i in range(3)]
                    length = math.sqrt(sum(d*d for d in diff))
                    self.assertGreater(length, 0)
                    normal = [d/length for d in diff]
                    rounded = [core[i] + bevel*normal[i] for i in range(3)]
                    self.assertAlmostEqual(sum(n*n for n in normal), 1, places=6)
                    for i in range(3):
                        self.assertTrue(math.isfinite(rounded[i]))
                        self.assertLessEqual(abs(rounded[i]), half[i]+1e-8)

    def test_runtime_smoke_will_check_mesh_and_original_collision(self):
        for phrase in ('bevel hero retains its original collision shape',
                       'bevel hero uses an ArrayMesh visual',
                       'bevel geometry is indexed and bounded',
                       'identical lockers share one cached bevel mesh'):
            self.assertIn(phrase, SMOKE)

if __name__ == '__main__':
    unittest.main()
