"""Static source checks for the new checkpoint flow. Not a Godot runtime test."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'scripts/main.gd').read_text(encoding='utf-8')
CODEC = (ROOT / 'scripts/save_codec.gd').read_text(encoding='utf-8')
SMOKE = (ROOT / 'tests/godot_flow_smoke.gd').read_text(encoding='utf-8')


class CheckpointContract(unittest.TestCase):
    def test_schema_and_required_keys(self):
        self.assertIn('const SCHEMA_VERSION := 1', CODEC)
        required = ['schema', 'layer', 'language', 'slot', 'elapsed', 'remaining',
                    'stability', 'collapse_count', 'run_started', 'game_complete',
                    'fuses', 'seal', 'power_on', 'locker_open', 'archive_found',
                    'seal_open', 'quality']
        for key in required:
            self.assertIn('"' + key + '"', CODEC)

    def test_json_numbers_can_be_float_but_must_be_integral(self):
        self.assertIn('TYPE_INT and typeof(value) != TYPE_FLOAT', CODEC)
        self.assertIn('floorf(number) == number', CODEC)
        self.assertIn('number >= minimum and number <= maximum', CODEC)

    def test_reject_invalid_progress(self):
        for token in ['raw["layer"] == "school" and not raw["power_on"]',
                      'raw["locker_open"] and not raw["power_on"]',
                      'raw["archive_found"] and not raw["locker_open"]',
                      'raw["game_complete"] and']:
            self.assertIn(token, CODEC)

    def test_save_uses_temp_and_backup_with_rollback(self):
        for token in ['TEMP_FILE', 'BACKUP_FILE', 'DirAccess.rename_absolute',
                      'DirAccess.remove_absolute', 'file.flush()',
                      'DirAccess.rename_absolute(rollback, target)']:
            self.assertIn(token, MAIN)

    def test_load_is_validated_before_mutating_game(self):
        block = MAIN.split('func _load_game() -> void:', 1)[1].split('func _apply_quality()', 1)[0]
        self.assertLess(block.index('_read_recovery_checkpoint(SAVE_FILE, SAVE_FILE + ".rollback", BACKUP_FILE)'),
                        block.index('transition_token += 1'))
        self.assertIn('if state.is_empty():', block)
        self.assertIn('overlay.dismiss()', block)
        self.assertIn('_move_to(str(state["layer"]))', block)

    def test_save_blocked_during_dialog_or_transition(self):
        block = MAIN.split('func _save_game() -> void:', 1)[1].split('func _read_checkpoint(', 1)[0]
        self.assertIn('if transitioning or overlay.is_dialog_open:', block)

    def test_save_file_size_is_bounded(self):
        self.assertIn('const MAX_SAVE_BYTES := 16384', MAIN)
        self.assertIn('if file.get_length() > MAX_SAVE_BYTES:', MAIN)

    def test_engine_smoke_contains_codec_negative_cases(self):
        self.assertIn('DreamSaveCodec.validated(JSON.parse_string(JSON.stringify(snapshot)))', SMOKE)
        self.assertIn('"reject impossible progress"', SMOKE)
        self.assertIn('"reject out-of-range fuse"', SMOKE)
        self.assertIn('"reject negative elapsed"', SMOKE)


if __name__ == '__main__':
    unittest.main()
