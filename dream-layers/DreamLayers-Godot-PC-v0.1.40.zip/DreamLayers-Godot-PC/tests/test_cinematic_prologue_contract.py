"""Static prologue mission and cinematic-safety checks; NOT a Godot render test."""
import re
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'scripts/main.gd').read_text()
ROOM = (ROOT / 'scripts/room_builder.gd').read_text()
SMOKE = (ROOT / 'tests/godot_flow_smoke.gd').read_text()


def func(name):
    m = re.search(rf'(?m)^func {re.escape(name)}\([^\n]*\).*?:\n', MAIN)
    if not m:
        raise AssertionError(f'Missing {name}')
    rest = MAIN[m.end():]
    after = re.search(r'(?m)^func ', rest)
    return MAIN[m.start():m.end() + after.start() if after else len(MAIN)]


class CinematicPrologueContract(unittest.TestCase):
    def test_clock_is_collision_aware_interactive_but_details_are_decorative(self):
        self.assertIn('"prologue_clock": "reality"', MAIN)
        self.assertIn('"PrologueClock"', ROOM)
        self.assertIn('true, "prologue_clock", 2.3', ROOM)
        self.assertIn('"ClockFace"', ROOM)
        self.assertIn('"ClockHand"', ROOM)
        self.assertIn('Color("d5c4a4"), true)', ROOM)
        self.assertIn('Color("473d38"), false)', ROOM)

    def test_intro_start_is_first_person_objective_not_unskippable_cutscene(self):
        intro = func('_intro')
        self.assertIn('"intro_start"', intro)
        self.assertIn('WASD:', intro)
        choice = func('_choice')
        self.assertIn('prologue_step = 1', choice)
        self.assertIn('"prologue_clock":\n            _inspect_prologue_clock()', func('_interact'))
        self.assertIn('return action == "bed" or run_started', func('_can_interact'))

    def test_clock_only_runs_after_intro_in_correct_focus_and_room(self):
        gate = func('_can_interact')
        self.assertIn('not app_has_focus', gate)
        self.assertIn('ACTION_LAYERS[action] != current_layer', gate)
        self.assertIn('overlay.is_dialog_open', gate)
        self.assertIn('return prologue_step == 1 and not run_started', gate)
        inspect = func('_inspect_prologue_clock')
        self.assertLess(inspect.index('if not _can_interact("prologue_clock")'), inspect.index('prologue_step = 2'))
        self.assertIn('"prologue_clock")', inspect)
        self.assertIn('if was_prologue_clock:', func('_choice'))

    def test_cinematic_tween_pauses_on_focus_loss_and_does_not_move_player(self):
        effect = func('_tick_prologue_shift')
        self.assertIn('if not app_has_focus', effect)
        self.assertIn('current_layer != "reality"', effect)
        self.assertIn('prologue_shift_remaining = maxf(', effect)
        for part in ['"WindowMullion"', '"ClockHand"', '"LampShade"']:
            self.assertIn(part, effect)
        for forbidden in ('player.position', 'player.rotation', 'player.velocity', 'gravity', 'stability =',
                          'remaining_seconds =', 'Input.mouse_mode', 'collision_layer'):
            self.assertNotIn(forbidden, effect)
        self.assertIn('_tick_prologue_shift(focused_delta)', func('_process'))

    def test_prologue_uses_same_safe_modal_and_does_not_change_save_schema(self):
        inspect = func('_inspect_prologue_clock')
        self.assertIn('"id":"close"', inspect)
        self.assertIn('"prologue_clock")', inspect)
        self.assertNotIn('prologue_step', (ROOT / 'scripts/save_codec.gd').read_text())
        self.assertNotIn('prologue_clock', (ROOT / 'scripts/save_codec.gd').read_text())
        for marker in ['cinematic prologue objective starts', 'clock interaction requires correct lifecycle',
                       'prologue shift freezes while unfocused', 'prologue keeps bed dive available']:
            self.assertIn(marker, SMOKE)

    def test_movie_and_game_references_are_production_principles_not_assets(self):
        brief = (ROOT/'docs/PROLOGUE-CINEMATIC-DESIGN-TR.md').read_text()
        for needle in ['GTA V', 'Inception', 'görev', 'kamera', 'ses', 'özgün']:
            self.assertIn(needle, brief)
        self.assertIn('Kaynak kodları, ses kayıtları ve sahneleri kopyalanmadı', brief)


if __name__ == '__main__':
    unittest.main()
