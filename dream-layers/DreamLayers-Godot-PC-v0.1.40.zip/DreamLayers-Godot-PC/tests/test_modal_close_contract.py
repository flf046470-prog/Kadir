"""Static controller-side modal close guards; NOT Godot runtime execution."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
OVERLAY = (ROOT / "scripts/overlay.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class ModalCloseContract(unittest.TestCase):
    def test_main_rejects_close_when_not_offered(self):
        choice = MAIN.split("func _choice(id: String) -> void:", 1)[1].split("    match id:", 1)[0]
        self.assertIn('if id == "close" and not overlay.dialog_can_cancel:', choice)
        self.assertIn('return', choice.split('if id == "close" and not overlay.dialog_can_cancel:', 1)[1].split("# A callback", 1)[0])

    def test_guard_runs_before_close_dispatch(self):
        choice = MAIN.split("func _choice(id: String) -> void:", 1)[1]
        self.assertLess(choice.index('if id == "close" and not overlay.dialog_can_cancel:'),
                        choice.index('        "close":'))

    def test_overlay_cancel_flag_tracks_explicit_close_and_dismiss(self):
        self.assertIn('if str(choice.get("id", "")) == "close":', OVERLAY)
        self.assertIn('dialog_can_cancel = false', OVERLAY.split("func dismiss() -> void:", 1)[1])

    def test_engine_smoke_covers_both_mandatory_confirmations(self):
        self.assertIn('"direct close cannot bypass prologue confirmation"', SMOKE)
        self.assertIn('"direct close cannot bypass ending confirmation"', SMOKE)


if __name__ == "__main__":
    unittest.main()
