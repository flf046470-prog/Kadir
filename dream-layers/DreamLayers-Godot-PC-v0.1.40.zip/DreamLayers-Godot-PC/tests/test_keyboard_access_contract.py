"""Static keyboard-accessibility contracts; not a Godot engine test."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
OVERLAY = (ROOT / "scripts/overlay.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class KeyboardAccessContract(unittest.TestCase):
    def test_first_dialog_button_gets_focus_after_modal_is_visible(self):
        block = OVERLAY.split("func dialog(", 1)[1].split("func dialog_code(", 1)[0]
        self.assertIn("var first_button: Button = null", block)
        self.assertLess(block.index("modal_shade.show()"), block.index("first_button.grab_focus()"))

    def test_locker_input_overrides_generic_button_focus(self):
        block = OVERLAY.split("func dialog_code(", 1)[1].split("func _submit_locker_from_keyboard(", 1)[0]
        self.assertLess(block.index("dialog(title, body,"), block.index("modal_code.grab_focus()"))
        self.assertIn("modal_code.show()", block)

    def test_enter_submission_uses_existing_guarded_path(self):
        self.assertIn("modal_code.text_submitted.connect(_submit_locker_from_keyboard)", OVERLAY)
        block = OVERLAY.split("func _submit_locker_from_keyboard(", 1)[1].split("func _choose(", 1)[0]
        self.assertIn("if is_dialog_open and modal_code.visible:", block)
        self.assertIn('_choose("locker_submit", dialog_generation)', block)
        self.assertNotIn("modal_callback.call(", block)

    def test_motor_smoke_covers_focus_and_enter(self):
        for expected in [
            '"prologue first button keyboard focus"',
            '"locker text entry keyboard focus"',
            'game.overlay.modal_code.text_submitted.emit("4812")',
            '"locker solved by Enter"',
            '"stale Enter cannot reward twice"',
        ]:
            self.assertIn(expected, SMOKE)


if __name__ == "__main__":
    unittest.main()
