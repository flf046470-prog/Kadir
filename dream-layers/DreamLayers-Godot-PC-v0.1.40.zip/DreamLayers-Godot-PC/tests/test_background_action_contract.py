"""Source-only background action gate contracts; Godot runtime is not executed."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


def body(name: str) -> str:
    start = re.search(rf"(?m)^func {re.escape(name)}\([^\n]*\).*?:\n", MAIN)
    if start is None:
        raise AssertionError(f"Missing {name}")
    next_fn = re.search(r"(?m)^func ", MAIN[start.end():])
    return MAIN[start.start():start.end() + next_fn.start() if next_fn else len(MAIN)]


class BackgroundActionContract(unittest.TestCase):
    def test_direct_interactions_reject_background_focus(self):
        source = body("_can_interact")
        self.assertIn("if not app_has_focus or game_complete", source)
        self.assertLess(source.index("not app_has_focus"), source.index("ACTION_LAYERS.has"))

    def test_modal_callbacks_reject_background_focus(self):
        source = body("_choice")
        self.assertIn("if not app_has_focus or not overlay.is_dialog_open:", source)
        self.assertLess(source.index("not app_has_focus"), source.index("match id:"))

    def test_successful_load_does_not_unfreeze_background_player(self):
        source = body("_load_game")
        self.assertIn("player.can_move = app_has_focus and not game_complete", source)
        self.assertLess(source.index("_move_to(str(state"), source.index("player.can_move = app_has_focus"))

    def test_engine_smoke_includes_direct_background_call_cases(self):
        for label in (
            "background direct prologue callback ignored",
            "background direct bed interaction ignored",
            "background direct puzzle callback ignored",
        ):
            self.assertIn(label, SMOKE)


if __name__ == "__main__":
    unittest.main()
