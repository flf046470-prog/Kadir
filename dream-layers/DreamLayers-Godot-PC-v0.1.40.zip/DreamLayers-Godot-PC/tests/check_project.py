"""Static smoke checks, deliberately NOT a Godot/Windows runtime test."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
required = [
    'project.godot', 'Main.tscn', 'scripts/main.gd', 'scripts/player.gd',
    'scripts/overlay.gd', 'scripts/room_builder.gd', 'README-TR.md',
    'docs/ROADMAP-TR.md', 'docs/TEST-REPORT-TR.md',
]
for part in required:
    assert (root / part).is_file(), f'Missing: {part}'

scene = (root/'Main.tscn').read_text()
assert 'res://scripts/main.gd' in scene
project = (root/'project.godot').read_text()
assert 'res://Main.tscn' in project
scripts = {f.stem: f.read_text() for f in (root/'scripts').glob('*.gd')}
assert len(scripts) == 5
assert 'save_codec' in scripts
assert 'Godot' not in scripts['main'][:50]  # project does not import UE
assert 'const EPOCH_SECONDS := 90.0' in scripts['main']
assert 'const FOLD_SECONDS := 180.0' in scripts['main']
assert 'const DIVE_SECONDS := 12.0' in scripts['main']
assert 'dive_remaining_seconds = DIVE_SECONDS' in scripts['main']
for puzzle in ('fuses','locker','archive','seal','wake_bell'):
    assert '"'+puzzle+'"' in scripts['main']
for room in ('build_reality','build_house','build_school'):
    assert 'func '+room in scripts['room_builder']
for action in ('KEY_W','KEY_A','KEY_S','KEY_D','KEY_SHIFT'):
    assert action in scripts['player']
assert 'Input.mouse_mode = Input.MOUSE_MODE_CAPTURED' in scripts['overlay']
for file, source in scripts.items():
    assert source.count('(') == source.count(')'), f'Unbalanced parentheses: {file}'
    assert source.count('[') == source.count(']'), f'Unbalanced brackets: {file}'
    assert source.count('{') == source.count('}'), f'Unbalanced braces: {file}'
print('PASS: 9 files, scene and source contract (STATIC ONLY; Godot not executed)')
