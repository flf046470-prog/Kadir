"""Static source guards for gameplay action authorization (not a Godot runtime test)."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")


def function_source(name: str) -> str:
    match = re.search(rf"(?m)^func {re.escape(name)}\([^\n]*\).*?:\n", SOURCE)
    if not match:
        raise AssertionError(f"Missing function {name}")
    next_function = re.search(r"(?m)^func ", SOURCE[match.end():])
    return SOURCE[match.start():match.end() + next_function.start() if next_function else len(SOURCE)]


class ActionGateContract(unittest.TestCase):
    def test_every_interactive_action_is_assigned_to_one_room(self):
        block = SOURCE.split("const ACTION_LAYERS := {", 1)[1].split("}", 1)[0]
        pairs = re.findall(r'"([a-z_]+)": "([a-z]+)"', block)
        self.assertEqual(len(pairs), 11)
        self.assertEqual(dict(pairs), {
            "bed": "reality", "prologue_clock": "reality", "house_note": "house", "fuses": "house",
            "school_door": "house", "wake_bell": "house", "phase_echo": "house", "locker": "school",
            "archive": "school", "seal": "school", "return_house": "school",
        })

    def test_action_gate_rejects_invalid_lifecycle_and_modal(self):
        gate = function_source("_can_interact")
        for condition in ("game_complete", "transitioning", "overlay.is_dialog_open"):
            self.assertIn(condition, gate)
        self.assertIn("not ACTION_LAYERS.has(action)", gate)
        self.assertIn("ACTION_LAYERS[action] != current_layer", gate)
        self.assertIn('action == "bed" or run_started', gate)

    def test_interact_checks_gate_before_dispatch(self):
        action = function_source("_interact")
        self.assertLess(action.index("if not _can_interact(action):"), action.index("match action:"))
        self.assertIn("        return", action)

    def test_keyboard_interaction_rejects_game_completion(self):
        self.assertIn("if event.keycode == KEY_E and not transitioning and not game_complete:", SOURCE)

    def test_stale_dialogue_callbacks_have_layer_guards(self):
        choice = function_source("_choice")
        self.assertLess(choice.index("if not app_has_focus or not overlay.is_dialog_open:"), choice.index("match id:"))
        self.assertIn('current_layer != "house" or not run_started or power_on or game_complete', choice)
        self.assertIn('current_layer != "school" or not run_started or not archive_found or seal_open or game_complete', choice)
        self.assertIn('current_layer != "school" or not run_started or not power_on or locker_open or game_complete', choice)

    def test_out_of_range_fuse_and_seal_buttons_rejected(self):
        choice = function_source("_choice")
        self.assertEqual(choice.count('if not index_text.is_valid_int():'), 2)
        self.assertIn("if idx < 0 or idx >= fuse_values.size():", choice)
        self.assertIn("if idx < 0 or idx >= seal_values.size():", choice)

    def test_core_puzzle_and_run_flow_preserved(self):
        for token in ('fuse_values == [3, 1, 4]', 'entered_code == "4812"',
                      'seal_values == [0, 1, 2, 3]', 'const DIVE_SECONDS := 12.0',
                      'const EPOCH_SECONDS := 90.0', 'func _fold()'):
            self.assertIn(token, SOURCE)


if __name__ == "__main__":
    unittest.main()
