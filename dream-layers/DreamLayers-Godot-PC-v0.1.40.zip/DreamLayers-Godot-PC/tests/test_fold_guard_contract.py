"""Static fold-entry contract. Real Godot behavior needs engine smoke."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
FOLD = MAIN.split("func _fold() -> void:", 1)[1].split("func _wake() -> void:", 1)[0]
PROCESS = MAIN.split("func _process(delta: float) -> void:", 1)[1].split("func _unhandled_input(", 1)[0]


class FoldGuardContract(unittest.TestCase):
    def test_fold_requires_active_focused_nonmodal_play(self):
        self.assertIn(
            "if not run_started or not app_has_focus or transitioning or game_complete or overlay.is_dialog_open:\n        return",
            FOLD,
        )

    def test_fold_requires_exhaustion(self):
        self.assertIn("if remaining_seconds > 0.0 and stability > 0:\n        return", FOLD)
        self.assertIn("if remaining_seconds <= 0.0 or stability <= 0:\n            _fold()", PROCESS)

    def test_guards_precede_any_mutation(self):
        self.assertLess(FOLD.index("not run_started"), FOLD.index("collapse_count += 1"))
        self.assertLess(FOLD.index("remaining_seconds > 0.0"), FOLD.index("stability = 35"))
        self.assertLess(FOLD.index("remaining_seconds > 0.0"), FOLD.index('_move_to("house")'))

    def test_engine_smoke_covers_denials_and_valid_collapse(self):
        for marker in (
            "direct fold cannot bypass prologue",
            "healthy focused dream cannot be folded directly",
            "background direct fold rejected even at zero stability",
            "open modal blocks direct fold at zero stability",
            "exhausted focused dream folds and grants three-minute recovery",
            "completed game cannot fold from direct callback",
        ):
            self.assertIn(marker, SMOKE)


if __name__ == "__main__":
    unittest.main()
