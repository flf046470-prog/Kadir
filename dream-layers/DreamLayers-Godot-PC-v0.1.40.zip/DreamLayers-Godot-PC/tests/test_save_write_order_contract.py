"""Source-only regression: invalid serialized saves must not open WRITE mode."""
from pathlib import Path
import unittest

MAIN = (Path(__file__).resolve().parents[1] / "scripts/main.gd").read_text(encoding="utf-8")
SAVE = MAIN.split("func _save_game() -> void:", 1)[1].split("func _promote_checkpoint(", 1)[0]
SMOKE = (Path(__file__).resolve().parent / "godot_flow_smoke.gd").read_text(encoding="utf-8")


class SaveWriteOrderContract(unittest.TestCase):
    def test_encode_before_opening_truncating_temp_file(self):
        self.assertLess(SAVE.index("DreamSaveCodec.encode_checkpoint(payload)"),
                        SAVE.index("FileAccess.open(TEMP_FILE, FileAccess.WRITE)"))

    def test_size_rejection_before_opening_temp_file(self):
        self.assertLess(SAVE.index("encoded.to_utf8_buffer().size() > MAX_SAVE_BYTES"),
                        SAVE.index("FileAccess.open(TEMP_FILE, FileAccess.WRITE)"))
        self.assertIn('"Invalid save size or content"', SAVE)

    def test_engine_smoke_has_oversize_disk_fixture(self):
        self.assertIn('"oversized checkpoint rejected before parsing"', SMOKE)
        self.assertIn('"X".repeat(16385)', SMOKE)
        self.assertIn('sealed_path, oversized_path]', SMOKE)


if __name__ == "__main__":
    unittest.main()
