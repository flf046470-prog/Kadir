"""Source-contract regression tests. These do not execute the Godot engine."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
PLAYER = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")
OVERLAY = (ROOT / "scripts/overlay.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class RuntimeSafetyContract(unittest.TestCase):
    def test_raycast_explicitly_ignores_player_collision_body(self):
        self.assertIn("ray.add_exception(self)", PLAYER)
        self.assertLess(PLAYER.index("camera.add_child(ray)"), PLAYER.index("ray.add_exception(self)"))
        self.assertIn("ray.force_raycast_update()", PLAYER)

    def test_engine_smoke_will_check_raycast_exception(self):
        self.assertIn("probe_ray.hit_from_inside = true", SMOKE)
        self.assertIn("probe_ray.get_collider() != game.player", SMOKE)
        self.assertNotIn("get_exceptions()", SMOKE.split("    var probe_ray:", 1)[-1])

    def test_hud_text_only_assigned_when_changed(self):
        self.assertIn("if stats_label.text != status:", OVERLAY)
        self.assertIn("if hint_label.text != shown_hint:", OVERLAY)
        self.assertIn("if aim_label.visible != show_aim:", OVERLAY)


if __name__ == "__main__":
    unittest.main()
