"""Source-only contract for direct dive completion calls (not a Godot test)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
FINISH = MAIN.split("func _finish_dive(token: int) -> void:", 1)[1].split("func _fold() -> void:", 1)[0]
PROCESS = MAIN.split("func _process(delta: float) -> void:", 1)[1].split("func _unhandled_input(", 1)[0]


class DiveCompletionContract(unittest.TestCase):
    def test_completion_rejects_unfocused_direct_calls(self):
        self.assertIn("or not app_has_focus:", FINISH)
        self.assertLess(FINISH.index("not app_has_focus"), FINISH.index("transitioning = false"))

    def test_completion_rejects_early_current_token(self):
        self.assertIn("if dive_remaining_seconds > 0.0:\n        return", FINISH)
        self.assertLess(FINISH.index("if dive_remaining_seconds > 0.0:"), FINISH.index('run_started = true'))

    def test_existing_token_and_countdown_completion_remain(self):
        self.assertIn("token != transition_token or not transitioning or not is_inside_tree()", FINISH)
        self.assertIn("dive_remaining_seconds = maxf(0.0, dive_remaining_seconds - focused_delta)", PROCESS)
        self.assertIn("_finish_dive(transition_token)", PROCESS)

    def test_engine_smoke_exercises_both_guards_and_normal_finish(self):
        for marker in (
            "current-token early dive completion is rejected",
            "background direct dive completion is rejected even at zero seconds",
            "foreground countdown completes bed to house transition",
        ):
            self.assertIn(marker, SMOKE)


if __name__ == "__main__":
    unittest.main()
