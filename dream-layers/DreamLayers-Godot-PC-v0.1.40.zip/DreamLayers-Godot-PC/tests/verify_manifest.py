"""Verify source package hashes and file inventory without running Godot."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "docs" / "MANIFEST.json"


def main() -> int:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    expected = data["files"]
    actual = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file()
        and path != MANIFEST
        and "__pycache__" not in path.parts
        and ".godot" not in path.parts
    }
    if set(expected) != actual:
        print("FAIL: missing:", sorted(set(expected) - actual), "extra:", sorted(actual - set(expected)))
        return 1
    mismatches = []
    for relative, digest in sorted(expected.items()):
        actual_digest = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
        if actual_digest != digest:
            mismatches.append(relative)
    if mismatches:
        print("FAIL: SHA-256 mismatch:", mismatches)
        return 1
    print(f"PASS: {len(expected)}/{len(expected)} SHA-256 source files verified")
    return 0


if __name__ == "__main__":
    sys.exit(main())
