"""Static source contract for ending guard; NOT a Godot runtime test."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
WAKE = MAIN.split("func _wake() -> void:", 1)[1]
GATE = MAIN.split("func _can_interact(action: String) -> bool:", 1)[1].split("func _interact(", 1)[0]


class WakeGuardContract(unittest.TestCase):
    def test_wake_requires_shared_interaction_gate_and_solved_seal(self):
        self.assertIn('if not _can_interact("wake_bell") or not seal_open:\n        return', WAKE)

    def test_wake_guard_precedes_room_change_and_completion(self):
        self.assertLess(WAKE.index('_can_interact("wake_bell")'), WAKE.index('_move_to("reality")'))
        self.assertLess(WAKE.index('not seal_open'), WAKE.index('game_complete = true'))

    def test_shared_gate_requires_house_focus_and_no_modal_or_transition(self):
        self.assertIn('"wake_bell": "house"', MAIN)
        self.assertIn('not app_has_focus or game_complete or transitioning or overlay.is_dialog_open', GATE)
        self.assertIn('return action == "bed" or run_started', GATE)

    def test_engine_smoke_covers_unauthorized_and_legitimate_wake(self):
        for marker in (
            "direct wake cannot bypass prologue or seal",
            "direct wake cannot complete from school",
            "background direct wake cannot complete the game",
            '"demo completed"',
        ):
            self.assertIn(marker, SMOKE)


if __name__ == "__main__":
    unittest.main()
