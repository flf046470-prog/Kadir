"""Regression contracts for defects found by the first real Godot 4.3 run (v0.1.39).

Static source checks only; `tests/run_godot_smoke.py --require-engine` is the
behavioural proof.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
BUILDER = (ROOT / "scripts/room_builder.gd").read_text(encoding="utf-8")
CODEC = (ROOT / "scripts/save_codec.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class EngineParseFixesContract(unittest.TestCase):
    def test_main_does_not_override_object_tr(self):
        # Object.tr(StringName, StringName) cannot be overridden with a
        # different signature: Godot 4.3 refused to parse main.gd.
        self.assertIsNone(re.search(r"^func tr\(", MAIN, re.M))
        self.assertIsNone(re.search(r"(?<![\w.])tr\(", MAIN))
        self.assertIn("func loc(turkish: String, english: String) -> String:", MAIN)

    def test_codec_duplicate_is_explicitly_typed(self):
        self.assertIn("var state: Dictionary = raw.duplicate(true)", CODEC)
        self.assertNotIn("var state := raw.duplicate(true)", CODEC)

    def test_cuboid_children_have_stable_names(self):
        cuboid = BUILDER.split("static func cuboid(", 1)[1].split("\nstatic func ", 1)[0]
        self.assertIn('hit.name = "CollisionShape3D"', cuboid)
        self.assertIn('mesh.name = "Visual"', cuboid)

    def test_corrupt_checkpoints_parse_without_engine_error(self):
        decode = CODEC.split("static func decode_checkpoint(text: String)", 1)[1]
        self.assertNotIn("JSON.parse_string", decode)
        self.assertIn("var parser := JSON.new()", CODEC)

    def test_smoke_releases_meshes_before_teardown(self):
        self.assertIn("func _release_meshes(node: Node) -> void:", SMOKE)
        self.assertLess(SMOKE.index("DREAM LAYERS ENGINE SMOKE:"), SMOKE.index("game.free()"))


if __name__ == "__main__":
    unittest.main()
