"""Static guards for stale-dialog prevention; not an in-engine test."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
OVERLAY = (ROOT / "scripts/overlay.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class DialogContextContract(unittest.TestCase):
    def test_dialog_context_is_recorded(self):
        self.assertIn('var active_dialog := ""', MAIN)
        self.assertIn('active_dialog = context', MAIN)
        for context in ('"intro"', '"note"', '"fuses"', '"locker"', '"seal"', '"ending"'):
            self.assertIn(context, MAIN)

    def test_choice_requires_current_context(self):
        block = MAIN.split('func _choice(id: String)', 1)[1].split('    match id:', 1)[0]
        self.assertIn('active_dialog != required_context', block)
        for context in ('intro', 'ending', 'fuses', 'seal', 'locker'):
            self.assertIn(f'required_context = "{context}"', block)
        self.assertIn('elif id != "close":', block)

    def test_generation_increments_on_open_and_close(self):
        self.assertIn('var dialog_generation := 0', OVERLAY)
        self.assertEqual(OVERLAY.count('dialog_generation += 1'), 2)
        self.assertIn('button.pressed.connect(_choose.bind(str(choice.get("id", "")), dialog_generation))', OVERLAY)
        self.assertIn('if generation != dialog_generation or not is_dialog_open:', OVERLAY)

    def test_engine_smoke_covers_stale_and_cross_dialog(self):
        self.assertIn('cross-dialog puzzle callback rejected', SMOKE)
        self.assertIn('stale button generation rejected', SMOKE)


if __name__ == "__main__":
    unittest.main()
