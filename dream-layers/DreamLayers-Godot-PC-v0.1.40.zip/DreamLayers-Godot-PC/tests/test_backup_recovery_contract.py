"""Static source regression; Godot engine I/O requires the separate smoke test."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class BackupRecoveryContract(unittest.TestCase):
    def test_pending_file_verified_before_rotation(self):
        save = MAIN.split("func _save_game() -> void:", 1)[1].split("func _promote_checkpoint(", 1)[0]
        self.assertLess(save.index("_read_checkpoint(TEMP_FILE).is_empty()"),
                        save.index("_promote_checkpoint(temporary, target, backup, primary_valid)"))

    def test_primary_validity_checked_from_disk(self):
        self.assertIn("var primary_valid := not _read_checkpoint(SAVE_FILE).is_empty()", MAIN)

    def test_invalid_primary_does_not_replace_backup(self):
        block = MAIN.split("func _promote_checkpoint(", 1)[1].split("func _read_checkpoint(", 1)[0]
        self.assertIn("if primary_valid:", block)
        self.assertIn("elif DirAccess.remove_absolute(target) != OK:", block)
        self.assertIn("DirAccess.rename_absolute(target, rollback)", block)
        self.assertLess(block.index("if primary_valid:"), block.index("DirAccess.rename_absolute(target, rollback)"))

    def test_backup_recovery_remains_available_on_failed_promotion(self):
        block = MAIN.split("func _promote_checkpoint(", 1)[1].split("func _read_checkpoint(", 1)[0]
        self.assertIn("if DirAccess.rename_absolute(temporary, target) != OK:", block)
        self.assertIn("DirAccess.rename_absolute(rollback, target)", block)

    def test_old_backup_retained_until_new_primary_verified(self):
        block = MAIN.split("func _promote_checkpoint(", 1)[1].split("func _read_recovery_checkpoint(", 1)[0]
        self.assertLess(block.index("DirAccess.rename_absolute(target, rollback)"),
                        block.index("DirAccess.rename_absolute(temporary, target)"))
        self.assertLess(block.index("if _read_checkpoint(target).is_empty():"),
                        block.index("DirAccess.remove_absolute(backup)"))
        self.assertLess(block.index("DirAccess.remove_absolute(backup)"),
                        block.index("DirAccess.rename_absolute(rollback, backup)"))

    def test_crash_recovery_prefers_rollback_before_older_backup(self):
        block = MAIN.split("func _read_recovery_checkpoint(", 1)[1].split("func _read_checkpoint(", 1)[0]
        self.assertIn("for path in [primary, rollback, backup]:", block)
        self.assertIn('SAVE_FILE + ".rollback"', MAIN)
        self.assertIn('"interrupted promotion prefers rollback"', SMOKE)
        self.assertIn('"verified promotion updates backup"', SMOKE)

    def test_engine_smoke_uses_isolated_files_and_cleans_up(self):
        self.assertIn('user://dream_layers_smoke_checkpoint_v015', SMOKE)
        self.assertIn('"last valid backup preserved"', SMOKE)
        self.assertIn('"corrupt primary rejected"', SMOKE)
        self.assertIn('DirAccess.remove_absolute(test_dir_abs)', SMOKE)
        self.assertNotIn('FileAccess.open(game.SAVE_FILE, FileAccess.WRITE)', SMOKE)


if __name__ == "__main__":
    unittest.main()
