"""Source contracts for 3D interaction reach (NOT an engine physics test)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
PLAYER = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class Reach3DContract(unittest.TestCase):
    def test_hit_uses_shared_reach_guard(self):
        self.assertIn('if not _hit_within_reach(hit_point, allowed):', PLAYER)

    def test_reach_is_camera_to_hit_3d(self):
        self.assertIn('ray.global_position.distance_to(hit_point)', PLAYER)
        self.assertNotIn('Vector2(global_position.x, global_position.z)', PLAYER)

    def test_reach_rejects_negative_limits(self):
        self.assertIn('allowed >= 0.0 and ray.global_position.distance_to(hit_point) <= allowed', PLAYER)

    def test_engine_scenarios_include_vertical_and_near_hits(self):
        for label in (
            'vertical offset cannot bypass interaction reach',
            'nearby object remains within interaction reach',
            'negative reach cannot enable interaction',
        ):
            self.assertIn(label, SMOKE)


if __name__ == "__main__":
    unittest.main()
