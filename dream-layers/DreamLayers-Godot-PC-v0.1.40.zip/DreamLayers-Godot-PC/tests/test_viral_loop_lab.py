"""Tests for original, offline design research model (NOT a Godot smoke test)."""
import unittest
from tools.viral_loop_lab import EVENT_TYPES, evaluate, schedule_events


class ViralLoopLabTests(unittest.TestCase):
    def test_first_phase_is_safe_and_every_run_has_event(self):
        for seed in range(120):
            result = schedule_events(seed)
            self.assertTrue(result)
            self.assertTrue(all(1 <= e.phase < 6 for e in result))
            self.assertTrue(all(e.kind in EVENT_TYPES for e in result))

    def test_schedule_is_deterministic_and_does_not_use_global_rng(self):
        import random
        random.seed(150)
        before = random.getstate()
        self.assertEqual(schedule_events(417), schedule_events(417))
        self.assertEqual(before, random.getstate())

    def test_cooldown_and_maximum_three_events(self):
        for seed in range(150):
            chosen = schedule_events(seed)
            self.assertLessEqual(len(chosen), 3)
            self.assertTrue(all(b.phase - a.phase >= 2 for a, b in zip(chosen, chosen[1:])))

    def test_empty_random_selection_gets_one_non_onboarding_event(self):
        chosen = schedule_events(0, probability=0.0)
        self.assertEqual([x.phase for x in chosen], [3])

    def test_all_candidate_chances_still_respect_cooldown(self):
        chosen = schedule_events(0, probability=1.0)
        self.assertEqual([x.phase for x in chosen], [1, 3, 5])

    def test_invalid_configuration_and_empty_measurement_rejected(self):
        for cfg in ({"phase_count": 1}, {"phase_seconds": 0},
                    {"probability": -0.1}, {"probability": 1.01},
                    {"max_events": 0}, {"min_empty_phases": 6}):
            with self.subTest(cfg=cfg), self.assertRaises(ValueError):
                schedule_events(4, **cfg)
        with self.assertRaises(ValueError):
            evaluate([])

    def test_report_only_models_candidate_counts(self):
        r = evaluate(range(30))
        self.assertEqual(r.simulated_runs, 30)
        self.assertEqual(sum(r.kind_counts.values()), int(r.mean_events_per_run * 30 + 1e-6))
        self.assertGreaterEqual(r.median_first_event_seconds, 90)
        self.assertLessEqual(r.max_events_per_run, 3)


if __name__ == "__main__":
    unittest.main()
