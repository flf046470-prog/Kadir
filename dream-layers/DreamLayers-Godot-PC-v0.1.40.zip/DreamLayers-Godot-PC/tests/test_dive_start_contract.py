"""Static contract for direct dive starts; NOT an in-engine test."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
START = MAIN.split("func _start_dive() -> void:", 1)[1].split("func _finish_dive(", 1)[0]
GATE = MAIN.split("func _can_interact(action: String) -> bool:", 1)[1].split("func _interact(", 1)[0]


class DiveStartContract(unittest.TestCase):
    def test_direct_start_uses_shared_bed_gate_before_mutating_transition(self):
        self.assertIn('if not _can_interact("bed"):\n        return', START)
        self.assertLess(START.index('_can_interact("bed")'), START.index('transitioning = true'))
        self.assertLess(START.index('_can_interact("bed")'), START.index('transition_token += 1'))

    def test_shared_gate_checks_focus_modal_and_active_transition(self):
        self.assertIn('not app_has_focus or game_complete or transitioning or overlay.is_dialog_open', GATE)

    def test_shared_gate_restricts_bed_to_reality(self):
        self.assertIn('ACTION_LAYERS[action] != current_layer', GATE)
        self.assertIn('return action == "bed" or run_started', GATE)
        self.assertIn('"bed": "reality"', MAIN)

    def test_engine_smoke_covers_direct_start_and_normal_completion(self):
        for marker in (
            "direct bed dive cannot bypass prologue modal",
            "background direct dive start is rejected",
            "direct dive restart cannot reset active countdown",
            "direct dive start cannot restart from house",
            "foreground countdown completes bed to house transition",
        ):
            self.assertIn(marker, SMOKE)


if __name__ == "__main__":
    unittest.main()
