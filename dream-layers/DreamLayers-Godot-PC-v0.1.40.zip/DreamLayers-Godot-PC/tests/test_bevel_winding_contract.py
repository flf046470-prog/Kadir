"""Verify the v0.1.37 beveled ArrayMesh triangle orientation, statically.

Godot ArrayMesh front-facing triangles have CLOCKWISE winding viewed from
outside. Because U cross V is outward in this builder, mathematical triangle
cross-products must point INWARD (opposite the supplied outward vertex normals).
These tests do not run the Godot renderer; use the engine smoke for that.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "scripts/room_builder.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
MESH = SOURCE.split("static func _beveled_box_mesh(", 1)[1].split("static func _use_bevel_visual(", 1)[0]


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


class BevelWindingContract(unittest.TestCase):
    def test_source_winds_both_triangles_clockwise(self):
        self.assertIn('first, first + row_length, first + 1,', MESH)
        self.assertIn('first + 1, first + row_length, first + row_length + 1', MESH)
        self.assertNotIn('first, first + 1, first + row_length,', MESH)
        self.assertNotIn('first + 1, first + row_length + 1, first + row_length', MESH)

    def test_six_faces_have_outward_basis(self):
        # Mirrors face_normals / face_u / face_v from the 3D source.
        right, left, up, down, back, forward = ((1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1))
        faces=[(right,forward,up),(left,back,up),(up,right,forward),
               (down,right,back),(back,right,up),(forward,left,up)]
        self.assertEqual(len(faces),6)
        for outward, u, v in faces:
            with self.subTest(face=outward):
                self.assertEqual(cross(u, v), outward)
                # first -> first+row -> first+1 is +V then +U.
                self.assertLess(dot(cross(v,u), outward), 0)
                # second triangle: first+1 -> first+row -> next+row
                self.assertLess(dot(cross(tuple(x-y for x,y in zip(v,u)), v),outward),0)

    def test_vertex_normals_stay_outward(self):
        self.assertIn('var outward := (box_point - core).normalized()', MESH)
        self.assertIn('normals.append(outward)', MESH)
        self.assertIn('triangles.append_array(PackedInt32Array([', MESH)

    def test_mesh_count_and_cache_unchanged(self):
        self.assertIn('var cache_key := str(size) + ":" + str(bevel)', MESH)
        self.assertIn('if _bevel_mesh_cache.has(cache_key):', MESH)
        self.assertIn('result.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, buffers)', MESH)
        self.assertIn('shape.size = size', SOURCE)
        self.assertIn('hit.shape = shape', SOURCE)

    def test_godot_smoke_checks_all_faces_and_gameplay_colliders(self):
        self.assertIn('bevel clockwise winding agrees with outward vertex normal', SMOKE)
        self.assertIn('bevel collision shape remains a BoxShape3D', SMOKE)
        self.assertIn('game.rooms["reality"].get_node("BedFrame")', SMOKE)


if __name__ == '__main__':
    unittest.main()
