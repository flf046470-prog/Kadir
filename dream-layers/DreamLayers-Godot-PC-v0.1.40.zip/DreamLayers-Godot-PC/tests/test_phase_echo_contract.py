"""Source-level checks for optional six-phase memory echoes; NOT runtime tests."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'scripts/main.gd').read_text()
ROOM = (ROOT / 'scripts/room_builder.gd').read_text()
SMOKE = (ROOT / 'tests/godot_flow_smoke.gd').read_text()

class PhaseEchoContract(unittest.TestCase):
    def test_six_temporal_variants_have_inspectable_actions(self):
        creator = ROOM.split('static func add_personal_phase_props(', 1)[1]
        self.assertIn('for index in range(6):', creator)
        self.assertIn('"phase_echo", 2.7', creator)
        self.assertIn('"TemporalVariant_%d" % index', creator)
        self.assertIn('item.collision_layer = 1 if index == 0 else 0', creator)

    def test_phase_echo_uses_standard_interaction_gate_and_context(self):
        self.assertIn('"phase_echo": "house"', MAIN)
        self.assertIn('"phase_echo":\n            _inspect_phase_echo()', MAIN)
        func = MAIN.split('func _inspect_phase_echo()', 1)[1].split('func _update_phase(', 1)[0]
        self.assertIn('if not _can_interact("phase_echo"):', func)
        self.assertIn('if current_phase < 0 or current_phase >= temporal_props.size():', func)
        self.assertIn('"echo")', func)
        self.assertIn('"id": "close"', func)

    def test_invisible_echoes_do_not_block_raycast(self):
        func = MAIN.split('func _update_phase(', 1)[1].split('func _start_dive(', 1)[0]
        self.assertIn('echo.visible = idx == phase', func)
        self.assertIn('echo_body.collision_layer = 1 if idx == phase else 0', func)
        self.assertIn('var echo_body := echo as CollisionObject3D', func)

    def test_echo_is_optional_and_does_not_mutate_gameplay_or_save(self):
        func = MAIN.split('func _inspect_phase_echo()', 1)[1].split('func _update_phase(', 1)[0]
        self.assertIn('var lines_tr := [', func)
        self.assertIn('var lines_en := [', func)
        for forbidden in ('stability =', 'remaining_seconds =', 'power_on =',
                          'seal_open =', 'archive_found =', '_save_game(', '_fold('):
            self.assertNotIn(forbidden, func)
        self.assertNotIn('phase_echo', (ROOT / 'scripts/save_codec.gd').read_text())

    def test_engine_smoke_has_focus_modal_and_collision_checks(self):
        for needle in ('phase echo prologue interaction rejected',
                       'phase echo displays contextual clue',
                       'phase echo does not grant stability',
                       'inactive phase markers cannot intercept raycasts'):
            self.assertIn(needle, SMOKE)

if __name__ == '__main__':
    unittest.main()
