"""Static visual pipeline checks; NOT evidence of rendered photorealism/FPS."""
from pathlib import Path
import unittest
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ROOM = (ROOT / 'scripts/room_builder.gd').read_text()
MAIN = (ROOT / 'scripts/main.gd').read_text()
PROJECT = (ROOT / 'project.godot').read_text()


class GlobalPBRContract(unittest.TestCase):
    def test_pbr_meshes_apply_to_every_procedural_room(self):
        self.assertIn('mesh.material_override = _pbr_material(label, tint)', ROOM)
        for room in ('build_reality', 'build_house', 'build_school'):
            self.assertIn('static func ' + room, ROOM)
        self.assertIn('static var _material_cache: Dictionary', ROOM)

    def test_textures_cover_five_material_families(self):
        for kind in ('plaster', 'wood', 'fabric', 'metal', 'stone'):
            for channel in ('albedo', 'normal', 'roughness'):
                path = ROOT / 'assets' / 'pbr' / f'{kind}_{channel}.png'
                self.assertTrue(path.exists(), path)
                with Image.open(path) as texture:
                    self.assertEqual(texture.size, (512, 512))
                    self.assertEqual(texture.mode, 'RGB')
        self.assertIn('result.normal_texture', ROOM)
        self.assertIn('result.roughness_texture', ROOM)

    def test_color_pipeline_and_renderer(self):
        self.assertIn('renderer/rendering_method="forward_plus"', PROJECT)
        self.assertIn('Environment.TONE_MAPPER_ACES', MAIN)
        self.assertIn('background.tonemap_white = 6.0', MAIN)

    def test_quality_tiers_are_runtime_adjustable(self):
        self.assertIn('env.ssao_enabled = quality >= 1', MAIN)
        self.assertIn('env.ssil_enabled = quality == 2', MAIN)
        self.assertIn('lamp.shadow_enabled = shadow_on', MAIN)
        self.assertIn('KEY_F3', MAIN)
        self.assertIn('Viewport.MSAA_DISABLED if quality == 0', MAIN)

    def test_no_puzzle_collision_rewrites(self):
        for action in ('"bed"', '"fuses"', '"locker"', '"seal"', '"wake_bell"'):
            self.assertIn(action, ROOM)
        self.assertIn('root.set_meta("reach_m", reach)', ROOM)
        self.assertIn('if solid:', ROOM)
        self.assertIn('StaticBody3D.new()', ROOM)
        self.assertIn('"SkirtingX"', ROOM)


if __name__ == '__main__':
    unittest.main()
