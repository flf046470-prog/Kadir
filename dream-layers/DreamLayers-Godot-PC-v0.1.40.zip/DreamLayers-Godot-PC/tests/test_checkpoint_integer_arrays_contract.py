"""Static contracts for integer puzzle arrays after JSON checkpoint decoding.

These are NOT Godot parser/runtime tests; engine smoke checks the behavior.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
CODEC = (ROOT / "scripts/save_codec.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
VALIDATED = CODEC.split("static func validated(raw: Variant) -> Dictionary:", 1)[1].split("static func encode_checkpoint", 1)[0]


class CheckpointIntegerArraysContract(unittest.TestCase):
    def test_integer_range_validation_still_precedes_normalization(self):
        self.assertLess(VALIDATED.index('if not _integer(value, 1, 6):'), VALIDATED.index('var fuses: Array[int]'))
        self.assertLess(VALIDATED.index('if not _integer(value, 0, 5):'), VALIDATED.index('var seal: Array[int]'))

    def test_both_puzzle_arrays_normalize_to_ints(self):
        for key in ('fuses', 'seal'):
            self.assertIn(f'for value in raw["{key}"]:', VALIDATED)
            self.assertIn(f'{key}.append(int(value))', VALIDATED)
            self.assertIn(f'state["{key}"] = {key}', VALIDATED)
        self.assertIn('return state', VALIDATED)
        self.assertNotIn('return raw.duplicate(true)', VALIDATED)

    def test_progress_checks_compare_normalized_int_arrays(self):
        # Godot 4 Array equality is type-strict: parsed JSON [3.0, 1.0, 4.0]
        # != [3, 1, 4]. Found by the real engine smoke in v0.1.39.
        self.assertLess(VALIDATED.index('var seal: Array[int]'), VALIDATED.index('# Reject impossible progress'))
        self.assertNotIn('raw["fuses"] != [', VALIDATED)
        self.assertNotIn('raw["seal"] != [', VALIDATED)

    def test_both_checkpoint_decoders_pass_through_validation(self):
        decode = CODEC.split('static func decode_checkpoint(text: String) -> Dictionary:', 1)[1]
        self.assertIn('return validated(_parse_json(data))', decode)
        self.assertIn('return validated(raw)', decode)

    def test_engine_scenarios_cover_modulo_and_legacy_arrays(self):
        for marker in (
            'decoded fuse values are integer typed',
            'decoded fuse value cycles safely after reload',
            'decoded seal values are integer typed',
            'legacy checkpoint puzzle arrays normalize to integers',
        ):
            self.assertIn(marker, SMOKE)


if __name__ == "__main__":
    unittest.main()
