"""Source-level regression guards; these do NOT execute GDScript or Godot."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
PLAYER = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")
OVERLAY = (ROOT / "scripts/overlay.gd").read_text(encoding="utf-8")


class InteractionContract(unittest.TestCase):
    def test_locker_requires_manual_entry(self):
        self.assertIn('overlay.dialog_code(', MAIN)
        self.assertNotIn('"locker_right"', MAIN)
        self.assertNotIn('"locker_wrong_a"', MAIN)

    def test_locker_code_is_checked(self):
        self.assertIn('entered_code == "4812"', MAIN)
        self.assertIn('entered_code.length() != 4', MAIN)
        self.assertIn('entered_code.is_valid_int()', MAIN)
        self.assertIn('entered_code.begins_with("+")', MAIN)

    def test_malformed_locker_input_does_not_penalize(self):
        start = MAIN.index('elif id.begins_with("locker_submit:")')
        end = MAIN.index('            else:\n                overlay.dismiss()', start)
        branch = MAIN[start:end]
        self.assertLess(branch.index('return'), branch.index('_wrong_answer()'))

    def test_locker_success_is_idempotent(self):
        self.assertIn('if not locker_open:', MAIN)
        self.assertIn('locker_open = true', MAIN)

    def test_archive_is_prerequisite_for_seal(self):
        self.assertIn('if not archive_found:', MAIN)

    def test_game_over_stops_movement(self):
        self.assertIn('player.can_move = app_has_focus and not overlay.is_dialog_open and not transitioning and not game_complete', MAIN)

    def test_reach_uses_raycast_collision(self):
        self.assertIn('ray.get_collision_point()', PLAYER)
        self.assertNotIn('distance_to(body.global_position)', PLAYER)
        self.assertIn('if not _hit_within_reach(hit_point, allowed):', PLAYER)

    def test_code_ui_uses_four_character_limit(self):
        self.assertIn('modal_code.max_length = 4', OVERLAY)
        self.assertIn('"locker_submit:" + modal_code.text', OVERLAY)

    def test_existing_dive_and_phase_preserved(self):
        self.assertIn('dive_remaining_seconds = DIVE_SECONDS', MAIN)
        self.assertIn('const EPOCH_SECONDS := 90.0', MAIN)
        self.assertIn('func _fold()', MAIN)


if __name__ == '__main__':
    unittest.main(verbosity=2)
