extends SceneTree

# Real input path smoke: events go through Input.parse_input_event ->
# Viewport -> _unhandled_input, the raycast is the physics RayCast3D and
# movement runs in _physics_process. Still headless: no GPU, no OS window.
var failures := 0
var checks := 0

func _initialize() -> void:
    call_deferred("_run")

func _check(condition: bool, description: String) -> void:
    checks += 1
    if not condition:
        failures += 1
        push_error("FAIL: " + description)

func _key(code: Key, pressed := true) -> void:
    var event := InputEventKey.new()
    event.keycode = code
    event.physical_keycode = code
    event.pressed = pressed
    Input.parse_input_event(event)

func _tap(code: Key) -> void:
    _key(code, true)
    await process_frame
    _key(code, false)
    await process_frame

func _physics_frames(count: int) -> void:
    for i in range(count):
        await physics_frame

# Stand `distance` metres in front of a node's centre and look straight at it.
func _face(game: Variant, target: Node3D, distance: float, from_dir: Vector3) -> void:
    var player: CharacterBody3D = game.player
    var goal := target.global_position
    var eye_height: float = player.eye.position.y
    player.global_position = Vector3(goal.x, 0.05, goal.z) + from_dir.normalized() * distance
    player.velocity = Vector3.ZERO
    var flat := Vector3(goal.x, player.global_position.y, goal.z)
    player.look_at(flat, Vector3.UP)
    var eye_pos := player.global_position + Vector3(0, eye_height, 0)
    var to_target := goal - eye_pos
    var horizontal := Vector2(to_target.x, to_target.z).length()
    player.eye.rotation.x = atan2(to_target.y, horizontal)
    await _physics_frames(3)

func _run() -> void:
    var scene := load("res://Main.tscn") as PackedScene
    var game = scene.instantiate()
    root.add_child(game)
    await _physics_frames(5)
    var reality: Node3D = game.rooms["reality"]

    # Intro dialog blocks E: pressing it must not start anything.
    _check(game.overlay.is_dialog_open and game.active_dialog == "intro", "intro dialog open at start")
    await _tap(KEY_E)
    _check(game.active_dialog == "intro" and not game.transitioning, "E ignored while intro is open")
    game._choice("intro_start")
    await process_frame
    _check(not game.overlay.is_dialog_open and game.prologue_step == 1, "intro closed, objective 1")

    # Raycast through the real physics world onto the clock, then press E.
    await _face(game, reality.get_node("PrologueClock"), 1.4, Vector3(-1, 0, 0.4))
    _check(game.player.looked_at_action() == "prologue_clock", "ray hits the desk clock from 1.4 m")
    await _tap(KEY_E)
    _check(game.active_dialog == "prologue_clock" and game.prologue_step == 2, "E on the clock opens objective 2")
    game._choice("close")
    await process_frame

    # Out of reach: the clock allows 2.3 m, the ray is 3.8 m long.
    await _face(game, reality.get_node("PrologueClock"), 3.2, Vector3(-1, 0, 0.4))
    _check(game.player.looked_at_action() == "", "clock is out of reach at 3.2 m")

    # WASD walks through _physics_process with real key state.
    var player: CharacterBody3D = game.player
    player.global_position = Vector3(0.5, 0.05, 1.0)
    player.rotation = Vector3.ZERO
    await _physics_frames(10)
    var start := player.global_position
    _key(KEY_W, true)
    await _physics_frames(30)
    _key(KEY_W, false)
    await _physics_frames(20)
    var walked := Vector2(player.global_position.x - start.x, player.global_position.z - start.z).length()
    _check(walked > 0.8 and walked < 3.5, "W walks forward ~0.5 s (moved %.2f m)" % walked)
    _check(player.global_position.y > -0.5, "player stays on the floor")

    # The bed by ray + E starts the dive; R cancels it.
    await _face(game, reality.get_node("BedFrame"), 2.4, Vector3(1, 0, 0.3))
    _check(game.player.looked_at_action() == "bed", "ray hits the bed")
    await _tap(KEY_E)
    _check(game.transitioning, "E on the bed starts the dive")
    await _tap(KEY_R)
    _check(not game.transitioning and game.current_layer == "reality", "R cancels the dive")

    # F2 / F3 via real key events.
    var lang: String = game.language
    await _tap(KEY_F2)
    _check(game.language != lang, "F2 toggles language")
    var q: int = game.quality
    await _tap(KEY_F3)
    _check(game.quality == (q + 1) % 3, "F3 cycles quality")

    print("DREAM LAYERS INPUT SMOKE: %d checks, %d failures" % [checks, failures])
    for room in game.rooms.values():
        _release(room)
    _release(game)
    for room in game.rooms.values():
        if not room.is_inside_tree():
            room.free()
    for child in game.get_children(true):
        child.free()
    game.free()
    await process_frame
    quit(1 if failures > 0 else 0)

func _release(node: Node) -> void:
    if node is MeshInstance3D:
        (node as MeshInstance3D).mesh = null
    for child in node.get_children(true):
        _release(child)
