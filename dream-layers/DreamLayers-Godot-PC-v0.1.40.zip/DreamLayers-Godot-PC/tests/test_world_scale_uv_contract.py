"""Static checks for selective world-scale PBR mapping (not render proof)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ROOM = (ROOT / "scripts/room_builder.gd").read_text()
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text()


class WorldScaleUVContract(unittest.TestCase):
    def test_world_mapping_is_limited_to_six_shell_labels(self):
        self.assertIn('const WORLD_MAPPED_SHELL := ["Floor", "Ceiling", "North", "South", "West", "East"]', ROOM)
        self.assertIn('return label in WORLD_MAPPED_SHELL', ROOM)
        self.assertIn('var world_mapped := _world_mapped(label)', ROOM)

    def test_cache_does_not_alias_uv_and_triplanar_materials(self):
        self.assertIn('if world_mapped else ":uv"', ROOM)
        self.assertIn('":world" if world_mapped', ROOM)
        self.assertIn('if _material_cache.has(key):', ROOM)

    def test_world_scale_and_low_cost_furniture_uvs(self):
        self.assertIn('result.uv1_triplanar = world_mapped', ROOM)
        self.assertIn('result.uv1_world_triplanar = world_mapped', ROOM)
        self.assertIn('Vector3(0.75, 0.75, 0.75) if world_mapped else Vector3(2.0, 2.0, 2.0)', ROOM)

    def test_engine_assertions_and_collision_contract_preserved(self):
        self.assertIn('shell_mat.uv1_world_triplanar', SMOKE)
        self.assertIn('not bed_mat.uv1_triplanar', SMOKE)
        self.assertIn('shape.size = size', ROOM)
        self.assertIn('mesh.material_override = _pbr_material(label, tint)', ROOM)


if __name__ == "__main__":
    unittest.main()
