"""Static-only decorative geometry contracts; real Godot rendering is untested."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ROOM = (ROOT / "scripts/room_builder.gd").read_text()
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text()


class RoundedHardwareContract(unittest.TestCase):
    def test_rounded_details_use_low_segment_cylinder_pbr(self):
        method = ROOM.split("static func rounded_detail", 1)[1].split("static func light", 1)[0]
        for fragment in ("CylinderMesh.new()", "cylinder.radial_segments = 12",
                         "mesh.material_override = _pbr_material(label, tint)",
                         "root.add_child(mesh)", "parent.add_child(root)"):
            self.assertIn(fragment, method)

    def test_details_never_create_physics_or_actions(self):
        method = ROOM.split("static func rounded_detail", 1)[1].split("static func light", 1)[0]
        for forbidden in ("StaticBody3D.new", "CollisionShape3D.new", "BoxShape3D.new",
                          'set_meta("action"', "collision_layer"):
            self.assertNotIn(forbidden, method)
        self.assertIn('"wake_bell", 1.5)', ROOM)
        self.assertIn('true, "seal")', ROOM)
        self.assertIn('true, "bed", 2.4)', ROOM)

    def test_each_room_gets_visual_only_rounded_details(self):
        for label in ("LampBaseRound", "LampStemRound", "BellButtonRound", "DoorKnobRound",
                      "LockerKnobRound_%d", "SealDialRound"):
            self.assertIn(label, ROOM)
        self.assertIn('if face_z:', ROOM)
        self.assertIn('mesh.rotation_degrees.x = 90.0', ROOM)

    def test_engine_smoke_covers_geometry_and_interactions(self):
        for fragment in ("rounded detail has no physics body", "rounded hardware uses cylinder geometry",
                         "rounded hardware preserves bed action collider",
                         "rounded hardware preserves bell action collider",
                         "rounded hardware preserves seal action collider"):
            self.assertIn(fragment, SMOKE)


if __name__ == "__main__":
    unittest.main()
