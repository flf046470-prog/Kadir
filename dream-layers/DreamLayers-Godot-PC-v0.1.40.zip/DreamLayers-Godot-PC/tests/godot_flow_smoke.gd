extends SceneTree

# In-engine gameplay state smoke, invoked by tests/run_godot_smoke.py.
# Simulates focused dive countdown via _process; not real OS Alt+Tab,
# physical keyboard/raycast input, cinematic rendering or GPU performance.
var failures := 0
var checks := 0

func _initialize() -> void:
    call_deferred("_run")

func _check(condition: bool, description: String) -> void:
    checks += 1
    if not condition:
        failures += 1
        push_error("FAIL: " + description)

func _run() -> void:
    var scene := load("res://Main.tscn") as PackedScene
    if scene == null:
        push_error("Could not load Main.tscn")
        quit(1)
        return
    # PackedScene.instantiate() is typed Node; keep Variant dispatch for the
    # dynamic main.gd script properties/methods (no class_name on that script).
    var game = scene.instantiate()
    root.add_child(game)
    await process_frame
    _check(game.current_layer == "reality", "initial room")
    # Memory Echoes are optional phase-specific interactions. The six
    # overlapping visuals must never become six overlapping physics targets.
    _check(game.temporal_props.size() == 6, "six phase echo variants are present")
    for idx in range(game.temporal_props.size()):
        var marker: CollisionObject3D = game.temporal_props[idx] as CollisionObject3D
        _check(marker.get_meta("action", "") == "phase_echo", "phase echo has action metadata")
        _check(marker.collision_layer == (1 if idx == 0 else 0),
            "inactive phase markers cannot intercept raycasts")
    game._interact("phase_echo")
    _check(game.active_dialog == "intro" and game.overlay.is_dialog_open,
        "phase echo prologue interaction rejected")
    # Shared visual baseline must reach all three streamed rooms, not just the
    # bedroom. This is a resource test, NOT an 8K image/FPS/photorealism test.
    for layer in ["reality", "house", "school"]:
        var any_pbr := false
        for piece in game.rooms[layer].get_children():
            for piece_mesh in piece.get_children():
                if piece_mesh is MeshInstance3D:
                    var surface := piece_mesh.material_override as StandardMaterial3D
                    if surface != null and surface.normal_texture != null and surface.roughness_texture != null:
                        any_pbr = true
                        break
            if any_pbr:
                break
        _check(any_pbr, "PBR material maps present in " + layer)
    # Rounded hardware is visual-only in all three rooms. Gameplay targets
    # remain the original collision bodies and action metadata.
    var rounded_parts := {
        "reality": ["LampBaseRound", "LampStemRound"],
        "house": ["BellButtonRound", "DoorKnobRound"],
        "school": ["LockerKnobRound_0", "LockerKnobRound_4", "SealDialRound"]
    }
    for layer in rounded_parts:
        for part_name in rounded_parts[layer]:
            var detail: Node3D = game.rooms[layer].get_node_or_null(part_name)
            _check(detail != null and not (detail is CollisionObject3D),
                layer + " rounded detail has no physics body: " + part_name)
            var detail_mesh: MeshInstance3D = null
            if detail != null:
                for child in detail.get_children():
                    if child is MeshInstance3D:
                        detail_mesh = child
                        break
            _check(detail_mesh != null and detail_mesh.mesh is CylinderMesh,
                layer + " rounded hardware uses cylinder geometry: " + part_name)
    # v0.1.35: selected hero props have beveled visuals, separate from physics.

    # display mesh while their original BoxShape3D/metadata stay unchanged.
    for layer_name in ["reality", "house", "school"]:
        var hero_name := "BedFrame" if layer_name == "reality" else ("FuseCabinet" if layer_name == "house" else "Locker_2")
        var hero := game.rooms[layer_name].get_node(hero_name) as StaticBody3D
        _check(hero != null and hero.get_child(0) is CollisionShape3D,
            layer_name + " bevel hero retains its original collision shape")
        var display: MeshInstance3D = hero.get_child(1) if hero != null else null
        _check(display != null and display.mesh is ArrayMesh,
            layer_name + " bevel hero uses an ArrayMesh visual")
        if display != null and display.mesh is ArrayMesh:
            var vertices: PackedVector3Array = display.mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
            var indices: PackedInt32Array = display.mesh.surface_get_arrays(0)[Mesh.ARRAY_INDEX]
            _check(vertices.size() == 294 and indices.size() == 1296,
                layer_name + " bevel geometry is indexed and bounded")
    _check(game.rooms["school"].get_node("Locker_0").get_child(1).mesh ==
        game.rooms["school"].get_node("Locker_1").get_child(1).mesh,
        "identical lockers share one cached bevel mesh")
    # v0.1.37: Godot ArrayMesh front faces are clockwise. Sample an interior
    # flat quad on each of the 6 box sides so the triangle winding must be
    # opposite its outward lighting normal. This is NOT a pixel render test.
    var bevel_hero := game.rooms["reality"].get_node("BedFrame") as StaticBody3D
    var collision := bevel_hero.get_child(0) as CollisionShape3D
    _check(collision != null and collision.shape is BoxShape3D,
        "bevel collision shape remains a BoxShape3D")
    var bevel_display := bevel_hero.get_child(1) as MeshInstance3D
    if bevel_display != null and bevel_display.mesh is ArrayMesh:
        var bevel_arrays: Array = bevel_display.mesh.surface_get_arrays(0)
        var points: PackedVector3Array = bevel_arrays[Mesh.ARRAY_VERTEX]
        var normals: PackedVector3Array = bevel_arrays[Mesh.ARRAY_NORMAL]
        var faces: PackedInt32Array = bevel_arrays[Mesh.ARRAY_INDEX]
        for side in range(6):
            # 7x7 vertices, 6x6 quads and 2 triangles/quad per side.
            var tri_offset := side * 216 + (3 * 6 + 3) * 6
            var i0 := faces[tri_offset]
            var i1 := faces[tri_offset + 1]
            var i2 := faces[tri_offset + 2]
            var geometric_normal := (points[i1] - points[i0]).cross(points[i2] - points[i0]).normalized()
            _check(geometric_normal.dot(normals[i0]) < -0.99,
                "bevel clockwise winding agrees with outward vertex normal: side %d" % side)

    _check(game.rooms["reality"].get_node("BedFrame").get_meta("action") == "bed",
        "rounded hardware preserves bed action collider")
    _check(game.rooms["house"].get_node("WakeBell").get_meta("action") == "wake_bell",
        "rounded hardware preserves bell action collider")
    _check(game.rooms["school"].get_node("SealPedestal").get_meta("action") == "seal",
        "rounded hardware preserves seal action collider")
    # Shell materials use world-scale triplanar mapping in every room;
    # furniture retains cheaper box UVs. Requires actual Godot to execute.
    for layer in ["reality", "house", "school"]:
        for shell_name in ["Floor", "North"]:
            var shell_node: Node3D = game.rooms[layer].get_node(shell_name)
            var shell_mesh: MeshInstance3D = null
            for child in shell_node.get_children():
                if child is MeshInstance3D:
                    shell_mesh = child
                    break
            var shell_mat: StandardMaterial3D = shell_mesh.material_override if shell_mesh != null else null
            _check(shell_mat != null and shell_mat.uv1_triplanar and shell_mat.uv1_world_triplanar,
                layer + " " + shell_name + " uses world triplanar mapping")
            _check(shell_mat != null and shell_mat.uv1_scale == Vector3(0.75, 0.75, 0.75),
                layer + " " + shell_name + " has metre-scale texture repeat")
    var bed_mat: StandardMaterial3D = null
    for child in game.rooms["reality"].get_node("BedFrame").get_children():
        if child is MeshInstance3D:
            bed_mat = child.material_override
            break
    _check(bed_mat != null and not bed_mat.uv1_triplanar,
        "small furniture avoids triplanar sampling cost")
    var visual_env: Environment = null
    for child in game.get_children():
        if child is WorldEnvironment:
            visual_env = child.environment
            break
    _check(visual_env != null and visual_env.tonemap_mode == Environment.TONE_MAPPER_ACES,
        "ACES color pipeline is configured")
    # F3 tiers must switch shell shader variants without modifying the
    # original collision shape, action metadata or furniture UV mapping.
    var floor_root: Node3D = game.rooms["reality"].get_node("Floor")
    var floor_mesh: MeshInstance3D = null
    var floor_shape: CollisionShape3D = null
    for child in floor_root.get_children():
        if child is MeshInstance3D:
            floor_mesh = child
        if child is CollisionShape3D:
            floor_shape = child
    var original_floor_shape: Shape3D = floor_shape.shape if floor_shape != null else null
    game.quality = 2
    game._apply_quality()
    # F3 detail LOD is visual-only, reversible and present in every room.
    # Each rounded mesh is unique; neither collision nor action metadata changes.
    var bed_hit: CollisionShape3D = game.rooms["reality"].get_node("BedFrame/CollisionShape3D")
    var original_bed_hit: Shape3D = bed_hit.shape
    for layer in rounded_parts:
        for part_name in rounded_parts[layer]:
            var rounded_mesh: MeshInstance3D = game.rooms[layer].get_node(part_name + "/Visual")
            var cylinder: CylinderMesh = rounded_mesh.mesh as CylinderMesh
            _check(cylinder != null and cylinder.radial_segments == 24,
                layer + " rounded LOD HIGH " + part_name)
    _check(visual_env != null and visual_env.ssao_enabled and visual_env.ssil_enabled,
        "high tier enables indirect contact shading")
    _check(floor_mesh != null and (floor_mesh.material_override as StandardMaterial3D).uv1_triplanar,
        "HIGH restores world triplanar shell mapping")
    game.quality = 0
    game._apply_quality()
    for layer in rounded_parts:
        for part_name in rounded_parts[layer]:
            var rounded_mesh: MeshInstance3D = game.rooms[layer].get_node(part_name + "/Visual")
            var cylinder: CylinderMesh = rounded_mesh.mesh as CylinderMesh
            _check(cylinder != null and cylinder.radial_segments == 8,
                layer + " rounded LOD LOW " + part_name)
    _check(bed_hit.shape == original_bed_hit,
        "rounded LOD preserves original collision shape")
    _check(visual_env != null and not visual_env.ssao_enabled and not visual_env.ssil_enabled,
        "low tier disables expensive screen-space shading")
    _check(floor_mesh != null and not (floor_mesh.material_override as StandardMaterial3D).uv1_triplanar,
        "LOW switches shell to cheap standard UV")
    _check(floor_shape != null and floor_shape.shape == original_floor_shape,
        "F3 mapping does not replace shell collision shape")
    game.quality = 1
    game._apply_quality()
    for layer in rounded_parts:
        for part_name in rounded_parts[layer]:
            var rounded_mesh: MeshInstance3D = game.rooms[layer].get_node(part_name + "/Visual")
            var cylinder: CylinderMesh = rounded_mesh.mesh as CylinderMesh
            _check(cylinder != null and cylinder.radial_segments == 12,
                layer + " rounded LOD MEDIUM " + part_name)
    _check(floor_mesh != null and (floor_mesh.material_override as StandardMaterial3D).uv1_world_triplanar,
        "MEDIUM restores world triplanar after LOW")
    game.quality = 1
    game._apply_quality()

    # Godot 4.3 RayCast3D has add_exception() but NO get_exceptions().
    # Cast a very short ray from inside the capsule to verify self-collision is ignored.
    var probe_ray: RayCast3D = game.player.ray
    var old_target: Vector3 = probe_ray.target_position
    var old_inside: bool = probe_ray.hit_from_inside
    probe_ray.target_position = Vector3(0.0, 0.0, -0.05)
    probe_ray.hit_from_inside = true
    probe_ray.force_raycast_update()
    _check(not probe_ray.is_colliding() or probe_ray.get_collider() != game.player, "interaction ray excludes player collider")
    probe_ray.target_position = old_target
    probe_ray.hit_from_inside = old_inside
    probe_ray.force_raycast_update()
    # Reach must be measured in 3D from the camera, not just in X/Z.
    var eye_origin: Vector3 = probe_ray.global_position
    _check(not game.player._hit_within_reach(eye_origin + Vector3(0, 2, 0), 1.5),
        "vertical offset cannot bypass interaction reach")
    _check(game.player._hit_within_reach(eye_origin + Vector3(0, 0, -1), 1.5),
        "nearby object remains within interaction reach")
    _check(not game.player._hit_within_reach(eye_origin, -1.0),
        "negative reach cannot enable interaction")
    _check(game.overlay.is_dialog_open, "prologue modal")
    game._open_fuses()
    _check(game.active_dialog == "intro" and game.overlay.is_dialog_open,
        "direct fuse builder cannot replace prologue modal")
    game._open_locker()
    _check(game.active_dialog == "intro" and game.overlay.is_dialog_open,
        "direct locker builder cannot replace prologue modal")
    game._wake()
    _check(not game.game_complete and game.current_layer == "reality" and game.overlay.is_dialog_open,
        "direct wake cannot bypass prologue or seal")
    game._fold()
    _check(game.collapse_count == 0 and game.current_layer == "reality",
        "direct fold cannot bypass prologue")
    game._wrong_answer()
    _check(game.stability == 100, "prologue cannot receive direct wrong-answer penalty")
    _check((game.overlay.modal_buttons.get_child(0) as Button).has_focus(), "prologue first button keyboard focus")
    var escape_key := InputEventKey.new()
    escape_key.keycode = KEY_ESCAPE
    escape_key.pressed = true
    game.overlay._input(escape_key)
    _check(game.overlay.is_dialog_open, "Escape cannot skip prologue confirmation")
    game._choice("close")
    _check(game.overlay.is_dialog_open, "direct close cannot bypass prologue confirmation")
    game._start_dive()
    _check(not game.transitioning and game.current_layer == "reality",
        "direct bed dive cannot bypass prologue modal")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    game._choice("intro_start")
    _check(game.overlay.is_dialog_open, "background direct prologue callback ignored")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(0.0)
    game._choice("intro_start")
    _check(game.prologue_step == 1 and not game.overlay.is_dialog_open,
        "cinematic prologue objective starts")
    game._interact("prologue_clock")
    _check(game.prologue_step == 2 and game.active_dialog == "prologue_clock"
        and game.overlay.is_dialog_open,
        "clock interaction requires correct lifecycle")
    game._interact("prologue_clock")
    _check(game.prologue_step == 2 and game.active_dialog == "prologue_clock",
        "stale double clock interaction cannot replace modal")
    game._choice("close")
    _check(not game.overlay.is_dialog_open
        and is_equal_approx(game.prologue_shift_remaining, game.PROLOGUE_SHIFT_SECONDS),
        "clock close begins original reality-shift visual")
    game._process(0.4)
    var clock_rotation: float = game.rooms["reality"].get_node("ClockHand").rotation.z
    _check(clock_rotation < -0.001,
        "prologue visual shift animates a decorative clock hand")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    var shifted_timer: float = game.prologue_shift_remaining
    game._process(0.7)
    _check(is_equal_approx(game.prologue_shift_remaining, shifted_timer)
        and is_equal_approx(game.rooms["reality"].get_node("ClockHand").rotation.z, clock_rotation),
        "prologue shift freezes while unfocused")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(0.0)
    game._process(2.2)
    _check(is_zero_approx(game.prologue_shift_remaining),
        "prologue shift completes after focused play resumes")
    _check(game.rooms["reality"].get_node("PrologueClock").get_meta("action") == "prologue_clock",
        "clock collider remains interactable without modifying bed collider")
    _check(game.rooms["reality"].get_node("BedFrame").get_meta("action") == "bed",
        "prologue keeps bed dive available")
    game._interact("fuses")
    _check(not game.overlay.is_dialog_open, "reject house puzzle in reality")

    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    game._start_dive()
    _check(not game.transitioning and game.current_layer == "reality",
        "background direct dive start is rejected")
    game._interact("bed")
    _check(not game.transitioning and game.current_layer == "reality", "background direct bed interaction ignored")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(0.0)
    # Exercise the 12-second dive state machine without waiting in real time.
    # Simulated focus notifications are NOT a Windows Alt+Tab test.
    game._interact("bed")
    _check(game.transitioning and game.dive_remaining_seconds == 12.0,
        "bed interaction starts focused dive countdown")
    var canceled_token: int = game.transition_token
    game._process(4.0)
    _check(game.transitioning and is_equal_approx(game.dive_remaining_seconds, 8.0),
        "focused dive countdown advances")
    var running_token: int = game.transition_token
    game._start_dive()
    _check(game.transition_token == running_token and is_equal_approx(game.dive_remaining_seconds, 8.0),
        "direct dive restart cannot reset active countdown")
    var cancel_dive := InputEventKey.new()
    cancel_dive.keycode = KEY_R
    cancel_dive.pressed = true
    game._unhandled_input(cancel_dive)
    _check(not game.transitioning and game.dive_remaining_seconds == 0.0 and game.current_layer == "reality",
        "R cancels dive without moving rooms")
    game._interact("bed")
    game._finish_dive(canceled_token)
    _check(game.transitioning and game.current_layer == "reality",
        "stale dive token cannot complete a newer dive")
    game._process(5.0)
    var paused_dive: float = game.dive_remaining_seconds
    # Current-token callbacks must not complete an unfinished focused dive.
    game._finish_dive(game.transition_token)
    _check(game.transitioning and game.current_layer == "reality" and is_equal_approx(game.dive_remaining_seconds, paused_dive),
        "current-token early dive completion is rejected")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    # Test focus guard separately from remaining-time guard: a delayed direct
    # callback with a zero counter must still not move rooms in the background.
    game.dive_remaining_seconds = 0.0
    game._finish_dive(game.transition_token)
    _check(game.transitioning and game.current_layer == "reality" and not game.run_started,
        "background direct dive completion is rejected even at zero seconds")
    game.dive_remaining_seconds = paused_dive
    game._process(120.0)
    _check(game.transitioning and game.current_layer == "reality" and is_equal_approx(game.dive_remaining_seconds, paused_dive),
        "background window cannot complete the 12-second dive")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(120.0)
    _check(game.transitioning and is_equal_approx(game.dive_remaining_seconds, paused_dive),
        "first resume frame cannot consume background dive time")
    game._process(6.9)
    _check(game.transitioning and game.current_layer == "reality",
        "dive waits for remaining foreground time")
    game._process(0.2)
    _check(not game.transitioning and game.run_started and game.current_layer == "house",
        "foreground countdown completes bed to house transition")
    _check(game.elapsed_seconds == 0.0 and game.remaining_seconds == 900.0,
        "dive completion frame does not consume dream time")
    game._fold()
    _check(game.collapse_count == 0 and game.remaining_seconds == 900.0,
        "healthy focused dream cannot be folded directly")
    var echo_stability: int = game.stability
    game._interact("phase_echo")
    _check(game.overlay.is_dialog_open and game.active_dialog == "echo",
        "phase echo displays contextual clue")
    _check(game.stability == echo_stability and game.current_layer == "house",
        "phase echo does not grant stability")
    game._choice("close")
    _check(not game.overlay.is_dialog_open, "phase echo close restores gameplay")
    game.elapsed_seconds = 90.0
    game._update_phase(true)
    _check(game.current_phase == 1 and game.temporal_props[1].collision_layer == 1
        and game.temporal_props[0].collision_layer == 0,
        "only active temporal marker blocks physics raycasts")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    game._interact("phase_echo")
    _check(not game.overlay.is_dialog_open, "phase echo background interaction rejected")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(0.0)
    game.elapsed_seconds = 0.0
    game._update_phase(true)
    game._start_dive()
    _check(not game.transitioning and game.current_layer == "house",
        "direct dive start cannot restart from house")
    # Focus loss must freeze the 15-minute countdown and disable gameplay
    # input. These calls exercise the notification gate, not OS Alt+Tab.
    var focus_elapsed: float = game.elapsed_seconds
    var focus_remaining: float = game.remaining_seconds
    var focus_language: String = game.language
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    game._process(2.0)
    _check(game.elapsed_seconds == focus_elapsed and game.remaining_seconds == focus_remaining,
        "background window does not consume dream timer")
    _check(not game.player.can_move, "background window disables movement")
    var background_stability: int = game.stability
    game.stability = 0
    game._fold()
    _check(game.collapse_count == 0 and game.stability == 0,
        "background direct fold rejected even at zero stability")
    game.stability = background_stability
    var background_position: Vector3 = game.player.global_position
    game.player.velocity = Vector3(3.0, 2.0, -4.0)
    game.player._physics_process(0.5)
    _check(game.player.global_position.is_equal_approx(background_position),
        "background physics cannot drift the player")
    _check(game.player.velocity == Vector3.ZERO,
        "background physics clears residual momentum")
    var language_key := InputEventKey.new()
    language_key.keycode = KEY_F2
    language_key.pressed = true
    game._unhandled_input(language_key)
    _check(game.language == focus_language, "background gameplay key is ignored")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(120.0)
    _check(game.elapsed_seconds == focus_elapsed and game.remaining_seconds == focus_remaining,
        "first resume frame cannot consume background dream time")
    game._process(1.0)
    _check(game.elapsed_seconds > focus_elapsed and game.remaining_seconds < focus_remaining,
        "foreground window resumes dream timer")
    _check(game.player.can_move, "foreground window restores movement")
    game._interact("locker")
    _check(not game.overlay.is_dialog_open, "reject school locker in house")
    game._interact("house_note")
    _check(game.overlay.is_dialog_open, "open note in house")
    var modal_stability: int = game.stability
    game.stability = 0
    game._fold()
    _check(game.collapse_count == 0 and game.overlay.is_dialog_open,
        "open modal blocks direct fold at zero stability")
    game.stability = modal_stability
    game._process(0.0)
    var modal_position: Vector3 = game.player.global_position
    game.player.velocity = Vector3(2.0, -3.0, 1.0)
    game.player._physics_process(0.5)
    _check(game.player.global_position.is_equal_approx(modal_position),
        "open modal freezes character physics")
    _check(game.player.velocity == Vector3.ZERO,
        "open modal clears residual momentum")
    game._open_fuses()
    _check(game.active_dialog == "note" and game.overlay.is_dialog_open,
        "direct fuse builder cannot replace house note modal")
    var note_fuses: Array = game.fuse_values.duplicate()
    game._choice("fuse_0")
    game._choice("fuse_submit")
    _check(game.fuse_values == note_fuses and not game.power_on, "cross-dialog puzzle callback rejected")
    var note_stability: int = game.stability
    game._wrong_answer()
    _check(game.stability == note_stability, "note dialog cannot receive puzzle penalty")
    game._choice("close")
    game._interact("fuses")
    _check(game.overlay.is_dialog_open, "open fuses in house")
    var cancel_fuses: Array = game.fuse_values.duplicate()
    game.overlay._input(escape_key)
    _check(not game.overlay.is_dialog_open, "Escape closes cancellable fuse dialog")
    game._choice("fuse_0")
    _check(game.fuse_values == cancel_fuses, "cancelled dialog cannot mutate puzzle")
    game._interact("fuses")
    var old_generation: int = game.overlay.dialog_generation
    game._choice("close")
    game._interact("fuses")
    var fresh_fuses: Array = game.fuse_values.duplicate()
    game.overlay._choose("fuse_0", old_generation)
    _check(game.fuse_values == fresh_fuses, "stale button generation rejected")
    var redraw_generation: int = game.overlay.dialog_generation
    game._open_fuses()
    _check(game.active_dialog == "fuses" and game.overlay.dialog_generation > redraw_generation,
        "focused active fuse puzzle can redraw its own dialog")
    var background_fuses: Array = game.fuse_values.duplicate()
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    var background_generation: int = game.overlay.dialog_generation
    game._open_fuses()
    _check(game.overlay.dialog_generation == background_generation,
        "background direct puzzle builder cannot redraw modal")
    game._choice("fuse_0")
    _check(game.fuse_values == background_fuses and game.overlay.is_dialog_open,
        "background direct puzzle callback ignored")
    var background_penalty_stability: int = game.stability
    game._wrong_answer()
    _check(game.stability == background_penalty_stability,
        "background direct wrong-answer penalty ignored")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(0.0)
    # Checkpoint JSON may deserialize puzzle numbers as floats. After F9,
    # cycling a fuse must still use integer operands for GDScript's % operator.
    var original_fuses: Array = game.fuse_values.duplicate()
    var loaded_fuses: Dictionary = DreamSaveCodec.decode_checkpoint(
        DreamSaveCodec.encode_checkpoint(DreamSaveCodec.capture(game)))
    _check(not loaded_fuses.is_empty() and typeof(loaded_fuses["fuses"][0]) == TYPE_INT,
        "decoded fuse values are integer typed")
    if not loaded_fuses.is_empty():
        game.fuse_values = loaded_fuses["fuses"].duplicate()
        game._choice("fuse_0")
        _check(typeof(game.fuse_values[0]) == TYPE_INT and game.fuse_values[0] == 1 + (int(original_fuses[0]) % 6),
            "decoded fuse value cycles safely after reload")
        game.fuse_values = original_fuses
        game._open_fuses()
    var before: Array = game.fuse_values.duplicate()
    var wrong_fuse_stability: int = game.stability
    game._choice("fuse_submit")
    _check(game.stability == maxi(0, wrong_fuse_stability - 9) and game.overlay.is_dialog_open,
        "focused wrong fuse submission still costs nine stability")
    game._choice("fuse_99")
    _check(game.fuse_values == before, "invalid fuse index rejected")
    game._choice("fuse_0")
    game._choice("fuse_0")
    game._choice("fuse_2")
    game._choice("fuse_2")
    game._choice("fuse_2")
    game._choice("fuse_submit")
    _check(game.power_on, "fuse solution accepted")
    var solved_stability: int = game.stability
    game._choice("fuse_submit")
    _check(game.stability == solved_stability, "stale fuse callback ignored")
    game._interact("school_door")
    _check(game.current_layer == "school", "school entered")

    game._open_fuses()
    _check(not game.overlay.is_dialog_open,
        "direct fuse builder cannot open in school")
    game._interact("locker")
    _check(game.overlay.modal_code.has_focus(), "locker text entry keyboard focus")
    game.overlay._input(escape_key)
    _check(not game.overlay.is_dialog_open, "Escape closes locker code dialog")
    game.overlay.modal_code.text_submitted.emit("4812")
    _check(not game.locker_open, "Enter after Escape cannot solve locker")
    game._interact("locker")
    var before_locker: int = game.stability
    game._choice("locker_submit:12")
    _check(game.stability == before_locker, "malformed locker code is penalty-free")
    game.overlay.modal_code.text = "4812"
    game.overlay.modal_code.text_submitted.emit("4812")
    _check(game.locker_open, "locker solved by Enter")
    var after_enter_stability: int = game.stability
    game.overlay.modal_code.text_submitted.emit("4812")
    _check(game.stability == after_enter_stability, "stale Enter cannot reward twice")
    game._interact("archive")
    _check(game.archive_found, "archive collected")
    game._interact("seal")
    var symbols_before: Array = game.seal_values.duplicate()
    game._choice("seal_99")
    _check(game.seal_values == symbols_before, "invalid seal index rejected")
    game._choice("seal_1")
    game._choice("seal_2")
    game._choice("seal_2")
    game._choice("seal_3")
    game._choice("seal_3")
    game._choice("seal_3")
    game._choice("seal_submit")
    _check(game.seal_open, "seal solved")
    # Checkpoint codec round-trip (no user save files are written by this smoke).
    var snapshot: Dictionary = DreamSaveCodec.capture(game)
    var decoded: Dictionary = DreamSaveCodec.validated(JSON.parse_string(JSON.stringify(snapshot)))
    _check(not decoded.is_empty(), "valid checkpoint JSON round-trip")
    _check(decoded["archive_found"] and decoded["seal_open"], "checkpoint preserves solved progress")
    var sealed_text: String = DreamSaveCodec.encode_checkpoint(snapshot)
    _check(not sealed_text.is_empty(), "checksum envelope generated")
    var sealed_state: Dictionary = DreamSaveCodec.decode_checkpoint(sealed_text)
    _check(not sealed_state.is_empty() and sealed_state["seal_open"], "checksum envelope round-trip")
    _check(not sealed_state.is_empty() and typeof(sealed_state["seal"][2]) == TYPE_INT,
        "decoded seal values are integer typed")
    var legacy_state: Dictionary = DreamSaveCodec.decode_checkpoint(JSON.stringify(snapshot))
    _check(not legacy_state.is_empty() and typeof(legacy_state["fuses"][1]) == TYPE_INT
        and typeof(legacy_state["seal"][1]) == TYPE_INT,
        "legacy checkpoint puzzle arrays normalize to integers")
    var tampered_envelope: Dictionary = JSON.parse_string(sealed_text)
    var altered_state: Dictionary = snapshot.duplicate(true)
    altered_state["stability"] = 1
    tampered_envelope["data"] = JSON.stringify(altered_state)
    _check(DreamSaveCodec.decode_checkpoint(JSON.stringify(tampered_envelope)).is_empty(),
        "valid-looking modified data fails checksum")
    tampered_envelope.erase("sha256")
    _check(DreamSaveCodec.decode_checkpoint(JSON.stringify(tampered_envelope)).is_empty(),
        "incomplete checksum envelope rejected")
    _check(not DreamSaveCodec.decode_checkpoint(JSON.stringify(snapshot)).is_empty(),
        "legacy checkpoint remains loadable")
    var invalid: Dictionary = snapshot.duplicate(true)
    invalid["power_on"] = false
    _check(DreamSaveCodec.validated(invalid).is_empty(), "reject impossible progress")
    invalid = snapshot.duplicate(true)
    invalid["fuses"] = [3, 9, 4]
    _check(DreamSaveCodec.validated(invalid).is_empty(), "reject out-of-range fuse")
    invalid = snapshot.duplicate(true)
    invalid["elapsed"] = -5.0
    _check(DreamSaveCodec.validated(invalid).is_empty(), "reject negative elapsed")
    # A tampered legacy or checksum-valid checkpoint must not invent puzzle
    # progress that is unreachable through the actual gameplay gates.
    invalid = snapshot.duplicate(true)
    invalid["archive_found"] = false
    invalid["seal_open"] = false
    invalid["seal"] = [0, 1, 0, 0]
    _check(DreamSaveCodec.validated(invalid).is_empty(), "reject seal changes before archive")
    invalid = snapshot.duplicate(true)
    invalid["layer"] = "reality"
    invalid["run_started"] = false
    invalid["game_complete"] = false
    invalid["power_on"] = false
    invalid["locker_open"] = false
    invalid["archive_found"] = false
    invalid["seal_open"] = false
    invalid["elapsed"] = 0.0
    invalid["remaining"] = 900.0
    invalid["stability"] = 100
    invalid["collapse_count"] = 0
    invalid["fuses"] = [2, 1, 1]
    invalid["seal"] = [0, 0, 0, 0]
    _check(DreamSaveCodec.validated(invalid).is_empty(), "reject fuse changes before first dive")
    invalid["fuses"] = [1, 1, 1]
    invalid["seal"] = [0, 1, 0, 0]
    _check(DreamSaveCodec.validated(invalid).is_empty(), "reject seal changes before first dive")
    # F5/F9 exercise the real save/load methods and keyboard dispatch, but
    # only inside the runner's isolated HOME/APPDATA roots (never user data).
    # An unfocused direct call must preserve an existing pending checkpoint.
    var pending_guard_path := "user://dream_layers_save_v1.tmp.json"
    var pending_guard_file := FileAccess.open(pending_guard_path, FileAccess.WRITE)
    _check(pending_guard_file != null, "create pending checkpoint guard fixture")
    if pending_guard_file != null:
        pending_guard_file.store_string("preserve-pending")
        pending_guard_file.close()
        game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
        game._save_game()
        _check(FileAccess.get_file_as_string(pending_guard_path) == "preserve-pending",
            "background direct F5 save cannot overwrite pending checkpoint")
        game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
        game._process(0.0)
        var save_key := InputEventKey.new()
        save_key.keycode = KEY_F5
        save_key.pressed = true
        game._unhandled_input(save_key)
        var real_checkpoint: Dictionary = game._read_checkpoint("user://dream_layers_save_v1.json")
        _check(not real_checkpoint.is_empty() and real_checkpoint["stability"] == snapshot["stability"],
            "focused F5 writes a verified checkpoint")
        game.stability = 3
        var load_key := InputEventKey.new()
        load_key.keycode = KEY_F9
        load_key.pressed = true
        var guard_choices: Array[Dictionary] = [{"id":"close", "label":"Close"}]
        game._dialog("LOAD GUARD", "Keep this modal open", guard_choices, "note")
        game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
        game._unhandled_input(load_key)
        _check(game.stability == 3 and game.overlay.is_dialog_open,
            "background keyboard F9 cannot load or dismiss modal")
        game._load_game()
        _check(game.stability == 3 and game.overlay.is_dialog_open and not game.player.can_move,
            "background direct F9 cannot load or dismiss modal")
        game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
        game._process(0.0)
        game._choice("close")
        game._unhandled_input(load_key)
        _check(game.stability == snapshot["stability"] and game.current_layer == "school",
            "focused F9 restores saved checkpoint and room")
    for save_path in ["user://dream_layers_save_v1.json", "user://dream_layers_save_v1.bak.json",
            pending_guard_path, "user://dream_layers_save_v1.json.rollback"]:
        if FileAccess.file_exists(save_path):
            DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
    # Use a dedicated temporary directory: never touch a player's actual saves.
    var test_dir := "user://dream_layers_smoke_checkpoint_v015"
    var test_dir_abs := ProjectSettings.globalize_path(test_dir)
    _check(DirAccess.make_dir_recursive_absolute(test_dir_abs) == OK, "create isolated checkpoint test directory")
    var primary := test_dir + "/primary.json"
    var backup := test_dir + "/backup.json"
    var temporary := test_dir + "/pending.json"
    var sealed_path := test_dir + "/sealed.json"
    var oversized_path := test_dir + "/oversized.json"
    var oversized_file := FileAccess.open(oversized_path, FileAccess.WRITE)
    _check(oversized_file != null, "create oversized checkpoint fixture")
    if oversized_file != null:
        oversized_file.store_string("X".repeat(16385))
        oversized_file.close()
        _check(game._read_checkpoint(oversized_path).is_empty(), "oversized checkpoint rejected before parsing")
    var sealed_file := FileAccess.open(sealed_path, FileAccess.WRITE)
    _check(sealed_file != null, "open sealed checkpoint fixture")
    if sealed_file != null:
        sealed_file.store_string(sealed_text)
        sealed_file.close()
        _check(not game._read_checkpoint(sealed_path).is_empty(), "read sealed checkpoint from disk")
        var corrupt_file := FileAccess.open(sealed_path, FileAccess.WRITE)
        if corrupt_file != null:
            corrupt_file.store_string(JSON.stringify(tampered_envelope))
            corrupt_file.close()
        _check(corrupt_file != null and game._read_checkpoint(sealed_path).is_empty(),
            "reject incomplete envelope from disk")
    var backup_file := FileAccess.open(backup, FileAccess.WRITE)
    _check(backup_file != null, "create backup test fixture")
    if backup_file != null:
        backup_file.store_string(JSON.stringify(snapshot))
        backup_file.close()
    var primary_file := FileAccess.open(primary, FileAccess.WRITE)
    if primary_file != null:
        primary_file.store_string("{invalid-json")
        primary_file.close()
    var pending_file := FileAccess.open(temporary, FileAccess.WRITE)
    if pending_file != null:
        pending_file.store_string(JSON.stringify(snapshot))
        pending_file.close()
    _check(primary_file != null and pending_file != null, "create primary and pending fixtures")
    if backup_file != null and primary_file != null and pending_file != null:
        _check(game._read_checkpoint(primary).is_empty(), "corrupt primary rejected")
        _check(not game._read_checkpoint(backup).is_empty(), "valid backup accepted")
        var promoted: bool = game._promote_checkpoint(
            ProjectSettings.globalize_path(temporary),
            ProjectSettings.globalize_path(primary),
            ProjectSettings.globalize_path(backup), false)
        _check(promoted, "promote valid pending save over corrupt primary")
        _check(not game._read_checkpoint(primary).is_empty(), "new primary is valid")
        _check(not game._read_checkpoint(backup).is_empty(), "last valid backup preserved")
    # Simulate a crash after primary -> rollback but before pending -> primary.
    # The older backup must not shadow the more recent staged checkpoint.
    var newer: Dictionary = snapshot.duplicate(true)
    newer["elapsed"] = 41.0
    newer["remaining"] = 850.0
    var older: Dictionary = snapshot.duplicate(true)
    older["elapsed"] = 11.0
    older["remaining"] = 880.0
    var old_file := FileAccess.open(backup, FileAccess.WRITE)
    var new_file := FileAccess.open(primary, FileAccess.WRITE)
    if old_file != null and new_file != null:
        old_file.store_string(JSON.stringify(older))
        old_file.close()
        new_file.store_string(JSON.stringify(newer))
        new_file.close()
        var rollback := primary + ".rollback"
        var staged_ok := DirAccess.rename_absolute(ProjectSettings.globalize_path(primary), ProjectSettings.globalize_path(rollback)) == OK
        _check(staged_ok, "simulate interrupted primary rotation")
        if staged_ok:
            var recovered: Dictionary = game._read_recovery_checkpoint(primary, rollback, backup)
            _check(not recovered.is_empty() and recovered["elapsed"] == 41.0, "interrupted promotion prefers rollback")
            var new_pending := FileAccess.open(temporary, FileAccess.WRITE)
            if new_pending != null:
                new_pending.store_string(JSON.stringify(snapshot))
                new_pending.close()
            _check(new_pending != null, "write replacement checkpoint")
            # Restore the staged primary, then verify the full promotion path.
            var restored := DirAccess.rename_absolute(ProjectSettings.globalize_path(rollback), ProjectSettings.globalize_path(primary)) == OK
            _check(restored, "restore staged primary")
            if restored and new_pending != null:
                var promoted_again: bool = game._promote_checkpoint(
                    ProjectSettings.globalize_path(temporary),
                    ProjectSettings.globalize_path(primary),
                    ProjectSettings.globalize_path(backup), true)
                _check(promoted_again, "promote valid checkpoint with previous primary")
                var saved_backup: Dictionary = game._read_checkpoint(backup)
                _check(not saved_backup.is_empty() and saved_backup["elapsed"] == 41.0, "verified promotion updates backup")
                _check(not game._read_checkpoint(primary).is_empty(), "promoted primary stays readable")
    else:
        if old_file != null:
            old_file.close()
        if new_file != null:
            new_file.close()
        _check(false, "create interrupted-rotation fixtures")
    for path in [primary, backup, temporary, primary + ".rollback", sealed_path, oversized_path]:
        if FileAccess.file_exists(path):
            DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
    DirAccess.remove_absolute(test_dir_abs)
    # A valid seal alone does not authorize direct ending from school.
    game._wake()
    _check(not game.game_complete and game.current_layer == "school",
        "direct wake cannot complete from school")
    game._interact("return_house")
    _check(game.current_layer == "house", "returned to house")
    var before_fold: int = game.collapse_count
    game.stability = 0
    game._fold()
    _check(game.collapse_count == before_fold + 1 and game.stability == 35
        and game.remaining_seconds == 180.0 and game.current_layer == "house",
        "exhausted focused dream folds and grants three-minute recovery")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
    game._wake()
    _check(not game.game_complete and game.current_layer == "house",
        "background direct wake cannot complete the game")
    game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_IN)
    game._process(0.0)
    game._interact("wake_bell")
    _check(game.game_complete, "demo completed")
    game._choice("close")
    _check(game.overlay.is_dialog_open, "direct close cannot bypass ending confirmation")
    game._choice("ending")
    var completed_penalty_stability: int = game.stability
    game._wrong_answer()
    _check(game.stability == completed_penalty_stability,
        "completed game cannot receive delayed wrong-answer penalty")
    var completed_folds: int = game.collapse_count
    game.stability = 0
    game._fold()
    _check(game.collapse_count == completed_folds and game.current_layer == "reality",
        "completed game cannot fold from direct callback")
    game._interact("school_door")
    _check(game.current_layer == "reality", "post-completion input rejected")

    print("DREAM LAYERS ENGINE SMOKE: %d checks, %d failures" % [checks, failures])
    # Godot 4.3's headless dummy renderer logs `mesh_get_surface_count:
    # Parameter "m" is null` when a MeshInstance3D is freed while still
    # holding a mesh. Detach meshes before teardown so the runner's strict
    # "no engine errors" gate only sees real failures. Rooms not currently
    # in the tree are included via game.rooms.
    for room in game.rooms.values():
        _release_meshes(room)
    _release_meshes(game)
    for room in game.rooms.values():
        if not room.is_inside_tree():
            room.free()
    # Free children explicitly before the root; letting game.free() cascade
    # still logged one dummy-renderer mesh error in Godot 4.3 headless.
    for child in game.get_children(true):
        child.free()
    game.free()
    await process_frame
    quit(1 if failures > 0 else 0)

func _release_meshes(node: Node) -> void:
    if node is MeshInstance3D:
        (node as MeshInstance3D).mesh = null
    for child in node.get_children(true):
        _release_meshes(child)
