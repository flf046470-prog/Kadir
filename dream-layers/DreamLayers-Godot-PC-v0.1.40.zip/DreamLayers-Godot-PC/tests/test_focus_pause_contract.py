"""Source-level focus/timer guards; not an OS or Godot runtime test."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


def body(name):
    match = re.search(rf"(?m)^func {re.escape(name)}\([^\n]*\).*?:\n", MAIN)
    if match is None:
        raise AssertionError(f"Missing function {name}")
    next_fn = re.search(r"(?m)^func ", MAIN[match.end():])
    return MAIN[match.start():match.end() + next_fn.start() if next_fn else len(MAIN)]


class FocusPauseContract(unittest.TestCase):
    def test_notification_tracks_focus_and_stops_movement(self):
        notification = body("_notification")
        self.assertIn("NOTIFICATION_APPLICATION_FOCUS_OUT", notification)
        self.assertIn("NOTIFICATION_APPLICATION_FOCUS_IN", notification)
        self.assertIn("app_has_focus = false", notification)
        self.assertIn("app_has_focus = true", notification)
        self.assertIn("player.can_move = false", notification)

    def test_timer_and_movement_require_focus(self):
        process = body("_process")
        self.assertIn("run_started and app_has_focus", process)
        self.assertIn("player.can_move = app_has_focus", process)

    def test_background_key_events_rejected_before_shortcuts(self):
        handler = body("_unhandled_input")
        self.assertLess(handler.index("if not app_has_focus:"), handler.index("if event.keycode == KEY_F5:"))

    def test_engine_scenarios_cover_pause_and_resume(self):
        for label in (
            "background window does not consume dream timer",
            "background window disables movement",
            "background gameplay key is ignored",
            "foreground window resumes dream timer",
            "foreground window restores movement",
        ):
            self.assertIn(label, SMOKE)


if __name__ == "__main__":
    unittest.main()
