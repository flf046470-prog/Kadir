"""Static source contract for focus-safe F9 load (NOT a Godot runtime test)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
LOAD = MAIN.split("func _load_game() -> void:", 1)[1].split("func _apply_quality(", 1)[0]
INPUT = MAIN.split("func _unhandled_input(", 1)[1].split("func _save_game(", 1)[0]


class BackgroundLoadContract(unittest.TestCase):
    def test_direct_load_rejects_unfocused_window(self):
        self.assertIn("if not app_has_focus:\n        return", LOAD)
        self.assertLess(LOAD.index("if not app_has_focus:"), LOAD.index("_read_recovery_checkpoint("))

    def test_focus_guard_precedes_modal_dismiss_and_state_changes(self):
        self.assertLess(LOAD.index("if not app_has_focus:"), LOAD.index("overlay.dismiss()"))
        self.assertLess(LOAD.index("if not app_has_focus:"), LOAD.index('language = str(state["language"])'))
        self.assertLess(LOAD.index("if not app_has_focus:"), LOAD.index('_move_to(str(state["layer"]))'))

    def test_keyboard_f9_still_uses_focus_gate(self):
        self.assertLess(INPUT.index("if not app_has_focus:"), INPUT.index("if event.keycode == KEY_F9:"))
        self.assertIn("_load_game()", INPUT)

    def test_engine_smoke_has_negative_and_positive_load_scenarios(self):
        for label in (
            "background keyboard F9 cannot load or dismiss modal",
            "background direct F9 cannot load or dismiss modal",
            "focused F9 restores saved checkpoint and room",
        ):
            self.assertIn(label, SMOKE)


if __name__ == "__main__":
    unittest.main()
