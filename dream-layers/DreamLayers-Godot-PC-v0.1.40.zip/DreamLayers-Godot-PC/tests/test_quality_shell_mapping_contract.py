"""Static F3 shader-cost regression checks (not Godot performance proof)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ROOM = (ROOT / "scripts/room_builder.gd").read_text()
MAIN = (ROOT / "scripts/main.gd").read_text()
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text()


class QualityShellMappingContract(unittest.TestCase):
    def test_low_quality_switches_shells_only(self):
        self.assertIn("DreamRooms.set_shell_mapping(rooms, quality == 0)", MAIN)
        self.assertIn("for label in WORLD_MAPPED_SHELL:", ROOM)
        self.assertIn("var world_mapped := _world_mapped(label)", ROOM)
        self.assertIn("if low_cost_shell:\n        world_mapped = false", ROOM)

    def test_material_cache_separates_shader_variants(self):
        self.assertIn('":world" if world_mapped', ROOM)
        self.assertIn('else ":uv"', ROOM)
        self.assertIn("_pbr_material(label, current.albedo_color, low_cost)", ROOM)

    def test_collision_and_action_shapes_are_unchanged(self):
        self.assertIn("shape.size = size", ROOM)
        self.assertIn('root.set_meta("action", action)', ROOM)
        self.assertIn("mesh.material_override = _pbr_material(label, tint)", ROOM)
        method = ROOM.split("static func set_shell_mapping", 1)[1].split("static func material", 1)[0]
        self.assertNotIn("CollisionShape3D.new", method)
        self.assertNotIn("BoxShape3D.new", method)

    def test_motor_checks_all_quality_transitions(self):
        for expected in (
            "HIGH restores world triplanar shell mapping",
            "LOW switches shell to cheap standard UV",
            "F3 mapping does not replace shell collision shape",
            "MEDIUM restores world triplanar after LOW",
        ):
            self.assertIn(expected, SMOKE)


if __name__ == "__main__":
    unittest.main()
