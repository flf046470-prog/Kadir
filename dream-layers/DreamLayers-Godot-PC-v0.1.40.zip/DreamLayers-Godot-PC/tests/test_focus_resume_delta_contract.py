"""Static focus-resume timer contracts. These do not run Godot or OS Alt+Tab."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


def body(name):
    start = re.search(rf"(?m)^func {re.escape(name)}\([^\n]*\).*?:\n", MAIN)
    if not start:
        raise AssertionError(f"Missing function: {name}")
    next_fn = re.search(r"(?m)^func ", MAIN[start.end():])
    return MAIN[start.start():start.end() + next_fn.start() if next_fn else len(MAIN)]


class FocusResumeDeltaContract(unittest.TestCase):
    def test_focus_loss_arms_one_shot_discard(self):
        self.assertIn("var discard_next_focused_delta := false", MAIN)
        notification = body("_notification")
        loss = notification.split("if what == NOTIFICATION_APPLICATION_FOCUS_OUT:", 1)[1].split("elif what == NOTIFICATION_APPLICATION_FOCUS_IN:", 1)[0]
        self.assertIn("app_has_focus = false", loss)
        self.assertIn("discard_next_focused_delta = true", loss)

    def test_only_first_focused_frame_is_discarded(self):
        process = body("_process")
        self.assertIn("var focused_delta := maxf(0.0, delta)", process)
        guard = process.split("if app_has_focus and discard_next_focused_delta:", 1)[1].split("# Count focused play time", 1)[0]
        self.assertIn("focused_delta = 0.0", guard)
        self.assertIn("discard_next_focused_delta = false", guard)
        self.assertLess(guard.index("focused_delta = 0.0"), guard.index("discard_next_focused_delta = false"))

    def test_both_timers_use_guarded_delta(self):
        process = body("_process")
        self.assertIn("dive_remaining_seconds = maxf(0.0, dive_remaining_seconds - focused_delta)", process)
        self.assertIn("elapsed_seconds += focused_delta", process)
        self.assertIn("remaining_seconds = maxf(0.0, remaining_seconds - focused_delta)", process)
        self.assertNotIn("elapsed_seconds += delta", process)
        self.assertNotIn("remaining_seconds - delta", process)

    def test_engine_smoke_covers_first_resume_frame(self):
        self.assertIn('"first resume frame cannot consume background dive time"', SMOKE)
        self.assertIn('"first resume frame cannot consume background dream time"', SMOKE)
        self.assertEqual(SMOKE.count("game._process(120.0)"), 3)  # background + two resume frames


if __name__ == "__main__":
    unittest.main()
