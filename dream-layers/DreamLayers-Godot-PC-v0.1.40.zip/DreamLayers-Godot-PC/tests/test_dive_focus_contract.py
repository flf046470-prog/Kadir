"""Source-level dive focus/cancellation guards; not a Godot or OS runtime test."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


def body(name):
    match = re.search(rf"(?m)^func {re.escape(name)}\([^\n]*\).*?:\n", MAIN)
    if match is None:
        raise AssertionError(f"Missing function {name}")
    next_fn = re.search(r"(?m)^func ", MAIN[match.end():])
    return MAIN[match.start():match.end() + next_fn.start() if next_fn else len(MAIN)]


class DiveFocusContract(unittest.TestCase):
    def test_dive_duration_and_initial_state(self):
        self.assertIn("const DIVE_SECONDS := 12.0", MAIN)
        self.assertIn("var dive_remaining_seconds := 0.0", MAIN)
        self.assertIn("dive_remaining_seconds = DIVE_SECONDS", body("_start_dive"))

    def test_countdown_is_gated_by_application_focus(self):
        process = body("_process")
        self.assertIn("if transitioning and app_has_focus:", process)
        self.assertIn("dive_remaining_seconds = maxf(0.0, dive_remaining_seconds - focused_delta)", process)
        self.assertLess(process.index("if transitioning and app_has_focus:"), process.index("_finish_dive(transition_token)"))

    def test_no_background_timer_or_dive_frame_time_charge(self):
        self.assertNotIn("create_timer(12.0)", MAIN)
        self.assertNotIn("await get_tree().create_timer", MAIN)
        self.assertIn("var was_transitioning := transitioning", body("_process"))
        self.assertIn("run_started and app_has_focus and not was_transitioning", body("_process"))

    def test_cancel_resets_timer_and_invalidates_token(self):
        keys = body("_unhandled_input")
        cancel = keys.split("if event.keycode == KEY_R and transitioning:", 1)[1].split("if event.keycode == KEY_E", 1)[0]
        for token in ("transition_token += 1", "transitioning = false", "dive_remaining_seconds = 0.0"):
            self.assertIn(token, cancel)

    def test_completion_rejects_stale_token(self):
        finish = body("_finish_dive")
        self.assertIn("token != transition_token or not transitioning or not is_inside_tree()", finish)
        self.assertIn('run_started = true', finish)
        self.assertIn('_move_to("house")', finish)

    def test_engine_smoke_covers_pause_cancel_and_resume(self):
        for label in (
            "bed interaction starts focused dive countdown",
            "R cancels dive without moving rooms",
            "stale dive token cannot complete a newer dive",
            "background window cannot complete the 12-second dive",
            "foreground countdown completes bed to house transition",
            "dive completion frame does not consume dream time",
        ):
            self.assertIn(label, SMOKE)


if __name__ == "__main__":
    unittest.main()
