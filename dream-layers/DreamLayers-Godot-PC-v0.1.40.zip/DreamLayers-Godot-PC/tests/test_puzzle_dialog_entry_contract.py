"""Static puzzle-modal entry guards; Godot smoke must confirm runtime behavior."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
HELPER = MAIN.split("func _can_open_puzzle(action: String, context: String) -> bool:", 1)[1].split("func _open_fuses()", 1)[0]


class PuzzleDialogEntryContract(unittest.TestCase):
    def test_builder_rejects_unfocused_inactive_transition_and_completed_game(self):
        self.assertIn("if not app_has_focus or not run_started or game_complete or transitioning:\n        return false", HELPER)

    def test_builder_requires_correct_action_room(self):
        self.assertIn('if ACTION_LAYERS.get(action, "") != current_layer:\n        return false', HELPER)

    def test_modal_refresh_is_allowed_only_for_same_context(self):
        self.assertIn("return not overlay.is_dialog_open or active_dialog == context", HELPER)
        for name in ("fuses", "locker", "seal"):
            body = MAIN.split(f"func _open_{name}() -> void:", 1)[1].split("\nfunc ", 1)[0]
            self.assertTrue(body.lstrip().startswith(f'if not _can_open_puzzle("{name}", "{name}"):\n        return'))

    def test_motor_smoke_exercises_negative_and_positive_dialog_entries(self):
        for marker in (
            "direct fuse builder cannot replace prologue modal",
            "direct locker builder cannot replace prologue modal",
            "direct fuse builder cannot replace house note modal",
            "focused active fuse puzzle can redraw its own dialog",
            "background direct puzzle builder cannot redraw modal",
            "direct fuse builder cannot open in school",
        ):
            self.assertIn(marker, SMOKE)


if __name__ == "__main__":
    unittest.main()
