"""Source-only regression guards for disabled character physics (not Godot runtime)."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
PLAYER = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


def body(name):
    match = re.search(rf"(?m)^func {re.escape(name)}\([^\n]*\).*?:\n", PLAYER)
    if match is None:
        raise AssertionError(f"Missing player function {name}")
    next_fn = re.search(r"(?m)^func ", PLAYER[match.end():])
    return PLAYER[match.start():match.end() + next_fn.start() if next_fn else len(PLAYER)]


class PlayerFreezeContract(unittest.TestCase):
    def test_disabled_body_exits_before_gravity_and_slide(self):
        physics = body("_physics_process")
        self.assertIn("if not can_move:", physics)
        self.assertLess(physics.index("if not can_move:"), physics.index("if not is_on_floor():"))
        self.assertLess(physics.index("return"), physics.index("move_and_slide()"))

    def test_freeze_clears_all_velocity_components(self):
        physics = body("_physics_process")
        self.assertRegex(physics, r"if not can_move:\s*\n\s*velocity = Vector3.ZERO\s*\n\s*return")

    def test_controller_disables_movement_for_focus_modal_transition_and_end(self):
        self.assertIn("player.can_move = app_has_focus and not overlay.is_dialog_open and not transitioning and not game_complete", MAIN)

    def test_engine_smoke_covers_background_and_modal_physics(self):
        for label in (
            "background physics cannot drift the player",
            "background physics clears residual momentum",
            "open modal freezes character physics",
            "open modal clears residual momentum",
        ):
            self.assertIn(label, SMOKE)


if __name__ == "__main__":
    unittest.main()
