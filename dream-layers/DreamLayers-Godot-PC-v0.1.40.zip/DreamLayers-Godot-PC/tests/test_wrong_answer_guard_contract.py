"""Static penalty-entry contract; in-engine cases require Godot 4.3+."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
PENALTY = MAIN.split("func _wrong_answer() -> void:", 1)[1].split("func _update_phase(", 1)[0]
CHOICE = MAIN.split("func _choice(id: String) -> void:", 1)[1].split("func _open_fuses(", 1)[0]


class WrongAnswerGuardContract(unittest.TestCase):
    def test_requires_focused_active_unblocked_game_and_open_modal(self):
        self.assertIn(
            "if not app_has_focus or not run_started or game_complete or transitioning or not overlay.is_dialog_open:\n        return",
            PENALTY,
        )

    def test_penalty_requires_matching_unsolved_puzzle_in_correct_room(self):
        for fragment in (
            'active_dialog == "fuses" and current_layer == "house" and not power_on',
            'active_dialog == "locker" and current_layer == "school" and power_on and not locker_open',
            'active_dialog == "seal" and current_layer == "school" and archive_found and not seal_open',
            'if not active_puzzle:\n        return',
        ):
            self.assertIn(fragment, PENALTY)

    def test_guards_precede_penalty_and_legitimate_submits_still_call_it(self):
        self.assertLess(PENALTY.index("not app_has_focus"), PENALTY.index("stability = maxi("))
        self.assertLess(PENALTY.index("if not active_puzzle"), PENALTY.index("stability = maxi("))
        self.assertEqual(CHOICE.count("_wrong_answer()"), 3)

    def test_motor_smoke_contains_negative_and_positive_penalty_cases(self):
        for marker in (
            "prologue cannot receive direct wrong-answer penalty",
            "note dialog cannot receive puzzle penalty",
            "background direct wrong-answer penalty ignored",
            "focused wrong fuse submission still costs nine stability",
            "completed game cannot receive delayed wrong-answer penalty",
        ):
            self.assertIn(marker, SMOKE)


if __name__ == "__main__":
    unittest.main()
