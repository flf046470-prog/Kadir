"""Source-contract tests for v0.1.7 checksum envelope (NOT engine execution)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
CODEC = (ROOT / "scripts/save_codec.gd").read_text(encoding="utf-8")
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class ChecksumEnvelopeContract(unittest.TestCase):
    def test_envelope_contains_format_payload_and_digest(self):
        self.assertIn('const ENVELOPE_FORMAT := "DL_CHECKPOINT_SHA256_V1"', CODEC)
        self.assertIn('"format": ENVELOPE_FORMAT, "data": data, "sha256": data.sha256_text()', CODEC)

    def test_checksum_verified_before_decoding_payload(self):
        decode = CODEC.split('static func decode_checkpoint(text: String)', 1)[1]
        self.assertLess(decode.index('raw["sha256"] != data.sha256_text()'),
                        decode.index('return validated(_parse_json(data))'))

    def test_incomplete_envelopes_do_not_fall_back_to_legacy(self):
        decode = CODEC.split('static func decode_checkpoint(text: String)', 1)[1]
        self.assertIn('if raw.has("format") or raw.has("data") or raw.has("sha256"):', decode)
        self.assertIn('if raw.size() != 3 or raw.get("format") != ENVELOPE_FORMAT:', decode)
        self.assertIn('if typeof(raw.get("data")) != TYPE_STRING or typeof(raw.get("sha256")) != TYPE_STRING:', decode)
        self.assertLess(decode.index('if raw.has("format")'), decode.index('return validated(raw)'))

    def test_save_and_load_use_codec_not_plain_json(self):
        save = MAIN.split('func _save_game() -> void:', 1)[1].split('func _promote_checkpoint(', 1)[0]
        read = MAIN.split('func _read_checkpoint(path: String)', 1)[1].split('func _load_game()', 1)[0]
        self.assertIn('var encoded := DreamSaveCodec.encode_checkpoint(payload)', save)
        self.assertIn('file.store_string(encoded)', save)
        self.assertIn('encoded.to_utf8_buffer().size() > MAX_SAVE_BYTES', save)
        self.assertIn('return DreamSaveCodec.decode_checkpoint(contents)', read)

    def test_engine_smoke_covers_tampering_and_legacy(self):
        for phrase in (
            '"checksum envelope round-trip"',
            '"valid-looking modified data fails checksum"',
            '"incomplete checksum envelope rejected"',
            '"legacy checkpoint remains loadable"',
            '"read sealed checkpoint from disk"',
            '"reject incomplete envelope from disk"',
        ):
            self.assertIn(phrase, SMOKE)

    def test_not_misrepresented_as_authentication(self):
        self.assertIn('This is NOT authentication', CODEC)


if __name__ == '__main__':
    unittest.main()
