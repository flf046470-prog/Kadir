"""Static F3 decorative LOD contracts. Godot rendering is NOT executed."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ROOM = (ROOT / 'scripts/room_builder.gd').read_text(encoding='utf-8')
MAIN = (ROOT / 'scripts/main.gd').read_text(encoding='utf-8')
SMOKE = (ROOT / 'tests/godot_flow_smoke.gd').read_text(encoding='utf-8')


class RoundedLodContract(unittest.TestCase):
    def test_decorations_have_stable_visual_identity(self):
        method = ROOM.split('static func rounded_detail', 1)[1].split('static func set_rounded_detail_lod', 1)[0]
        self.assertIn('root.add_to_group("dream_rounded_details")', method)
        self.assertIn('mesh.name = "Visual"', method)
        self.assertIn('cylinder.radial_segments = 12', method)

    def test_three_quality_tiers_change_segment_count(self):
        method = ROOM.split('static func set_rounded_detail_lod', 1)[1].split('static func light', 1)[0]
        for part in ('8 if quality_level == 0', '24 if quality_level == 2 else 12',
                     'detail.is_in_group("dream_rounded_details")',
                     'visual.mesh as CylinderMesh', 'cylinder.radial_segments = segments'):
            self.assertIn(part, method)

    def test_lod_does_not_touch_colliders_or_actions(self):
        method = ROOM.split('static func set_rounded_detail_lod', 1)[1].split('static func light', 1)[0]
        for forbidden in ('CollisionShape3D', 'StaticBody3D', 'set_meta(', 'collision_layer',
                          'material_override', 'BoxMesh.new()'):
            self.assertNotIn(forbidden, method)
        self.assertIn('DreamRooms.set_rounded_detail_lod(rooms, quality)', MAIN)

    def test_engine_smoke_covers_all_layers_and_reversible_tiers(self):
        for part in ('rounded LOD HIGH', 'rounded LOD LOW', 'rounded LOD MEDIUM',
                     'rounded LOD preserves original collision shape',
                     'for layer in rounded_parts:'):
            self.assertIn(part, SMOKE)


if __name__ == '__main__':
    unittest.main()
