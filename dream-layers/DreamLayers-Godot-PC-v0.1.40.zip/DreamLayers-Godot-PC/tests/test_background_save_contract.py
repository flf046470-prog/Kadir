"""Source-only contract: F5 cannot write checkpoints from an unfocused window."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")
SAVE = MAIN.split("func _save_game() -> void:", 1)[1].split("func _promote_checkpoint(", 1)[0]


class BackgroundSaveContract(unittest.TestCase):
    def test_direct_save_rejects_unfocused_window(self):
        self.assertIn("if not app_has_focus:\n        return", SAVE)
        self.assertLess(SAVE.index("if not app_has_focus:"), SAVE.index("DreamSaveCodec.capture(self)"))

    def test_focus_guard_precedes_truncating_write(self):
        self.assertLess(SAVE.index("if not app_has_focus:"),
                        SAVE.index("FileAccess.open(TEMP_FILE, FileAccess.WRITE)"))

    def test_keyboard_save_and_load_keep_existing_focus_gate(self):
        INPUT = MAIN.split("func _unhandled_input(", 1)[1].split("func _save_game(", 1)[0]
        self.assertLess(INPUT.index("if not app_has_focus:"), INPUT.index("if event.keycode == KEY_F5:"))
        self.assertIn("if event.keycode == KEY_F9:", INPUT)

    def test_engine_smoke_covers_pending_guard_and_actual_f5_f9(self):
        for expected in (
            "background direct F5 save cannot overwrite pending checkpoint",
            "focused F5 writes a verified checkpoint",
            "focused F9 restores saved checkpoint and room",
            "preserve-pending",
        ):
            self.assertIn(expected, SMOKE)


if __name__ == "__main__":
    unittest.main()
