"""Static guardrails for unreachable save states; NOT Godot execution."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
CODEC = (ROOT / "scripts/save_codec.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class CheckpointProgressContract(unittest.TestCase):
    def test_pre_dive_fuses_must_be_initial(self):
        pre_dive = CODEC.split('if not raw["run_started"]:', 1)[1].split('elif raw["layer"]', 1)[0]
        self.assertIn('fuses != [1, 1, 1]', pre_dive)
        self.assertIn('return {}', pre_dive)

    def test_pre_dive_seal_must_be_initial(self):
        pre_dive = CODEC.split('if not raw["run_started"]:', 1)[1].split('elif raw["layer"]', 1)[0]
        self.assertIn('seal != [0, 0, 0, 0]', pre_dive)
        self.assertIn('return {}', pre_dive)

    def test_archive_gates_seal_mutation(self):
        self.assertIn('if not raw["archive_found"] and seal != [0, 0, 0, 0]:', CODEC)

    def test_engine_scenarios_for_invalid_partial_progress(self):
        for case in [
            '"reject seal changes before archive"',
            '"reject fuse changes before first dive"',
            '"reject seal changes before first dive"',
        ]:
            self.assertIn(case, SMOKE)


if __name__ == "__main__":
    unittest.main()
