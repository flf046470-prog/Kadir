"""Static keyboard cancellation contracts; NOT a Godot runtime test."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
OVERLAY = (ROOT / "scripts/overlay.gd").read_text(encoding="utf-8")
SMOKE = (ROOT / "tests/godot_flow_smoke.gd").read_text(encoding="utf-8")


class KeyboardCancelContract(unittest.TestCase):
    def test_only_explicit_close_choice_enables_cancel(self):
        dialog = OVERLAY.split("func dialog(", 1)[1].split("func dialog_code(", 1)[0]
        self.assertIn('if str(choice.get("id", "")) == "close":', dialog)
        self.assertIn("dialog_can_cancel = true", dialog)
        self.assertIn("dialog_can_cancel = false", dialog)

    def test_escape_uses_guarded_close_action(self):
        handler = OVERLAY.split("func _input(", 1)[1].split("func _submit_locker_from_keyboard(", 1)[0]
        self.assertIn("not is_dialog_open or not dialog_can_cancel", handler)
        self.assertIn("event is InputEventKey and event.pressed and not event.echo", handler)
        self.assertIn("event.keycode == KEY_ESCAPE", handler)
        self.assertIn('_choose("close", dialog_generation)', handler)
        self.assertNotIn("dismiss()", handler)

    def test_cancel_state_clears_on_dismiss(self):
        dismiss = OVERLAY.split("func dismiss(", 1)[1]
        self.assertIn("dialog_can_cancel = false", dismiss)
        self.assertIn("dialog_generation += 1", dismiss)

    def test_engine_smoke_covers_cancel_and_no_stale_action(self):
        for expected in [
            '"Escape cannot skip prologue confirmation"',
            '"Escape closes cancellable fuse dialog"',
            '"cancelled dialog cannot mutate puzzle"',
            '"Escape closes locker code dialog"',
            '"Enter after Escape cannot solve locker"',
        ]:
            self.assertIn(expected, SMOKE)


if __name__ == "__main__":
    unittest.main()
