"""Original, deterministic Dream Layers design-lab model for observation events.

NOT third-party code, a Godot gameplay module, analytics, or measured player behavior.
The playable game remains unchanged. It lets designers test pacing constraints
before writing a Godot event director.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import argparse
import json
import random
from statistics import mean, median
from typing import Iterable

EVENT_TYPES = ("prop_shift", "sound_offset", "clock_mismatch", "false_echo")


@dataclass(frozen=True)
class Event:
    phase: int
    kind: str


@dataclass(frozen=True)
class LoopReport:
    simulated_runs: int
    mean_events_per_run: float
    median_first_event_seconds: float
    max_events_per_run: int
    kind_counts: dict[str, int]


def schedule_events(seed: int, *, phase_count: int = 6, phase_seconds: int = 90,
                    probability: float = 0.48, min_empty_phases: int = 1,
                    max_events: int = 3) -> tuple[Event, ...]:
    """Return scheduled *hypothetical* anomaly events, not game events.

    First phase is deliberately safe for onboarding. A fallback prevents a
    completely empty run. Cooldowns and a cap make every decision inspectable.
    Separate seeded Random prevents touching game/global RNG state.
    """
    if not 2 <= phase_count <= 24:
        raise ValueError("phase_count must be 2..24")
    if phase_seconds <= 0:
        raise ValueError("phase_seconds must be positive")
    if not 0.0 <= probability <= 1.0:
        raise ValueError("probability must be 0..1")
    if not 0 <= min_empty_phases < phase_count:
        raise ValueError("invalid min_empty_phases")
    if not 1 <= max_events <= phase_count - 1:
        raise ValueError("invalid max_events")

    rng = random.Random(seed)
    events: list[Event] = []
    previous_phase = -min_empty_phases - 1
    for phase in range(1, phase_count):
        if len(events) >= max_events:
            break
        if phase - previous_phase <= min_empty_phases:
            continue
        if rng.random() < probability:
            events.append(Event(phase, EVENT_TYPES[rng.randrange(len(EVENT_TYPES))]))
            previous_phase = phase
    if not events:
        # Always give the player at least one *opportunity* to notice a change.
        events.append(Event(min(3, phase_count - 1), EVENT_TYPES[rng.randrange(len(EVENT_TYPES))]))
    return tuple(events)


def evaluate(seeds: Iterable[int], **kwargs: object) -> LoopReport:
    """Evaluate ONLY simulated pacing, not actual engagement/virality."""
    samples = [schedule_events(seed, **kwargs) for seed in seeds]
    if not samples:
        raise ValueError("at least one seed is required")
    counts = {name: 0 for name in EVENT_TYPES}
    for sample in samples:
        for event in sample:
            counts[event.kind] += 1
    phase_seconds = int(kwargs.get("phase_seconds", 90))
    return LoopReport(
        simulated_runs=len(samples),
        mean_events_per_run=mean(len(x) for x in samples),
        median_first_event_seconds=median(x[0].phase * phase_seconds for x in samples),
        max_events_per_run=max(len(x) for x in samples),
        kind_counts=counts,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=1000)
    parser.add_argument("--probability", type=float, default=0.48)
    args = parser.parse_args()
    print(json.dumps(asdict(evaluate(range(args.runs), probability=args.probability)), indent=2))
