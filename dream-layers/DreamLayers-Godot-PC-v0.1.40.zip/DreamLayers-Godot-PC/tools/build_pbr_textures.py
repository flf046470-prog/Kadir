"""Deterministic tileable 512px PBR placeholder surfaces for all Dream Layers rooms.

Not scans or 8K. These are small original material studies; replace with
licensed, measured photo/scan assets at production time. Requires numpy/Pillow
only for regeneration, not for playing the game.
"""
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'assets' / 'pbr'
SIZE = 512
rng = np.random.default_rng(1701)
x = np.arange(SIZE, dtype=np.float32)[None, :]
y = np.arange(SIZE, dtype=np.float32)[:, None]


def smooth_noise(size, strength):
    # Tileable 2D value noise, bilinearly interpolated periodically.
    cells = rng.normal(0, 1, (size, size)).astype(np.float32)
    step = SIZE // size
    iy = np.arange(SIZE) / step
    ix = np.arange(SIZE) / step
    xi, yi = np.floor(ix).astype(int) % size, np.floor(iy).astype(int) % size
    tx, ty = (ix - np.floor(ix))[None, :], (iy - np.floor(iy))[:, None]
    tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
    a = cells[yi[:, None], xi[None, :]]
    b = cells[yi[:, None], (xi + 1)[None, :] % size]
    c = cells[(yi + 1)[:, None] % size, xi[None, :]]
    d = cells[(yi + 1)[:, None] % size, (xi + 1)[None, :] % size]
    return ((a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty) * strength


def save_image(path, data):
    Image.fromarray(np.clip(data, 0, 255).astype(np.uint8), 'RGB').save(path, optimize=True)


def build(kind):
    low = smooth_noise(8, 0.8)
    med = smooth_noise(32, 0.38)
    micro = rng.normal(0, .08, (SIZE, SIZE)).astype(np.float32)
    variation = low + med + micro
    if kind == 'wood':
        grain = np.sin(2 * np.pi * (y / 37 + np.sin(x / 29) * .21)) * .25
        grain += np.sin(2 * np.pi * (y / 11 + np.sin(x / 47) * .32)) * .09
        height = variation * .25 + grain
        rough = .66 + variation * .035 + grain * .12
    elif kind == 'fabric':
        weave = (np.sin(2 * np.pi * x / 8) + np.cos(2 * np.pi * y / 8)) * .12
        height = weave + variation * .06
        rough = .87 + variation * .025 + weave * .06
    elif kind == 'metal':
        scratches = np.sin(2 * np.pi * (y / 3.5 + .02 * np.sin(x / 44))) * .035
        height = variation * .045 + scratches
        rough = .40 + variation * .025 + scratches * .07
    elif kind == 'stone':
        fractures = np.abs(np.sin(2 * np.pi * (x / 171 + y / 254 + low * .12))) ** 13
        height = variation * .22 - fractures * .16
        rough = .79 + variation * .035 + fractures * .06
    else:  # painted plaster
        height = variation * .12
        rough = .89 + variation * .022
    height = height.astype(np.float32)
    # Neutral albedo intentionally preserves per-object authored true-to-life tint.
    grayscale = np.clip(225 + height * 15, 192, 246)
    albedo = np.stack([grayscale] * 3, axis=2)
    rough_rgb = np.stack([np.clip(rough * 255, 0, 255)] * 3, axis=2)
    dy = (np.roll(height, -1, axis=0) - np.roll(height, 1, axis=0)) * .4
    dx = (np.roll(height, -1, axis=1) - np.roll(height, 1, axis=1)) * .4
    normal = np.stack([-dx, -dy, np.ones_like(dx)], axis=2)
    normal /= np.linalg.norm(normal, axis=2, keepdims=True)
    normal = (normal * .5 + .5) * 255
    for suffix, img in [('albedo', albedo), ('roughness', rough_rgb), ('normal', normal)]:
        save_image(OUTPUT / f'{kind}_{suffix}.png', img)


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for kind in ('plaster', 'wood', 'fabric', 'metal', 'stone'):
        build(kind)
    print('Generated 15 deterministic 512px material textures. No 8K/photogrammetry claim.')


if __name__ == '__main__':
    main()
