"""Build a reproducible source-only ZIP, run static tests before/after extraction.

This is NOT a Godot runtime test and does not create a Windows executable.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_ROOT = "DreamLayers-Godot-PC"
FIXED_TIME = (2026, 10, 13, 0, 0, 0)


def source_files():
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if path == ROOT / 'docs' / 'MANIFEST.json':
            continue
        if any(p in {'.godot', '.git', '__pycache__'} for p in relative.parts):
            continue
        if path.suffix in {'.pyc', '.tmp'}:
            continue
        yield path


def check(root: Path):
    commands = [
        [sys.executable, 'tests/check_project.py'],
        [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py', '-q'],
        [sys.executable, 'tests/verify_manifest.py'],
    ]
    for command in commands:
        subprocess.run(command, cwd=root, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--godot-runtime-tested', action='store_true',
                        help='Only after tests/run_godot_smoke.py --require-engine printed PASS')
    args = parser.parse_args()
    if not args.version.startswith('0.'):
        parser.error('Expected a development source version')
    subprocess.run([sys.executable, 'tests/check_project.py'], cwd=ROOT, check=True)
    subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py', '-q'], cwd=ROOT, check=True)
    files = list(source_files())
    inventory = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    manifest = {
        'name': 'Dream Layers | First Awakening',
        'version': args.version + '-source',
        'engine': 'Godot 4.3+',
        'source_only': True,
        'godot_runtime_tested': args.godot_runtime_tested,
        'files': inventory,
    }
    (ROOT / 'docs' / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    check(ROOT)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(args.out, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for file in sorted([*files, ROOT / 'docs' / 'MANIFEST.json']):
            relative = file.relative_to(ROOT).as_posix()
            info = ZipInfo(f'{ARCHIVE_ROOT}/{relative}', date_time=FIXED_TIME)
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, file.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(args.out) as archive:
        assert archive.testzip() is None, 'ZIP CRC check failed'
        with tempfile.TemporaryDirectory(prefix='dreamlayers-verify-') as tmp:
            base = Path(tmp).resolve()
            for member in archive.infolist():
                dest = (base / member.filename).resolve()
                assert dest.is_relative_to(base), 'Unsafe ZIP path'
            archive.extractall(base)
            check(base / ARCHIVE_ROOT)
    print(f'PASS: {len(inventory)}/{len(inventory)} SHA manifest files and extracted ZIP tests')
    print('ZIP:', args.out)
    print('SHA-256:', hashlib.sha256(args.out.read_bytes()).hexdigest())
    print('RUNTIME:', 'Godot headless smoke PASS recorded' if args.godot_runtime_tested else 'NOT RUN (source-only package)')


if __name__ == '__main__':
    main()
