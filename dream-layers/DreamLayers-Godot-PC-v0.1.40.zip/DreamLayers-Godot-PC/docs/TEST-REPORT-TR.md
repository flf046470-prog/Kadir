## v0.1.40 — Giriş/raycast motor testi (16 Ekim 2026)

- `run_godot_smoke.py --require-engine` (Godot 4.3-stable headless): import/parse temiz; akış 232/0; **giriş ve raycast 13/0**; PASS.
- Mutasyon kontrolü: iki kontrol kasıtlı bozuldu → runner 2 FAIL raporladı.
- Python 191/191 PASS.

## v0.1.39 — İlk gerçek motor testi (16 Ekim 2026)

- Motor: `Godot_v4.3-stable_linux.x86_64` (4.3.stable.official.77dcf97d8), `--headless`.
- `GODOT_BIN=<yol> python3 tests/run_godot_smoke.py --require-engine` → **PASS**: import/parse temiz; `DREAM LAYERS ENGINE SMOKE: 232 checks, 0 failures`; çıktıda SCRIPT ERROR / ERROR yok.
- Düzeltmeden önceki ilk sonuç: **FAIL import/parse** (main.gd `tr()` imza çakışması, save_codec.gd ve smoke tip çıkarımı). Ardından: yatak collider düğüm adı, F9 ilerleme kaydının float/int dizi karşılaştırması yüzünden reddedilmesi, typed array çağrısı, JSON parse ERROR satırı, headless mesh teardown hatası.
- Python `python3 -m unittest discover -s tests -p 'test_*.py'`: **190/190 PASS**; `tests/check_project.py` PASS.
- Kapsam dışı: dummy renderer görüntü çizmez → görsel kalite, GPU/FPS, gerçek OS Alt+Tab, Windows EXE ve fiziksel giriş doğrulanmadı.

## v0.1.38 — prolog + viral döngü araştırması (14 Ekim 2026)

- `tests/test_cinematic_prologue_contract.py`: 6 kaynak sözleşmesi / güvenlik kontrolü (gerçek motor değildir).
- `tests/test_viral_loop_lab.py`: 7 deterministik Python model testi; `tools/viral_loop_lab.py` oyuna henüz entegre edilmeyen tasarım laboratuvarıdır.
- Toplam `python3 -m unittest discover -s tests -p 'test_*.py' -q`: **184/184 PASS**.
- `tests/godot_flow_smoke.gd`: prolog başlangıcı/saat/odak/animasyon/bed geriye dönük uyumluluk kontrolleri eklendi; **motor olmadığı için NOT RUN**.
- `tests/check_project.py`, manifest, ZIP CRC ve temiz ZIP çıkarma sonrası testleri paketleme sırasında kontrol edilecek.
- Hiçbir gerçek Godot motor, film/kamera render, ses karışımı, Windows EXE veya performans ölçümü yapılmadı.

## v0.1.37 — Mesh yüzey yönü kaynak testi

- Godot'un saat yönündeki ön yüz kuralı için bevel indeks sırası düzeltildi; 6 yüzün yönüne ait matematiksel statik testler eklendi.
- `tests/test_bevel_winding_contract.py`: 5 Python testi. `tests/godot_flow_smoke.gd`: her yüzün iç üçgen yönü + BoxShape3D koruması eklendi, **gerçek Godot binary mevcut olmadığından yürütülmedi**.
- Kaynak regresyonları, manifest, ZIP bütünlüğü, çıkarılmış ZIP tekrar testleri yeni paket üzerinde çalıştırılmalıdır. Motor, FPS, VRAM, Windows EXE kanıtı değildir.

## v0.1.36 — Zaman yankısı kaynak doğrulaması

- `tests/test_phase_echo_contract.py`: beş kaynak sözleşme kontrolü (6 işaret/eylem kapısı, faz dışı raycast maskesi, kayıt uyumluluğu, Godot smoke niyet kontrolleri).
- `tests/test_action_gate_contract.py` eski 9 eylem sabiti yeni 10 eylem haritasına göre güncellendi.
- Godot smoke: prolog kapısı, odakta açma, denge değişmeme, faz switch collider, arka plan engeli. Motor yürütme kanıtı değildir.
- Godot 4.3+ motoru mevcut değil; gerçek GDScript parse ve FPS/EXE sonuçları NOT RUN.

## v0.1.35 — 14 Ekim 2026 | Bevel mesh ve önceki LOD sözleşmelerinin beraber korunması

- Canonical v0.1.34 kaynak manifesti ve ZIP hash doğrulamasından sonra temel kaynak üzerine küçük görsel iyileştirme eklendi.
- 5 yeni Python kaynak/matematik referans testiyle hedef **161/161**; `tests/godot_flow_smoke.gd` üç odada ArrayMesh/BoxShape3D/cache kontrolü eklendi (motor olmadan **NOT RUN**).
- Godot 4.3+ binary yok: `python3 tests/run_godot_smoke.py --require-engine` gerçek import/runtime sonucu veremedi. Windows export ve GPU/FPS/VRAM, F5/F9 motor I/O, multiplayer henüz kanıtlanmadı.

## v0.1.34 — 14 Ekim 2026 | Dekoratif LOD kaynak regresyonu

- `tests/test_rounded_lod_contract.py`: 4 yeni **statik** Python kontrolü, toplam **156/156 PASS**. `tests/godot_flow_smoke.gd`: Gerçeklik/Ev/Okul'da 24→8→12 segment geçişi ve yatak collider kimliği senaryoları **yazıldı fakat çalıştırılmadı**.
- `python3 tests/check_project.py` PASS. Manifest/ZIP CRC/çıkarılmış ZIP tekrar testleri paketleme sırasında çalıştırılır.
- Godot 4.3+ binary yok: `python3 tests/run_godot_smoke.py --require-engine` **NOT RUN / exit 1**. Gerçek Godot parse, Windows EXE, F5/F9 dosya I/O, GPU/FPS/VRAM, multiplayer **YAPILMADI**. Ölçülmüş performans kazanımı yok.

## v0.1.33 — 14 Ekim 2026 | Görsel-only silindir donanım

- `tests/test_rounded_hardware_contract.py`: 4 yeni **statik** kaynak regresyonu (toplam 152 hedef). `tests/godot_flow_smoke.gd`: üç odada CylinderMesh ve collision-free ayrıntı, yatak/çan/mühür aksiyonlarının korunması için yeni motor kontrolleri.
- `python3 tests/run_godot_smoke.py --require-engine`: Godot binary yok, **NOT RUN / exit 1**. Motor import, gerçek render, Windows EXE, F5/F9 I/O, GPU/FPS/VRAM **YAPILMADI**. Kaynak/manifest/ZIP testleri motor kanıtı değildir.

## v0.1.32 — 14 Ekim 2026 | Shader kalite geçişi

- `tests/test_quality_shell_mapping_contract.py`: 4 statik regresyon. `tests/godot_flow_smoke.gd`: üç F3 tier materyal geri dönüşü ve collision shape kimliği motor kontrolü.
- Motor binary yok: `python3 tests/run_godot_smoke.py --require-engine` NOT RUN; GPU performansı ölçülmedi.

# Test / dürüst kanıt kaydı

| Kontrol | Durum | Açıklama |
| --- | --- | --- |
| Dosya varlığı, proje referansları | Otomatik statik test | `python3 tests/check_project.py` |
| Prolog, lokalizasyon anahtarları, etkileşim sabitleri | Otomatik statik test | Kaynak metinde doğrulama; motor yürütümü değil |
| GDScript parse ve Godot import | **YAPILMADI** | Godot editörü mevcut değil |
| Playable PIE/oyun döngüsü | **YAPILMADI** | Donanımlı motor ortamı gerekli |
| Windows `.exe` dışa aktarma | **YAPILMADI** | Windows export templates gerekli |
| GPU FPS/frametime | **YAPILMADI** | Gerçek ekran kartı ve hedef donanım gerekli |
| Gerçek multiplayer/Steam/Epic entegrasyonu | **YAPILMADI** | Ağ servisi, hesap ve mağaza ortamı gerekli |

Bu projedeki yeni testlerin sonuçları önceki Dream Layers C++/UE raporlarıyla **karıştırılmamalıdır**. Önceki raporlardaki 655 C++ testi bu yeni Godot uygulamasında çalıştırılmamıştır.

## v0.1.1 kontrolü (13 Ekim 2026)

- `python3 tests/check_project.py`: PASS (statik dosya/sözleşme).
- `python3 -m unittest discover -s tests -p 'test_*.py' -v`: **9/9 PASS** (statik kaynak regresyonu).
- Yeni dört rakamlı giriş, ışın temas menzili ve oyun sonu hareket kilidi gerçek Godot motorunda çalıştırılmadı.
- FPS/frametime karşılaştırması: **ölçülmedi**.

## v0.1.2 kaynak regresyonu (13 Ekim 2026)

- Başlangıç v0.1.1 SHA-256 eşleşti: `c20510db627527e5eae98ce0ac621a423b9d58db39c007c4db8fb3e9987ed97d`.
- `python3 tests/check_project.py`: **PASS** (statik sözleşme).
- `python3 -m unittest discover -s tests -p 'test_*.py' -v`: **16/16 PASS** (9 önceki + 7 yeni statik kaynak testi).
- `python3 tests/run_godot_smoke.py`: **NOT RUN**, çıkış kodu 2; Godot 4.3+ bulunamadı. Bu test gerçek Godot ile çalıştırıldığında import/parse ve oyun durum akışını sınar; şu an için başarı iddiası yoktur.
- SHA-256 manifesti ve ZIP çıkarma sonrası tekrar testler: **PASS** (paketleme kontrolü).
- GPU/FPS farkı: **ölçülmedi**; grafik kodu bu sürümde değişmedi.
- Gerçek etkileşim güvenliği, UI callback yaşam döngüsü, fiziksel raycast ve klavye smoke'u: **motor kabulü bekliyor**.

## v0.1.3 kaynak regresyonu (13 Ekim 2026)

- Kaynak v0.1.2 ZIP SHA-256: `f4d9f771b6b9fd4884bc07649d6473128c4e3d2884814a432048238013c4d1e6` **eşleşti**.
- `python3 tests/check_project.py`: **PASS** (statik kaynak).
- `python3 -m unittest discover -s tests -p 'test_*.py' -v`: **20/20 PASS** (4 yeni statik diyalog regresyonu).
- `tests/godot_flow_smoke.gd` içinde çapraz-diyalog ve eski nesil callback kontrolleri eklendi; **motor olmadığı için çalıştırılmadı**.
- Godot executable bulunamadı; GitHub DNS çözümlemesi başarısız. Gerçek headless import/parse, UI/oyun, Windows EXE ve GPU/FPS: **YAPILMADI**.
- `python3 tests/verify_manifest.py` ve ZIP çıkarıldıktan sonraki aynı kaynak testleri: **PASS**.
- Grafik/performance değişikliği yok; FPS farkı **ölçülmedi**.

## v0.1.4 (13 Ekim 2026)

- `DreamSaveCodec` checkpoint şeması, kaydetme/yükleme akışı ve 8 statik sözleşme testi eklendi.
- Godot smoke betiğine JSON round-trip ve 3 bozuk checkpoint senaryosu eklendi. **Godot bulunmadığı için bu motor senaryoları çalıştırılmadı.**
- Kaynak/manifest/ZIP testleri ve sayıları bu paketin oluşturulmasında tekrar kaydedilir.
- Save dosya sistemi semantiği ve gerçek oyun devamı Godot 4.3+ Windows ortamında kabul bekler.

## v0.1.5 (13 Ekim 2026)

- Bozuk ana kayıt üzerine yazma sırasında sağlam yedeğin korunması için kod düzeltildi.
- 5 yeni statik sözleşme testi ve izole Godot dosya sistemi smoke senaryosu eklendi.
- Godot 4.3+ motoru erişilebilir olmadığından gerçek headless/Windows testleri **YAPILMADI**.
- GPU/FPS farkı **ölçülmedi**; görsel/performans kodu değiştirilmedi.

## v0.1.6 (13 Ekim 2026)

- v0.1.5 ZIP SHA-256 `0be64f486bf28ca1b0f363a23ea9f534c139b8ddfc4f9ea9dd970d1e2290e848`: **eşleşti**.
- Kayıt döndürmede `.rollback` ara aşaması, ana→rollback→backup kurtarma önceliği ve önceki backup'ın yeni primary doğrulanana kadar korunması kodlandı.
- Python statik testleri: **35/35 PASS**; `tests/check_project.py`: **PASS**.
- Godot 4.3+ bulunamadı; `tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**. İzole motor testleri yazıldı ama çalıştırılmadı.
- Gerçek Windows dosya sistemi, EXE, GPU/FPS, multiplayer: **YAPILMADI**. Performans farkı **ölçülmedi**.
- Kaynak manifesti/ZIP CRC/çıkarılmış ZIP tekrar testi paketleme aşamasında ayrıca doğrulanır.

## v0.1.7 (13 Ekim 2026)

- v0.1.6 ZIP SHA-256 `f5d192e92011e224b6bc06e522546a963ce8692b662de6be106d34620f575a7b`: **eşleşti**.
- `tests/check_project.py`: **PASS** (statik). Python `unittest`: **41/41 PASS**, bunun 6'sı yeni checksum kaynak sözleşmesidir.
- Motor smoke dosyasına checksum zarfı round-trip, veri değişikliği/eksik checksum reddi, eski JSON geriye uyumluluk ve izole disk senaryoları eklendi; **çalıştırılmadı**.
- Godot 4.3+ binary bulunamadı ve GitHub DNS çözümlemesi başarısız: `tests/run_godot_smoke.py --require-engine` **NOT RUN / exit 1**. Gerçek parser/import, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**.
- Manifest/ZIP CRC/çıkarılmış ZIP tekrar testleri paketleme sırasında çalıştırılır. Grafik ve performans kodu değiştirilmedi; FPS farkı **ölçülmedi**.

## v0.1.8 (13 Ekim 2026)

- v0.1.7 ZIP SHA-256 `d7e5ac687722a4744338b3f43bb008766e3b85645a7f1f7990a3a2432e90448e`: **eşleşti**.
- `tests/run_godot_smoke.py` gerçek Godot 4.3+ sürüm kontrolü ve smoke bitiş doğrulaması gerektirir. Sıfır çıkış kodu tek başına başarı kabul edilmez.
- `tests/test_engine_runner.py`: 6 **Python runner** testi eklendi; eski 41 ile toplam **47/47 Python test** hedefi. Bu testlerde simüle edilmiş alt süreç sonuçları kullanılır; gerçek motor yürütümü değildir.
- `tests/godot_flow_smoke.gd`: Godot dinamik script üyelerinin statik `Node` tipi nedeniyle reddedilme olasılığına karşı `game` Variant olarak tutulur. Gerçek parser kabulü henüz yok.
- Godot binary/DNS/bağlı cihaz erişimi olmadığından headless import/parse ve oyun akışı **YAPILMADI**. Windows EXE, FPS/frametime ve multiplayer **YAPILMADI**. Ölçülmüş performans farkı **yok**.
- Paketleme: `tools/package_source.py` ile manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri.

## v0.1.9 (13 Ekim 2026)

- Kaynak v0.1.8 ZIP SHA-256 eşleşti: `a1e36250b6309a23a9dfc25d0855bec081101f5ff69142aac241cbcdc8c5e94d`.
- Raycast self-exception ve HUD değer değişimi koruması kaynakta uygulandı; üç yeni statik Python regresyon testi eklendi.
- `tests/godot_flow_smoke.gd` kapsül içinden kısa ışınla oyuncu gövdesinin algılanmadığını denetleyecek, ancak **motor mevcut olmadığı için çalıştırılmadı**.
- Gerçek Godot parse/physics/UI, Windows EXE ve FPS/frametime **YAPILMADI**. Performans kazancı ölçülmedi.


## v0.1.10 (14 Ekim 2026)

- v0.1.9 Library ZIP SHA-256 `8481f23238065aaac291f2734de65a52fd7ba8a8f3a39e2e2949448565d87d6f` eşleşti.
- Modal ilk düğme odağı ve dolap Enter gönderimi kaynak kodunda uygulandı; dört yeni statik regresyon kontrolü eklendi (toplam **54/54**).
- Godot smoke betiğine ilk düğme odağı, kod alanı odağı, Enter ile dolap açma ve stale Enter reddi kontrolleri eklendi; **motor olmadığı için çalıştırılmadı**.
- `tests/check_project.py` ve Python unittest PASS. Manifest/ZIP CRC/çıkarılmış ZIP tekrar testleri paketleme adımında ayrıca doğrulanır.
- Gerçek Godot UI/Windows EXE, GPU/FPS, multiplayer: **YAPILMADI**. Performans farkı ölçülmedi.


## v0.1.11 (14 Ekim 2026)

- v0.1.10 kaynak ZIP SHA-256 `2bea7973acc9a0f56b638104ad9ae5ab45350d3699c0e4c143bc256ac0fd90b6`: **eşleşti**. Önceki manifest **27/27 PASS**.
- `tests/check_project.py`: **PASS** (statik). Python unittest: **58/58 PASS** (4 yeni Esc iptal kaynak sözleşmesi).
- Godot smoke betiğine Esc ile not/bulmaca iptali, prolog onayı ve kapanış sonrası eski kod gönderimini reddetme senaryoları eklendi; **motor olmadığından çalıştırılmadı**.
- `tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ binary yok). Gerçek UI, parse, Windows `.exe`, GPU/FPS, multiplayer **YAPILMADI**; ölçülmüş performans farkı **yok**.
- Yeni SHA manifest, ZIP CRC ve çıkarılmış ZIP regresyonu paketleme sırasında çalıştırılacaktır.


## v0.1.12 (14 Ekim 2026)

- Kaynak v0.1.11 ZIP SHA-256 `3a3cebfd2f693ec7b2e9b1fc9b48a0476d9f6b34446630ad485d8258618912dd` **eşleşti**; eski manifest **28/28 PASS**.
- `tests/check_project.py`: **PASS** (statik); Python unittest: **62/62 PASS** (4 yeni statik ilerleme sözleşmesi).
- `tests/godot_flow_smoke.gd`: arşiv öncesi mühür, dalış öncesi sigorta/mühür değişikliği reddi için üç negatif senaryo eklendi; **gerçek motor olmadığından çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**, Godot 4.3+ çalıştırıcısı yok; GitHub DNS çözümleme başarısız. Gerçek import/parse, Windows EXE, FPS/frametime, multiplayer **YAPILMADI**.
- Manifest, ZIP CRC ve ZIP çıkarma sonrası testler paketleme sırasında doğrulanır. Ölçülmüş GPU/CPU performans farkı yoktur.


## v0.1.13 (14 Ekim 2026)

- Kaynak v0.1.12 Library ZIP SHA-256 `b158eaddfed06f8bab234418ef4601569542f3cb49446163e8f5e2a42114cfed` **eşleşti**; kaynak manifesti **29/29 PASS**.
- `tests/check_project.py`: **PASS** (statik); Python unittest: **66/66 PASS** (4 yeni 3D erişim sözleşmesi; eski yatay test güncellendi).
- Godot smoke için dikey mesafe, yakın hedef ve negatif erişim sınırı senaryoları eklendi; **Godot motoru olmadığı için çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ binary bulunamadı). Gerçek GDScript import/parse, 3D fizik/raycast, save I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**. Ölçülmüş performans kazancı **yok**.
- SHA manifest, ZIP CRC ve çıkarılmış ZIP regresyonları paketleme aşamasında tekrar doğrulanır.

## v0.1.14 (14 Ekim 2026)

- Kaynak v0.1.13 Library ZIP SHA-256 `46ca5ad794652e1afdc6f58b1ffa616a342b2d8a90f1c0498e11a85035d1ad6b` **eşleşti**; kaynak manifesti **30/30 PASS**.
- `tests/check_project.py`: **PASS** (statik); Python unittest: **70/70 PASS** (4 yeni odak-zamanlama sözleşmesi; mevcut hareket testi güncellendi).
- Godot smoke'a odak kaybı sırasında zamanın ve oyun tuşlarının durması, hareketin engellenmesi, odak geri gelince zaman ve hareketin sürmesi için 5 kontrol eklendi; **gerçek motor olmadığından çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ bulunamadı). Gerçek Godot import/parse, Windows Alt+Tab, kayıt I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**. Ölçülmüş performans farkı **yok**.
- Manifest, ZIP CRC ve çıkarılmış ZIP testleri paketleme aşamasında doğrulanır.

## v0.1.15 (14 Ekim 2026)

- Başlangıç Library v0.1.14 ZIP SHA-256 `00815bcce9edfdcc580ec584e7e73dc02d469aa511def7a53028ea8a6e9b2ee4` **eşleşti**, önceki kaynak manifesti **31/31 PASS**.
- `tests/check_project.py`: **PASS** (statik); Python unittest: **74/74 PASS** (4 yeni `test_player_freeze_contract.py` sözleşmesi).
- `tests/godot_flow_smoke.gd` içine odak kaybı ve açık modal sırasında oyuncu konumu/hızının değişmemesi için dört motor kontrolü eklendi; **gerçek Godot motoru olmadığından çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ bulunamadı). Gerçek GDScript parse, Windows Alt+Tab, CharacterBody3D fiziği, save I/O, Windows EXE, GPU/FPS, multiplayer **YAPILMADI**. Performans farkı ölçülmedi.
- Manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme sırasında ayrıca doğrulanır.

## v0.1.16 (14 Ekim 2026)

- Kaynak v0.1.15 Library ZIP SHA-256 `1b6e9a5ee5a60ae3372f7a3692c03d23083e2fe805beb6426d866b33c45a470f` **eşleşti**; manifest **32/32 PASS**.
- `tests/check_project.py`: **PASS** (statik); Python unittest **80/80 PASS** (6 yeni odaklı dalış kaynak sözleşmesi). Eski `create_timer(12.0)` kontrolü odakla ilerleyen `DIVE_SECONDS` sayacına uyarlandı.
- Godot smoke: yatak dalışını başlatma, R iptali, eski token, arka planda süre durması, ön planda devam ve dalış bitiş karesinde rüya süresini koruma kontrolleri yazıldı; **motor olmadığından çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**, Godot 4.3+ çalıştırıcısı bulunamadı. Gerçek GDScript parse, Windows Alt+Tab, kayıt I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**. Performans kazancı ölçülmedi.
- Kaynak SHA manifesti, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme adımında ayrıca doğrulanır.

## v0.1.17 (14 Ekim 2026)

- Kaynak Library v0.1.16 ZIP SHA-256 `bef79b261fe16873ddca887107e1cf516a8953073c5558d73f5bf063312329c0`: **eşleşti**; eski kaynak manifesti **33/33 PASS**.
- `tests/check_project.py`: **PASS** (statik); Python unittest: **84/84 PASS** (4 yeni odak dönüşü `delta` koruma sözleşmesi). Önceki dalış testi yeni `focused_delta` hesabına uyarlandı.
- `tests/godot_flow_smoke.gd`: odak dönüşünün ilk karesinde 120 saniyelik yapay `delta` verilse de dalış/rüya süresinin değişmemesi için iki motor kontrolü yazıldı; **Godot motoru olmadığından çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ binary yok). Gerçek import/parse, OS Alt+Tab, kayıt dosya I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**; performans farkı ölçülmedi.
- Manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme sırasında doğrulanır.

## v0.1.18 (14 Ekim 2026)

- Kaynak v0.1.17 Library ZIP SHA-256 `01171310b62ce56855b975cf26c6b321322112fd3b873817ced902bebb009292`: **eşleşti**. Python unittest: **91/91 PASS** (4 Python runner mock + 3 statik F5 yazma sırası); kaynak SHA manifesti **35/35 PASS**; izole disk için bir Godot smoke kontrolü yazıldı, motor yokluğundan çalıştırılmadı.
- `tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ binary yok). Gerçek import/parse, dosya I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**; performans farkı ölçülmedi.
- Statik check, Python unittest, SHA manifesti, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme sırasında çalıştırılır.


## v0.1.19 (14 Ekim 2026)

- v0.1.18 Library ZIP SHA-256 `181a5c70e1f50f21d7221d4343d04c698e6a0e98f14aeef5ca7ba34b019735ee` **eşleşti**; eski manifest **35/35 PASS**.
- `tests/check_project.py`: **PASS (statik)**; Python unittest: **95/95 PASS** (4 yeni modal kapatma kaynak sözleşmesi).
- Godot smoke'a prolog/bitiş doğrudan `close` reddi için iki kontrol eklendi; **gerçek motor olmadığı için çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**. GDScript parser, UI, save I/O, Windows EXE, GPU/FPS, multiplayer **YAPILMADI**. Performans farkı ölçülmedi.
- SHA manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme sırasında yeniden doğrulanır.

## v0.1.20 (14 Ekim 2026)

- Önceki v0.1.19 Library ZIP SHA-256 doğrulandı: `51b7345c793ed5dba37f0e5dd77fb72fc93f24418dd6f0c512443c029fdae416`; kaynak manifesti **36/36 PASS**.
- `tests/check_project.py`: **PASS** (statik); Python unittest: **99/99 PASS** (4 yeni doğrudan çağrı odak sözleşmesi; mevcut test güncellendi).
- Godot smoke'a arka planda prolog onayı, yatak etkileşimi ve sigorta callback'inin reddi için 3 kontrol eklendi; **motor bulunmadığı için çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**. Gerçek Godot import/parse, OS Alt+Tab, UI/fizik, kayıt dosyası I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**; ölçülmüş performans farkı yok.
- Yeni manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme adımında doğrulanacaktır.

## v0.1.21 (14 Ekim 2026)

- Başlangıç Library v0.1.20 ZIP SHA-256 `13fbfa310c860e057dbce86ece01708daf04c33fca8dae8de17d6d0813ce2182` **eşleşti**; önceki manifest **37/37 PASS**.
- `tests/test_background_save_contract.py`: dört yeni **statik** test; toplam hedef **103/103**. Motor smoke'a arka plan doğrudan F5 pending koruma, ön planda gerçek F5 dosya yazma ve F9 geri yükleme senaryoları eklendi (izole HOME/APPDATA).
- Godot 4.3+ binary bulunamadı: `python3 tests/run_godot_smoke.py --require-engine` **NOT RUN / exit 1**. Gerçek GDScript import/parse, Windows klavye/Alt+Tab, kayıt dosya I/O, Windows EXE, GPU/FPS, multiplayer **YAPILMADI**. Performans farkı ölçülmedi.
- SHA manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri sürümlü paketleme sırasında doğrulanacaktır.

## v0.1.22 (14 Ekim 2026)

- Başlangıç Library v0.1.21 ZIP SHA-256 `a66bd883e022ae1d3476842804bcc9725f31ac037ce11b581aa23cf87015ada1` **eşleşti**; önceki kaynak manifesti **38/38 PASS**.
- `_finish_dive` odak dışı ve sayaç bitmeden gelen doğrudan çağrıları reddeder. `tests/test_dive_completion_contract.py` dört yeni Python **statik** test; `tests/godot_flow_smoke.gd` iki negatif motor kontrolü içerir, motor olmadığından çalıştırılamadı.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ çalıştırıcısı yok). Gerçek Godot import/parse, OS Alt+Tab, UI/fizik, F5/F9 dosya I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**. Ölçülmüş performans farkı yok.
- Python check/unittest, SHA manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme sırasında doğrulanır.

## v0.1.23 (14 Ekim 2026)

- Önceki v0.1.22 Library ZIP SHA-256 `1509504c8fa0684d1fb4b773d9397a19cda80e56473770b486df7b1d20614eaa` doğrulandı; eski manifest **39/39 PASS**.
- `scripts/main.gd` doğrudan F9 yüklemesini odağa bağlar. `tests/test_background_load_contract.py` dört yeni Python **statik** test; Godot smoke'a arka plan F9 (klavye + doğrudan) ve odak sonrası başarılı F9 kontrolü eklendi.
- Godot 4.3+ çalıştırıcısı yok: `python3 tests/run_godot_smoke.py --require-engine` **NOT RUN / exit 1**. Gerçek Godot import/parse, UI, Windows Alt+Tab, F5/F9 motor I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**; performans ölçümü yok.
- Python check **PASS**, unittest **111/111 PASS**, SHA manifest **40/40 PASS**, ZIP CRC ve çıkarılmış ZIP tekrar testleri **PASS**. Bunlar kaynak testleridir.

## v0.1.24 — Doğrudan yatak dalışı koruması (14 Ekim 2026)

- Kaynak: v0.1.23 Library ZIP SHA-256 `21a06c9013b5b73a647e8136be59ee9e951d9e8f420f8614c63a0494a5759563` eşleşti; eski manifest 40/40 PASS.
- `python3 tests/check_project.py`: **PASS** (statik). `python3 -m unittest discover -s tests -p 'test_*.py' -q`: **115/115 PASS** (4 yeni statik kontrol).
- Motor için dört yeni negatif senaryo: prolog modalında doğrudan başlangıç, arka planda doğrudan başlangıç, aktif dalışın yeniden başlatılması ve Ev'de doğrudan başlangıç. Motor bulunamadığı için **YÜRÜTÜLMEDİ**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ binary yok; GitHub DNS çözümlenemedi). Gerçek GDScript parser, Windows input, kayıt dosyası I/O, FPS/frametime ve export **YAPILMADI**.

## v0.1.25 — Doğrudan bitiş koruması (14 Ekim 2026)

- Başlangıç v0.1.24 Library ZIP SHA-256 `05da5695a4d7fd098a636d1ea16c97b1924ba84f0979506881e9320a760372f2` eşleşti; kaynak manifesti **41/41 PASS**.
- `tests/test_wake_guard_contract.py`: 4 yeni **statik** Python testi (toplam hedef 119). Godot smoke: prolog, Okul ve arka planda doğrudan `_wake()` reddi, meşru çanla bitiş korunur; **motor çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**, Godot 4.3+ binary bulunamadı. Gerçek parse, Windows UI/Alt+Tab, F5/F9 kayıt I/O, GPU/FPS ve EXE **YAPILMADI**.

## v0.1.26 — Çöküş koruması (14 Ekim 2026)

- Önceki Library v0.1.25 SHA-256 eşleşti, eski manifest 42/42 PASS. `tests/test_fold_guard_contract.py` dört yeni Python **statik** kontrolü ekler; hedef toplam 123/123 unittest.
- `tests/godot_flow_smoke.gd` altı yeni çöküş senaryosu içerir; Godot 4.3+ bulunmadığından **çalıştırılmadı**. Gerçek Windows Alt+Tab, GDScript parse, F5/F9 I/O, EXE, GPU/FPS ve multiplayer doğrulanmadı.
- Paketleme `tools/package_source.py` ile manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri üzerinden yapılır. Performans ölçülmedi.

## v0.1.27 — Yanlış cevap cezası kapısı (14 Ekim 2026)

- Kaynak v0.1.26 Library ZIP SHA-256 `2a434d1d4481c656d66c58200dca711d4cf8b5d379d6fe142dbcf65d55b7fdce` **eşleşti**, eski manifest **43/43 PASS**.
- `tests/test_wrong_answer_guard_contract.py`: 4 yeni **statik** Python regresyonu; toplam hedef **127/127**. Prolog/not/arka plan/bitiş sonrası ret ve doğru yanlış cevap cezası için beş Godot smoke kontrolü yazıldı; motor yokluğundan **çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1** (Godot 4.3+ yok). Gerçek GDScript parse, Windows Alt+Tab, UI/fizik, F5/F9 I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**. Performans ölçümü yok.

## v0.1.28 — Bulmaca modalı giriş güvenliği (14 Ekim 2026)

- Başlangıç Library v0.1.27 SHA-256 `03ca4c965a1de3d4a74ac30319608509610913dbe440aab0a3562e4dd9a46c3a` eşleşti; eski manifest **44/44 PASS**.
- `tests/test_puzzle_dialog_entry_contract.py`: 4 yeni **statik** test (hedef toplam **131/131**). `tests/godot_flow_smoke.gd`: prolog, not, okul, arka plan ve aynı bulmaca yenilemesi için altı yeni **çalıştırılmamış motor** kontrolü.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**, Godot 4.3+ binary yok. Gerçek Godot import/parse, UI/fizik, Windows Alt+Tab, F5/F9 I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**. Performans ölçülmedi.
- Kaynak Python, SHA manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme adımında doğrulanacaktır.

## v0.1.29 — JSON kayıt bulmaca sayı türü (14 Ekim 2026)

- Başlangıç Library v0.1.28 SHA-256 eşleşti; eski kaynak manifesti 45/45 PASS. `tests/test_checkpoint_integer_arrays_contract.py` dört yeni **statik** kaynak testi içerir (hedef 135/135).
- Motor smoke'a checksum ve legacy JSON'dan dönen sigorta/mühür öğelerinin `TYPE_INT` olmasını ve çözülmüş kayıttan sonra sigorta `%` döngüsünü denetleyen dört kontrol eklendi; **Godot 4.3+ yok, çalıştırılmadı**.
- `python3 tests/run_godot_smoke.py --require-engine`: **NOT RUN / exit 1**. Gerçek Godot import/parse, Windows Alt+Tab, fizik, F5/F9 dosya I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**. Ölçülmüş performans farkı yoktur.
- SHA manifest, ZIP CRC ve çıkarılmış ZIP tekrar testleri paketleme aşamasında doğrulanacaktır.

## v0.1.30 görsel kaynak testleri

- `tests/test_global_pbr_contract.py`: 5 statik görsel sözleşme; `tests/godot_flow_smoke.gd`: üç odada PBR kaynakları, ACES ve düşük/yüksek FX profili motor kontrolü eklendi fakat motor olmadan çalıştırılmadı. 15 PNG boyut/kanal kontrolü, tüm mevcut kaynak regresyonları ve kaynak manifesti paketlemede doğrulanır. Gerçek FPS farkı bilinmiyor, 8K üretilmedi.

## v0.1.31 — Dünya ölçekli UV regresyonları (14 Ekim 2026)

- `tests/test_world_scale_uv_contract.py`: 4 yeni **statik** test (beklenen toplam 144). Shell etiketleri, shader cache ayrımı, dünya ölçekli triplanar UV, mobilya normal UV ve collision kaynak sözleşmesi denetlenir.
- `tests/godot_flow_smoke.gd`: üç odada `Floor`/`North` malzemelerinin world triplanar ve UV ölçeğini, Gerçeklik'teki `BedFrame` standart UV yolunu kontrol eder; gerçek motor olmadan **çalıştırılmadı**.
- Godot 4.3+ bulunamadığından gerçek import/parse, görsel kalite, F5/F9 disk I/O, Windows EXE, GPU/FPS/VRAM ve multiplayer **YAPILMADI**. Kaynak testleri ve paket doğrulaması motor kanıtı değildir.
