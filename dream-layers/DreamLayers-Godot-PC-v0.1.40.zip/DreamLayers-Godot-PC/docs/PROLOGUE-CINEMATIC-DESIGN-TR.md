# Dream Layers: özgün, oynanabilir prolog — v0.1.38

## GTA V oynanışından çözümlenen ilke (iç kod değil)

GTA V'in North Yankton açılışında uzun açıklama menüsünden ziyade oyuncuya hemen bir görev zinciri verilir. Oyuncu hareket, bakış ve eylem düğmelerini oynarken öğrenir. Dream Layers'ın özgün uyarlaması: **görev 1/2 → masadaki saati E ile incele → görev 2/2 → yatakta dalış**. GTA V'deki banka soygunu, silahlar, karakterler, sesler, UI grafikleri veya diyaloglar kullanılmadı. Saat etkileşimi isteğe bağlıdır; önceki kayıtlardan ve testlerden gelen doğrudan yatağa dalış akışı korunur.

Kaynak: https://www.gtabase.com/grand-theft-auto-v/missions/prologue (kamusal görev özeti).

## Inception sinema dilinden çözümlenen ilke (film içeriği değil)

*Inception*'ın dikkat çekici yönleri: gerçekte mümkünmüş gibi tasarlanmış mekânlar, farklı rüya katmanları arasında görsel / zamansal süreklilik ve gündelik nesnelerde belirginleşen fiziksel çelişkiler. Oyunda yalnızca **özgün 01:47 → 01:46 saat paradoksu**, bir pencerede hafif 8° perspektif değişimi, saat ibresinin geri dönüşü ve lamba eğimi uygulanır. Görsel değişim 2,2 saniyeye yayılır; oyuncu kamerası sarsılmaz veya zorla hareket ettirilmez. Odak kaybında animasyon donar. Ses için özgün ve sessize alınabilir oda ambiyansı hedeflenir; *Inception* müziği, film miksajı, karakterleri, sahneleri veya senaryosu kullanılmaz.

Kaynaklar: https://www.wired.com/2010/11/pl-inception-nolan/ ; https://www.latimes.com/archives/la-xpm-2010-dec-07-la-en-inception-scene-20101207-story.html

## Aşamalar ve kabul kriterleri

1. **Bu kaynak sürümünde:** Kısa TR/EN açılış, gerçek bir etkileşim objesi, görev HUD, oyunun dünyasında ufak animasyon, odak ve modal güvenliği, önceki yatak→Ev dalışı ve F5/F9 şeması korunması. Python statik testleri ve kaynak doğrulaması.
2. **Godot 4.3+ gerekli:** Kamera açısı ve saatin erişilebilirliği, raycast, 2,2 saniyelik dönüş, modal ESC, raycast/bed, animasyon sırasında Alt+Tab, GDScript ayrıştırma ve eksik PBR kaynakları.
3. **Üretim kalitesi sonraki:** Kontrollü 30-90 saniyelik sahne ritmi, isteğe bağlı atlanabilir özgün ses paleti, müzik ve ses erişilebilirliği, oyuncu HUD yönlendirmesi, lisanslı yüksek detay prop modelleri, Windows ölçülen FPS/p95.

**Sınırlar:** Kaynak kodları, ses kayıtları ve sahneleri kopyalanmadı. Tersine mühendislik burada kamuya açık oynanış ve sinema dili üzerinden yapılan bir tasarım çözümlemesidir. Gerçek render veya GTA V düzeyinde oynanış iddiası yoktur.
