## v0.1.37 — Bevel triangle winding

`DreamRooms._beveled_box_mesh()` artık Godot 4.x `ArrayMesh` için saat yönünde ön yüz indeksleri üretir. Üçgen geometrik çarpımı aydınlatma normalinin tersi yönündedir; dışarıdan görünürlük sorununu önlemek amaçlanır. Altı yüzün içerideki üçgen yönleri statik olarak sınanır ve motor smoke kontrolü hazırdır. **Motor render testi henüz yoktur;** bu kaynak testi, görsel onay yerine geçmez.

## v0.1.35 — Seçili büyük nesneler için yuvarlatılmış PBR görsel mesh

- Yatak, başlık, masa, dolap, kapı gibi seçili büyük nesneler üç odada 294 köşeli/432 üçgenli indeksli ArrayMesh kullanır. PBR materyaller aynı kalır, aynı ölçüdeki mesh'ler önbelleklenir.
- Kaydedilmiş bulmaca/oyun mantığı ve tüm orijinal BoxShape3D hitbox'lar korunur. Bevel yarıçapı en çok 7,5 cm ve en ince yarı kalınlığın %44'üdür; görsel-fizik yüzeyi arasında ufak fark olabilir.
- Önceki v0.1.34 CylinderMesh donanım için F3 LOW=8, MEDIUM=12, HIGH=24 segment sistemi korunur. Büyük mimari kabuk ve trim BoxMesh kalır.
- Fotogrametri, taranmış 2K/4K/8K doku veya gerçekçi ışık kalibrasyonu henüz yok. Gerçek Godot görüntüsü/frametime/VRAM ölçülmeden performans ya da AAA grafik iddiası yok.

## v0.1.34 — F3 dekoratif geometri ayrıntı seviyesi

Gerçeklik/Ev/Okul'un yalnızca görsel yuvarlak donanımı F3 LOW/MEDIUM/HIGH için sırasıyla 8/12/24 silindir kenarına geçirilir. Her dekorun kendine ait `CylinderMesh` kaynağı vardır; güncelleme sadece kalite değişiminde yapılır. Fizik/etkileşim gövdeleri ve PBR materyalleri aynen kalır. Bu gerçek fotogrametri, mesh bevel veya 8K değildir; Godot render ve gerçek FPS/VRAM ölçümleri henüz yapılmadı.

## v0.1.33 — Görsel-only yuvarlak donanım

Üç odada lambanın gövde/tabanı, çan butonu, kapı ve dolap topuzları, mühür kadranı için 12 segmentli PBR silindir mesh ayrıntıları eklendi. Yeni fizik/collision yok; var olan etkileşim kutuları aynı. Bu düşük poligonlu küçük geometri iyileştirmesidir, fotogerçekçi tarama veya bevel mesh üretimi değildir. Godot render/FPS/VRAM doğrulaması bekliyor.

## v0.1.32 — F3 shader örnekleme maliyeti

LOW profili altı büyük shell yüzeyinde world triplanar yerine standart UV PBR kullanır; MEDIUM/HIGH triplanar görünümü korur. Bu seçenek, düşük GPU sınıfında triplanar doku örnekleme maliyetini azaltmak içindir. LOW'da UV ölçeği daha kaba görünebilir. Gerçek GPU'da FPS/VRAM veya görüntü karşılaştırması henüz yapılmadı.

# Dream Layers — Bütün oyun için görsel kalite altyapısı (v0.1.30)

## Bu teslimatta gerçekten uygulanan

- Ortak `DreamRooms.cuboid` oluşturucusu bütün **Gerçeklik, Ev, Okul** sahnelerinde aynı tileable **PBR albedo / normal / roughness** malzeme yolunu kullanır. 5 grup × 3 kanal = **15 adet özgün 512×512 PNG**. Doku ve materyal kaynakları önbelleğe alınır.
- Odalar aynı ACES renk dönüştürme, daha nötr gerçekçi renk paletleri ve pratik iç mekan lambalarını kullanır. Oda pervazları, yatak örtüsü/başlığı, pencere kayıtları, kapı kolu ve dolap hava aralıkları salt görsel dekoratif mesh'lerdir. **Mevcut collision/etkileşim fizik nesneleri değiştirilmedi.**
- Rendering Method artık **Forward+** (Vulkan destekli PC gerekir). F3 kalite kademeleri: **LOW** SSAO/SSIL kapalı, gölge kapalı, MSAA kapalı; **MEDIUM** SSAO açık, SSIL/gölge kapalı, 2× MSAA; **HIGH** SSAO+SSIL, dinamik lambalarda gölge, 4× MSAA. Yapay bloom kapalı. Geçiş geri alınabilir. Bunların FPS sonuçları ölçülmedi.
- `tools/build_pbr_textures.py` PNG'leri deterministik üretir; yeniden üretim için Python + NumPy + Pillow gerekir. Oyunu çalıştırmak için Python gerekmez.

## Sınırlar ve yüksek kaliteli asset hattı

Bu dosyalar gerçek taranmış dokular **değildir**, 8K üretimi **değildir** ve gerçek hayattan ayırt edilemeyen sonuç **garanti etmez**. Önceki kutu meshi geometrisi üzerinde mikro yüzey iyileştirmesidir. Görsel doğrulama ve ışık/GPU ölçümü **Godot 4.3+ içinde henüz yapılmadı**. Tüm oyun hâlâ oyun prototipidir.

Fotogerçekçi üretim için sıradaki işler: lisansı açık fotogrametri/scan mobilya, gerçek bevel geometry/LOD, ölçülü 2K/4K PBR taramalar, kahraman objelerde *opsiyonel* 8K; baking (normal/AO), kapı/pencere mimarisi ve fiziksel ışık girişi, doğru ölçek, reflection probe/GI, animasyon, gerçek cihaz ekran görüntüleri. 8K tüm objelerde etkinleştirilmemelidir: VRAM ve yükleme maliyetini aşırı yükseltir. Yüksek kalitede bile kalite seviyeleri/frametime p50-p95/VRAM ölçülmeden performans iddiası yoktur.

Motor smoke: `python3 tests/run_godot_smoke.py --require-engine`. PC'de Forward+ çalışmıyorsa önceki v0.1.29 paketini kullan; eski GPU'larda render yöntemi `gl_compatibility` olarak değiştirilebilir, ancak SSAO/SSIL yoktur. Render yöntemi değişimi Godot yeniden başlatma gerektirir.

## v0.1.31 — Büyük yüzeylerde dünya ölçekli doku

Altı oda kabuğu yüzeyi (`Floor`, `Ceiling`, `North`, `South`, `West`, `East`) 0,75 tekrar/metre dünya uzaylı triplanar UV kullanır. Küçük dekor/mobilya standart UV kullanır; shader varyantları ayrı cache anahtarlarına sahiptir. Bu, 12 metrelik duvar/zeminlerde dokuların gereksiz büyümesini azaltmayı amaçlar. Triplanar doku örnekleme maliyeti yükselir; gerçek Godot görüntüsü, FPS ve VRAM testleri bekler. Gerçek fotogrametri, 2K/4K/8K veya fotogerçekçilik iddiası yoktur.
