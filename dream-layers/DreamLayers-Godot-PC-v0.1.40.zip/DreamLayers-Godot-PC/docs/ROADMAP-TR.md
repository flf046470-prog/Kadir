# Dream Layers — 52 haftalık geliştirilebilir yol haritası

Bu bir **hedef planıdır**: bağımsız, otomatik olarak tamamlanmış geliştirme takvimi veya yayın garantisi değildir. Her fazdaki kabul testi, bir sonraki faza geçmeden gözden geçirilmelidir.

| Haftalar | İş paketi | Geçiş kriteri |
| --- | --- | --- |
| 1–4 | Motor kabulü, FPS kamera, çarpışma, kontrol, paketleme | Godot editörde sıfır hata; 10 dakika solo crash-free; ilk Windows build |
| 5–8 | Üç sahneli seviye bloklaması, oda geçişi, veri modeli | Gerçeklik→Ev→Okul→Gerçeklik tam döngü |
| 9–12 | Legacy çekirdek/veri parity çalışması | Tohum, 90s faz, bulmaca, stability fixtures birebir sonuç |
| 13–18 | Asıl puzzle etkileşimleri: sigorta, optik, dolap, mühür | Sunucu/local doğrulama, yanlış cevap/soğuma testleri |
| 19–24 | Prolog, sinematik yatak, TR/EN anlatım, ses | İptal/skip, restore, kullanıcı deneyimi testleri |
| 25–30 | Görsel geliştirme: PBR set, gerçekçi prop, ışık ve VFX | Referans hedef kareler, kaynak/lisans listesi |
| 31–36 | Optimizasyon: occlusion, streaming, LOD, GPU profili | Hedef donanımda p95 frametime için doğrulama |
| 37–42 | İsteğe bağlı 1–6 oyuncu, otorite, join/leave, reconnect | Ağ/paket kaybı, authority ve 6 client yük testi |
| 43–46 | Save/load, menü, erişilebilirlik, oyun kumandası, QA | Regresyon geçişi, crash ve kullanıcı testleri |
| 47–50 | Steam/Epic ürün materyalleri, build, demo ve inceleme | Mağaza koşullarının ve hesapların doğrulanması |
| 51–52 | Release candidate ve yayın kararı | Hatalar, ticari haklar, ödeme/vergi, yaş derecesi, platform incelemesi |

## Kaynak belgelere bağlı korunacak tasarım niyeti

- Gerçeklik / Ev / Okul farklı atmosferler, özgün zaman akışı ve altı kişisel dönem.
- Mekanizma ve bulmaca sonuçları (gelecekte multiplayer'da) ortak otoriteyle doğrulanır; kişisel zaman görünümü ayrı kalır.
- 90 saniyelik faz, 6 slot, katılımcı kayıtları ve odanın local/world konumu.
- Prolog; yatağa bağlanan rüyaya dalış; gerçekçi, tutarlı mobilya ölçeği; performansa öncelik.
- Referans oyun hash'lerini ve oyun kurallarını gerçek kaynaklar geldiğinde korumak.

## Dağıtım için dış bağımlılıklar

- Steamworks ve Epic Developer Portal hesapları, geliştirici sözleşmeleri, finansal/vergi bilgileri ve hak sahipliği.
- İmzalanmış/denetlenmiş Windows build, crash reporting ve test matrisi.
- Steam ürün sayfası, görseller, oynanış videosu, açıklama ve Valve onayı; Epic Store gereksinimleri.
- Online multiplayer yayınlanırsa PC mağazaları arasında crossplay gereksinimini değerlendirme.

Bu prototip yalnızca geliştirme başlangıcıdır. Tarih yaklaşsa bile gerekli kabul aşamaları tamamlanmadan satışa sunulmamalıdır.
