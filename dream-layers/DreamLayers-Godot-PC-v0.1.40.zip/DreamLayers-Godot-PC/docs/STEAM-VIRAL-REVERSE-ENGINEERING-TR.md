# Steam viral oyunlarının davranışsal tersine mühendisliği — Dream Layers

**Araştırma tarihi:** 14 Ekim 2026  
**Kaynak prototip:** Dream Layers Godot v0.1.38 (v0.1.37 temeli)  
**Kapsam:** Kamuya açık Steam mağaza açıklamaları, SteamDB tüm-zamanlar eşzamanlı oyuncu zirveleri ve yayımlanmış geliştirici açıklamaları. **Hiçbir üçüncü taraf EXE, şifreleme, ağ protokolü, telifli script, oyun verisi veya asset incelenmedi/sökülmedi.** Dolayısıyla aşağıda yer alan iç sistem modelleri **özgün tasarım hipotezleridir**; başka oyunların gerçek kaynak kodlarının tespiti değildir.

## 1. Kanıt seviyeleri ve metrik

- **K — Kamusal olarak doğrulanmış:** Steam sayfalarının açıkça açıkladığı özellikler ve tarihli geliştirici röportajları.
- **M — Davranışsal model:** K'dan hareketle kurulmuş muhtemel giriş → durum → sonuç mimarisi. Gerçek geliştirici implementasyonu bilinmiyor.
- **P — Dream Layers önerisi:** Yalnızca yeni oyun tasarımı/prototip fikri; oyuna eklendiği anlamına gelmez.

SteamDB tüm-zamanlar eşzamanlı zirveleri satış, gelir ya da güncel günlük kullanıcı sayısı **değildir**. Zirveler farklı tarihlerde gerçekleştiği için nedensel başarı kanıtı olarak kullanılamaz.

| Oyun | SteamDB tüm-zamanlar eşzamanlı zirvesi | Kaynak |
| --- | ---: | --- |
| Schedule I | 459.075 (6 Nisan 2025) | https://steamdb.info/app/3164500/charts/ |
| R.E.P.O. | 271.571 (23 Mart 2025) | https://steamdb.info/app/3241660/charts/ |
| Lethal Company | 240.817 (3 Aralık 2023) | https://steamdb.info/app/1966720/charts/ |
| Content Warning | 204.439 (2 Nisan 2024) | https://steamdb.info/app/2881650/charts/ |
| PEAK | 170.759 (17 Ağustos 2025) | https://steamdb.info/app/3527290/charts/ |
| RV There Yet? | 100.002 (25 Ekim 2025) | https://steamdb.info/app/3949040/charts/ |
| MIMESIS | 8.417 (29 Kasım 2025) | https://steamdb.info/app/2827200/charts/ |
| The Exit 8 | 2.819 (6 Aralık 2023) | https://steamdb.info/app/2653790/charts/ |

## 2. Kara-kutu sistem çözümlemesi

### A. R.E.P.O. — Physic-driven extraction

**K:** En çok 6 oyunculu çevrim içi korku, yakınlık sesli iletişim, fizik tabanlı taşınan değerli nesneler, kırılgan eşyalar, canavarlar, çıkarım ve yükseltme. https://store.steampowered.com/app/3241660/REPO/

**M / örnek durum makinesi:** `Keşif → Hedef nesne bulundu → Tut/çek → Fizik hareketi ve tehdit kontrolü → Hasar/değer güncellemesi → Tahliye → Ödül/ilerleme`. Korkutucu olay tek başına değil, oyuncu hareketleriyle oluşan zincirleme başarısızlıkla birleştiğinde anlam kazanır. Çok oyunculu varyantta taşınabilir nesne otoritesi/host ve hareketin ağda tutarlılığı gerekecektir; gerçek ağ implementasyonu bilinmiyor.

**P:** Ev'de ileride iki oyuncunun farklı zaman fazlarında aynı kırılgan rüya aynasını ortak taşıması. **Şimdi yapma:** multiplayer ve rigid-body testleri yok.

### B. Lethal Company — Quota + escalating exposure

**K:** Abandoned moon'larda hurda toplama, şirket kotası, gece artan tehlike, takım arkadaşlarını terminal/radardan yönlendirme ile sahada arama arasında rol ayrımı. https://store.steampowered.com/app/1966720/Lethal_Company/

**M:** `Gün başla → Riskli yere git → Değer topla → Geri dön / daha fazlasını riske at kararı → Kota kontrolü → Yükseltme/sonraki sefer`. Kararın özü **dönüş fırsatını bilerek geciktirmek**. Görev hedefi basittir; fırsat maliyeti, tehdit ve geri dönüş süresi kararı zorlaştırır.

**P:** Dream Layers'ın mevcut 15 dakikalık sayacında oyuncunun kalan zamanı harcayarak geçici, isteğe bağlı yankı ipuçları araması. Ana hikâyeyi zorunlu grind'a çevirmeme.

### C. Content Warning — Recorder as a social objective

**K:** Tehlikeli anları kamerayla çekme, oksijen/batarya/arkadaş sınırı, eve dönüp video yükleme, izlenme/gelir ve ekipman yükseltme. https://store.steampowered.com/app/2881650/Content_Warning/

**M:** `Hazırlan → Tehlikeyi göze alıp an yakala → Kaynakları tüket → Dön → Kaydı izle → Ödül/ekipman`. Kamera, komik/gergin olayı sadece tanımlamaz; oyuncuya o olayı **bilerek üretmek** için sebep verir.

**P:** Dream Layers'ta kamera/ses kaydı *yerine önce* izin gerektirmeyen oyun içi 20 saniyelik olay özeti (olay metaverisi) ve kaydet/tekrar oynat UX'i. Gerçek video yakalama kullanıcının onayı, disk/mahremiyet tasarımı ve motor testi ister.

### D. PEAK — Cooperative failure as the attraction

**K:** 4 oyuncuya kadar tırmanma, yaralanma ve dayanıklılık, yardımcı eşya, her 24 saatte yenilenen harita, yakınlık sohbeti. https://store.steampowered.com/app/3527290/PEAK/

**K / tasarımcı beyanı:** Aggro Crab sanat yönetmeni, eşyaların bir kısmının başarısız kullanım olasılığı taşıyacak biçimde tasarlandığını ve arkadaşlarla gülmenin önemli olduğunu açıklıyor. https://www.gamedeveloper.com/design/what-developers-can-learn-from-the-indie-social-co-op-games-topping-the-steam-charts

**M:** `Tırmanış planı → Sınırlı dayanıklılık → Riskli yardım aracı → Hata veya kurtarma → Takım tepkisi → Bir sonraki deneme`. Ürün özelliği “fizik” değil; **oyuncunun hata üretebildiği güvenli hareket alanı**.

**P:** Bulmacaların birinde zaman fazlarının yanlış eşleşmesi sonucu ses ve çevrenin tersine dönmesi; ölüm/ilerleme kilidi değil, düzeltebilecek bir sosyal/öğrenme anı.

### E. RV There Yet? — Shared machine, asymmetric jobs

**K:** En fazla 4 oyuncu tek karavanı birlikte sürer; ön/arka vinç, fizik, aracın korunması ve yakınlık sohbeti. https://store.steampowered.com/app/3949040/RV_There_Yet/

**M:** `Darboğaz → Sürücü/çekici/işaretçi rol dağılımı → Vinç gerilimi/araç devrilmesi → Ortak kurtarma → İlerleme`. Paylaşılan **tek fiziksel hedef** koordinasyonu zorunlu kılar.

**P:** Ağ testi sonrası iki kişinin beraber hizalaması gereken bir “rüya merceği”. Şimdi tek oyunculu buton bulmacasının yerine otomatik olarak koyma.

### F. MIMESIS — Suspicion rather than raw difficulty

**K:** Dört kişilik co-op; ekip arkadaşlarının sesini ve davranışını taklit eden canavarlar, toplama, gece trene dönme, yükseltmeler. https://store.steampowered.com/app/2827200/MIMESIS/

**M:** `Oyuncu görür/duyar → Gerçek mi sahte mi değerlendirmesi → Riskli yardım/güven kararı → Gerçek kimlik ortaya çıkar → Sonraki sosyal güvensizlik`. Psikolojik gerilim sahici oyuncu iletişiminin belirsizliğine dayanır. Ses taklidinin gerçek teknik yığını veya yapay zekâ modeli hakkında kamuya açık bu bilgilerden hüküm çıkarılamaz.

**P:** Oyuncu sesini taklit etmek yerine altı fazda **tutarsız fiziksel ipuçları**. Ses üretimi, rıza/gizlilik ve gerçek ağ mimarisi tamamlanmadan oyuncu ses klonlama yok.

### G. The Exit 8 — Tiny decision space, high observation load

**K:** Tekrarlanan koridorda anomali varsa geri dön, yoksa ilerle. Geliştirici söyleşisi, daha karmaşık fotoğraf/silah prototipleri yerine iki yönlü kararı tercih ettiğini açıklıyor. https://playism.com/en/game/the-exit-8/ ve https://automaton-media.com/en/news/20240214-27192/

**M:** `Referans mekânı öğren → Yeni döngüyü gözle → Değişiklik VAR/YOK kararı → İleri/geri → Doğruysa ilerle, yanlışsa yeniden başla`. Algoritmik bakımdan çok az oyuncu komutu vardır; içerik üretimi anomalilerin **fark edilebilir ama net olmayan** olmasına dayanır. Oyunun gerçek anomali seçme kodu bilinmiyor.

**P:** Mevcut Zaman Yankıları'nın üzerine “iki ayrı fazdaki ipuçları tutarlı mı?” değerlendirmesi. Özgün kural: **gözlemi rüya anısına bağla**; koridorda geri dönmenin birebir kopyasını yapma.

### H. Schedule I — Visible compounding progression

**K:** Açık dünya simülasyonu, üretim, ticaret, ekipman, otomasyon ve ilerleme; tek/çok oyunculu özellikler. https://store.steampowered.com/app/3164500/Schedule_I/

**M:** `Küçük döngü → Az kaynak → Yeniden yatırım → Otomasyon → Daha karmaşık döngü`. Oyuncu ilerlemeyi her tur daha hızlı/hâkim olarak hisseder.

**P:** Dream Layers'ın korku/gizem tonunu bozmadan “Rüya Defteri” üzerinden bulduğu ipuçlarını kalıcı, spoiler içermeyen bir koleksiyon olarak sun. Oyunun suç/uyuşturucu temasını taşımaya gerek yok.

## 3. Ortak keşif ve sınırlar

Kamusal ürün verileri ve geliştirici anlatımları şunları destekliyor: **anlaşılır ilk hedef; risk/ödül belirsizliği; oyuncu kaynaklı başarısızlık; arkadaşların tepki verebildiği olaylar; hızlı tekrar deneme; başkasına anlatılabilir sonuç.** Bir oyunun viral başarısının bunlardan tek birine *nedensel olarak* bağlı olduğunu kanıtlayamayız. PEAK geliştiricisinin ifadesi özellikle sosyal hata/yardım bileşenini destekliyor.

Fotogerçekçi görseller bazı gerilimlerde yararlıdır (The Exit 8), ancak PEAK/R.E.P.O. örnekleri tek başına 8K görünümün viral başarı garantisi olmadığını gösterir. Platform dışı pazarlama, fiyatlandırma, erişilebilirlik, yerelleştirme, topluluk ilişkileri de sonucu etkileyebilir; burada etkileri ölçülmedi.

## 4. Dream Layers özgün birleşim: “Hatırlayan Ev”

**Durum:** Sadece tasarım önerisi; **v0.1.38'de oynanışa eklenmedi.**

Oyuncu altı zaman fazında evin iki nesnesindeki küçük farklılıkları gözlemler: ses, saat yönü, resimdeki kişi, defterin tarihi. Bir “hafıza bağı” seçerek hangi iki ipucunun aynı geçmişe ait olduğuna karar verir. Doğru karar gizli hikâye parçası, yanlış karar korkutucu ama kurtarılabilir kısa gerçeklik kırılması üretir. Girişte doğru temel ipuçları öğretilir; renk körlüğü/ses kapalılığı için hem metin hem çevresel referans bulunur. Ana mühür ilerlemesi isteğe bağlı yan bulmaca tarafından kilitlenmez.

### Önerilen (henüz uygulanmamış) orijinal motor arayüzü

```text
EventDefinition(id, allowed_phases, required_flags, cue_visual,
                cue_audio, cue_subtitle, solution, cooldown_phases)
EventDirector(seed, run_progress, phase, active_modal, focus)
  -> optional event id or no event
Player.observe(event) -> journal entry
Player.choose(memory_link) -> reveal OR recoverable distortion
```

Güvenlik/tekrar oynanabilirlik kapıları: Prolog, modal ve odak dışı durumlarda olay tetiklememe; kayıtlı bulmaca ilerlemesine dokunmama; fiziksel oyuncu rızası olmadan ekran/ses kaydı olmaması; host/server authority olmadan co-op iddiası olmaması; çeşitliliğin `seed` ile test edilebilir olması.

### Kaynak koddan bağımsız çevrim laboratuvarı

`tools/viral_loop_lab.py` yalnızca **özgün bir Python olay takvimi tasarım örneğidir**, Steam oyunlarından çıkarılmış gerçek RNG algoritması değildir. 6 faz × 90 s, ilk faz güvenli, varsayılan fırsat olasılığı 0,48, ardışık faz cooldown, en fazla 3 olay ve bir olayın garantilenmesi gibi **bizim varsayımlarımızı** hesaplar. Oyun motoruna bağlanmaz, metrik/toplama servisine veri göndermez, diske oyuncu kaydı yapmaz.

Çalıştırma: `python3 tools/viral_loop_lab.py --runs 1000`; kaynak testi: `python3 -m unittest tests/test_viral_loop_lab.py -v`.

## 5. Öncelik sırası ve geçiş kriterleri

| Aşama | Gerçek geliştirme kararı | İlerlemeden önce doğrulanması gereken |
| --- | --- | --- |
| P0 | Godot 4.3+ headless import ve tam mevcut smoke | GDScript parser, Zaman Yankıları raycast, F5/F9, oynanış rotası |
| P1 | İki fazı karşılaştıran tek özgün yan bulmaca | TR/EN erişilebilir açıklama, yanlış kararda kurtarılabilirlik |
| P2 | Seyrek ve tekrar etmeyen anomali takvimi | Deterministik RNG, kayıt bütünlüğü, başlatma ve modal korumaları |
| P3 | Oyun içi rüya defteri ve olay geçmişi | Spoiler kontrolü, RAM ve disk limiti, yeniden yükleme testi |
| P4 | Tek oyuncu fiziksel nesne denemesi | Motor fizik ve en az iki donanımda FPS/VRAM profili |
| P5 | Ağlı asimetrik co-op, en son sesli sohbet | Host authority, bağlantı kaybı, ses izni ve mahremiyet |

**Tasarlanmış ama ölçülmemiş kullanıcı testi hedefleri:** ilk özgün anomaliyi algılama süresi, ilk iki fazın karşılaştırılabilirliği, yan bulmacanın isteğe bağlı anlaşılması, oyuncunun seans sonrası hatırladığı olay sayısı, tekrarlı denemede sıkılma ve beklenen GPU kare süreleri. Bunlar sonuç değildir; izlenmesi gereken ölçütlerdir.

## 6. Kaynak bağlantıları

Birincil: Steam R.E.P.O., Lethal Company, Content Warning, PEAK, RV There Yet?, MIMESIS, Schedule I; PLAYISM The Exit 8. Her oyun için tam URL yukarıdadır.

İkincil: SteamDB grafik sayfaları (tablo), geliştirici söyleşisi: https://www.gamedeveloper.com/design/what-developers-can-learn-from-the-indie-social-co-op-games-topping-the-steam-charts; The Exit 8 röportaj özeti https://automaton-media.com/en/news/20240214-27192/.

**Telif / dürüstlük:** Bütün örnek sistemler özgün yazıldı. Üçüncü taraf oyun dosyalarına erişilmedi; yürütülebilir binary sökülmedi, DRM aşılmadı, özel sunucu protokolü çözülmedi. İleri sürülen teknik mimari Steam oyunlarının gerçek iç kodu olarak sunulmamalıdır. Bu araştırma ve çevrim modeli bir **Godot oyun motoru kabulü**, FPS ölçümü veya başarı/viral olma kanıtı değildir.
