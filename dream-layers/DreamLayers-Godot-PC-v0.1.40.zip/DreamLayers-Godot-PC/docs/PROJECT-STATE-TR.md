## v0.1.40 — 16 Ekim 2026

- Klavye olayı → raycast → etkileşim ve WASD fizik hareketi gerçek motorda doğrulandı. Sıradaki: GPU'lu Windows makinede görüntü, fare bakışı, EXE export ve FPS.

## v0.1.39 kaynak devam kaydı — 16 Ekim 2026

- v0.1.38 ZIP temel alındı. Yıllardır beklenen ilk adım yapıldı: gerçek Godot 4.3 headless motor smoke. v0.1.38 parse edilmiyordu ve F9 ilerlemeli kayıtları reddediyordu; düzeltildi. Motor smoke **PASS (232/0)**, Python 190/190.
- Sıradaki ilk iş: GPU'lu bir makinede (Windows) editörde açıp gerçek görüntü/giriş kontrolü, ardından Windows EXE export ve FPS ölçümü.

## v0.1.38 kaynak devam kaydı — 14 Ekim 2026

- Library v0.1.37 ZIP SHA-256 `f577ff02fbcc9b7b03bfe4f95a5934e9ee2dd19417216dd2b34016b770da7bb6` temel alındı, projenin 3 katmanı, mevcut oyun mekaniği ve kayıt biçimi korunarak geliştirmeye devam edildi.
- İlk kez özgün **oynanabilir prolog görevi**: masadaki saat, TR/EN HUD ve süre odaklı 2,2 saniyelik çevresel kayma. Kamera sallanmaz; doğrudan yatak kullanımı ve dalış testleri korunur; saat görevi isteğe bağlıdır. Oynanabilirliğin Godot motorunda doğrulanması hâlâ gerekiyor.
- Steam'deki 7 viral oyunun kamuya açık oynanış/prensip araştırması (kod/asset tersine mühendisliği yapılmadı) ve çevrim dışı 6 zaman fazlı olay modelinin 7 Python testi aynı pakete eklendi. Bu simülasyon **oyuna bağlanmadı**.
- Python 184/184 PASS, kaynak kontrolü PASS. İlk sonraki görev: `python3 tests/run_godot_smoke.py --require-engine` ile sinematik prolog, F3, F5/F9 ve bütün akış, gerçek raycast, odak, render ve fizik kabulü. Gerçek görüntü, GTA V düzeyi tasarım, Inception düzeyi prodüksiyon, Windows EXE, GPU/FPS/VRAM ve multiplayer iddia edilmez.

## v0.1.37 kaynak devam kaydı — 14 Ekim 2026

- Library temel sürümü v0.1.36, SHA-256 `ab731c00efc54d44785ef9f1ace1ef25da38ce1145eb56acf4c71cc3b951f05d` doğrulandı; proje sıfırdan başlamadı.
- Öncelik: Godot 4.3'te `ArrayMesh` saat yönündeki ön yüz kuralı ile v0.1.35 bevel üçgenleri arasındaki terslik düzeltildi; altı yüzde triangulation yönü statik test edildi. Görsel-only mesh değişimi, `BoxShape3D`/bulmacalar/kayıt biçimi korunur.
- Godot motor/Windows/GPU görüntüleme testi bu ortamda çalıştırılamadı. İlk sonraki adım: `python3 tests/run_godot_smoke.py --require-engine`, özellikle bevel ön yüzleri ve eski uçtan uca smoke kontrolleri. Render çıktısı olmadan fotogerçekçi/oynanabilir iddiası yok.

## v0.1.36 — 14 Ekim 2026 | Zaman Yankıları / Oyun kıyaslaması

- Kaynak: Library v0.1.35 SHA-256 `be00d3594be37797be55b1a2823c2c19e7afb6e1af284af41d6b2581ca659c9d`, manifest 69/69 PASS. Sıfırdan başlanmadı.
- Evde altı fazı inceleme (`phase_echo`), TR/EN özgün anlatı, odak/etkileşim sınırı ve görünmez işaret collider kapatma. Ana bulmacalar ve checkpoint dosya biçimi korunur.
- Benzer oyunların yayımlanmış oynanış mekanikleri incelendi; tersine mühendislik için üçüncü taraf binary sökülmedi. `docs/VIRAL-MECHANICS-RESEARCH-TR.md`.
- Godot ikilisi bu ortamda yok: gerçek import, GDScript, UI/raycast, GPU ve Windows EXE henüz doğrulanmadı. İlk hedef `python3 tests/run_godot_smoke.py --require-engine`.

## v0.1.35 — 14 Ekim 2026 | Kademeli bevel görsellik (v0.1.34 üzerine)

- Temel kaynak: Library v0.1.34 SHA `9e2f37ad37823118c3c23ab68a6821e6d3c1ec41093128be9078f4074e5b189e`; içerdiği LOW/MEDIUM/HIGH CylinderMesh LOD korunur. v0.1.33'e geri dönülmedi.
- Üç odada seçili kahraman mobilyalar için önbellekli 294 verteks/432 üçgen PBR bevel mesh eklendi; orijinal StaticBody3D/BoxShape3D aynı kaldı. 5 yeni statik/matematik testi ve Godot motoru için bevel/collision/cache kontrolleri eklendi.
- Godot 4.3+ burada kurulu değil ve internet DNS erişimi başarısız; Godot parse/render/oyun akışı, Windows EXE, GPU p50/p95, VRAM, F5/F9 gerçek I/O, multiplayer yapılmadı. Sıradaki ilk iş gerçek Godot motor testi ve sonuçlara göre hata düzeltme.

## v0.1.34 — 14 Ekim 2026 | Dekoratif LOD

- Başlangıç doğrulanmış Library v0.1.33 SHA `4263d1c2050a0c2675588360ce1cadd7f2ceb1a3ed50c78883b0ed84d7a33337`; eski kaynak manifesti 67/67 PASS. Sıfırdan proje kurulmadı.
- Üç odadaki yuvarlak görsel donanım F3 LOW=8, MEDIUM=12, HIGH=24 silindir kenarı kullanır; mevcut PBR materyaller, aksiyon metadata ve collision kaynakları değişmez. Dört yeni Python sözleşme testi ve Godot motor bekleyen üç kademe/üç oda kontrolü eklendi.
- Godot 4.3+ çalıştırıcısı bulunamadı (`run_godot_smoke.py --require-engine` exit 1 NOT RUN). Render/GDScript parser/Windows EXE/GPU/FPS/VRAM/F5-F9 motor dosya I/O/multiplayer doğrulanmadı. Sonraki hedef gerçek motor kabulü, ardından görsel kıyas ve p50/p95 frametime.

## v0.1.33 — 14 Ekim 2026 | Dekoratif yuvarlak donanım

- Başlangıç Library v0.1.32 SHA `26c849ed2e90d1eceb7bb272e532bce1402e806602aa734b6960b80fb3aed31c` doğrulandı; kaynak manifesti 66/66 PASS.
- Üç odada dekoratif, PBR kaplı, 12 segmentli silindir donanım eklendi. Ana eylem/çarpışma gövdeleri değişmedi. Dört yeni statik regresyon ve motor bekleyen görsel/collision kontrolleri.
- Godot 4.3+ binary bulunamadı; gerçek import/render, Windows oynanış, GPU/FPS/VRAM, F5/F9 dosya I/O ve multiplayer henüz test edilmedi. Sonraki öncelik gerçek motor smoke ve kontrollü görsel karşılaştırma.

## v0.1.32 — 14 Ekim 2026 | F3 düşük kalite shell shader yolu

- v0.1.31 Library ZIP SHA `ed0d5e241e5604d549fe42ce1b371ca512d9ca8d6192a705ca3b8f8aeac6baad` doğrulandı; eski manifest 65/65 PASS. Proje sıfırdan oluşturulmadı.
- LOW, Gerçeklik/Ev/Okul'daki altı shell yüzeyini standart UV PBR shader varyantına geçirir; MEDIUM/HIGH dünya uzaylı triplanar'a döner. Çarpışma şekilleri, etkileşimler ve kayıt biçimi değişmez. LOW'da daha büyük doku görünümü olasıdır; GPU/FPS kazancı ölçülmedi.
- Dört yeni Python statik test ve Godot motor smoke HIGH→LOW→MEDIUM kontrolü eklendi. Godot 4.3+ binary yok: gerçek import/render/FPS/Windows EXE yapılmadı.

# Dream Layers — Devam durumu

- Tarih: **2026-10-14**; kaynak sürüm **v0.1.31**. Doğrulanmış önceki Library ZIP: `/Dream Layers/Versions/DreamLayers-Godot-PC-v0.1.30.zip`, SHA-256 `1cb2590c48cfe865a8a58e01493928a27cc3898994f0336867b5951f12428a91`. Kaynak manifesti 64/64 doğrulandı; proje sıfırdan başlatılmadı.
- Motor: **Godot 4.3+ / GDScript**, Unreal Engine gerekmiyor. Bu sürümde F5/F9 tek oyuncu checkpoint kayıt/yükleme, `DreamSaveCodec` ile tür, sınır ve bulmaca ilerleme tutarlılığı doğrulaması, geçici dosya/yedekli yazma eklendi.
- Kayıt `user://dream_layers_save_v1.json` ve yedek `.bak.json` kullanır. Yüklemede oyuncu ilgili oda girişine yerleştirilir; kesin oyuncu konumu/çok oyunculu kimliği saklanmaz. Diyalog/dalış sırasında kayıt kapalıdır.
- Kanıt: `python3 tests/check_project.py`, `python3 -m unittest discover -s tests -p 'test_*.py' -v`, `python3 tests/verify_manifest.py` ve çıkarılmış ZIP tekrar testleri. Bunlar **kaynak/statik testleridir**.
- Motor engeli: Godot 4.3+ çalıştırıcısı bulunamadı, GitHub DNS çözümlemesi başarısız. `python3 tests/run_godot_smoke.py --require-engine` gerçek Godot parser/import, gameplay, save/load ve Windows export kanıtı veremedi. Gerçek FPS, GPU, multiplayer ve mağaza kabulü yapılmadı.
- Sonraki iş: Godot 4.3+ ile headless import/parse ve `tests/godot_flow_smoke.gd` çalıştır; gerçek kayıt/yükleme, bozuk dosya/yedek kurtarma, F5/F9 fiziksel giriş, Windows EXE ve GPU/FPS ölçümü. Testler geçmeden bu sürümü oynanabilir/kararlı Windows build olarak tanımlama.
- Önceki sürümleri silme. 90/180/270/365 günlük yol haritası korunur.

## v0.1.5 kayıt kurtarma güvenliği

- Bozuk ana kayıt artık sağlam yedeğin üzerine taşınmaz; yeni geçici kayıt diskten yeniden okunarak doğrulanır. Önceki ZIP korunur.
- İzole motor dosya sistemi smoke senaryosu eklendi; **Godot motoru olmadan gerçek dosya işlemi kanıtı değildir**.
- Sonraki öncelik Godot 4.3+ headless parse/oyun akışı, özellikle Windows'ta rename/remove semantiği ve kayıt kurtarma testi.

## v0.1.6 kesinti kurtarma

- `main.gd` ana kayıt/rollback/yedek üçlüsünü kullanır. Eski yedek yeni primary diskten doğrulanana kadar korunur; kesintiye uğrayan rotasyondaki önceki primary `.rollback` içinden yüklenebilir.
- 35 statik Python testi, kaynak manifesti, ZIP CRC ve çıkarılmış ZIP tekrar testleri hedeflenir; bunlar gerçek Godot I/O testi değildir.
- Godot headless smoke dosyasında kesintiye uğramış rotasyon senaryosu eklendi; gerçek motor çalıştırılamadı. Öncelik Godot 4.3+ ile import/parse ve özellikle Windows rename semantiğini doğrulamaktır.

## v0.1.7 — Kayıt bütünlüğü

- Yeni F5 checkpoint dosyası SHA-256 kontrollü JSON zarfı kullanır; kaydedilen iç JSON metni birebir doğrulanır. Dosya hâlâ yerel tek oyunculu kayıttır; SHA-256 sahteciliğe karşı güvenlik mekanizması değildir.
- F9 önce checksum'lı dosyayı doğrular; geçersiz checksum, eksik zarf veya geçersiz ilerleme reddedilir ve mevcut rollback/yedek kurtarma sırası kullanılır. Eski v0.1.4–v0.1.6 düz JSON dosyaları geriye dönük desteklenir.
- Statik testler **41/41**; manifest/ZIP çıkarma kontrolleri paketleme aşamasında doğrulanır. Godot binary bulunamadı; gerçek motor dosya I/O, import, Windows EXE ve FPS **YAPILMADI**.
- Sonraki öncelik: Godot 4.3+ headless import/parse ve `python3 tests/run_godot_smoke.py --require-engine`, özellikle checksum'lı F5/F9, bozuk zarf sonrası `.rollback`/`.bak` kurtarma; sonra tam oynanış ve Windows export.

## v0.1.8 — Gerçek motor test kapısı

- Kaynak tabanı v0.1.7, SHA-256 `d7e5ac687722a4744338b3f43bb008766e3b85645a7f1f7990a3a2432e90448e` eşleşti.
- Headless runner artık Godot 4.3+ sürümünü doğrular; sıfır çıkış kodu yanında **`DREAM LAYERS ENGINE SMOKE: N checks, 0 failures`** kapanışını ister (`N > 0`). Aksi halde başarısız sayar. Test kullanıcı verileri geçici HOME/XDG/APPDATA köklerine yönlendirilir.
- Smoke betiğindeki sahne kökü dinamik script çağrıları için Variant olarak tutulur. 6 yeni Python runner testi eklendi; bu testler **motor testleri değildir**.
- Godot binary mevcut değil; gerçek Godot import/parse, F5/F9, Windows EXE, GPU/FPS ve multiplayer hâlâ **YAPILMADI**.
- Sonraki iş: Godot 4.3+ kurulu ortamda `python3 tests/run_godot_smoke.py --require-engine` çalıştır, varsa ilk gerçek parse veya runtime hatasını düzelt; özellikle smoke testinin yeni kapanış işaretini ve Windows kullanıcı verisi izolasyonunu doğrula.

## v0.1.9 — Etkileşim doğruluğu ve HUD maliyeti

- Kaynak v0.1.8 ZIP SHA-256: `a1e36250b6309a23a9dfc25d0855bec081101f5ff69142aac241cbcdc8c5e94d` **eşleşti**.
- `scripts/player.gd`: kamera altındaki RayCast3D oyuncu CollisionObject3D gövdesini açıkça hariç tutar (`ray.add_exception(self)`). Fiziksel etkileşim hedefleri artık kendi kapsülü tarafından engellenmemeli; gerçek Godot kabulü bekler.
- `scripts/overlay.gd`: aynı HUD metinleri/nişangâh görünürlüğü tekrar yazılmaz. Gerçek FPS veya frame time iyileşmesi ölçülmedi.
- `tests/test_runtime_safety_contract.py` üç yeni Python statik testi; `tests/godot_flow_smoke.gd` motor içi kısa raycast öz-kesişim kontrolü. Godot motoru/DNS erişimi bulunmadığından headless import/parse, gerçek raycast, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**.
- Sonraki çalışma: Godot 4.3+ `python3 tests/run_godot_smoke.py --require-engine` ile raycast öz-kesişim ve yatak etkileşimini doğrula; ardından klavye/fizik/arayüz kabulü ve FPS ölçümü.


## v0.1.10 — Klavye erişilebilirliği

- `scripts/overlay.gd`: normal modalda ilk düğmeye klavye odağı, kod modalında LineEdit'e odak; LineEdit Enter sinyali mevcut `dialog_generation` kontrolünü atlamadan `_choose()` üzerinden gönderilir.
- `tests/test_keyboard_access_contract.py`: 4 yeni statik test; `tests/godot_flow_smoke.gd`: klavye odağı, Enter ile doğru dolap kodu, kapanmış pencerede tekrar Enter koruması.
- v0.1.9 ZIP SHA-256 doğrulandı. Python statik testleri 54/54 hedef; manifest/ZIP kontrolleri paketlemede doğrulanır.
- **Motor erişimi hâlâ yok:** Godot 4.3+ headless parse, gerçek klavye UI/Windows ve FPS testi yapılmadı.
- Sonraki iş: gerçek Godot 4.3+ ile `python3 tests/run_godot_smoke.py --require-engine`; özellikle `LineEdit.text_submitted`, modal odak, raycast öz-kesişim, kayıt kurtarma ve tam oyun akışı.

## v0.1.11 — Esc ile klavye iptal güvenliği

- Kaynak v0.1.10 ZIP SHA-256 `2bea7973acc9a0f56b638104ad9ae5ab45350d3699c0e4c143bc256ac0fd90b6` **eşleşti**; orijinal kaynak manifesti **27/27** doğrulandı.
- `scripts/overlay.gd` sadece `close` seçeneği bulunan modal pencereleri Esc ile kapatır; prolog/bitiş onayı korunur. Esc mevcut `dialog_generation` korumalı `_choose` üzerinden işlenir.
- `tests/test_keyboard_cancel_contract.py` 4 yeni Python statik kontrol ve `tests/godot_flow_smoke.gd` için iptal/stale input senaryoları eklendi. Toplam **58/58 Python test**; bu testler gerçek Godot motorunu çalıştırmaz.
- Godot 4.3+ binary mevcut değil: `python3 tests/run_godot_smoke.py --require-engine` **NOT RUN / exit 1**. Gerçek GDScript parser, GUI klavye girişi, Windows `.exe`, FPS ve multiplayer **YAPILMADI**.
- Sonraki en değerli iş: gerçek Godot 4.3+ ile headless import/parse ve smoke; özellikle `_input` Esc yönlendirmesi, modal odak, F5/F9 checkpoint kurtarma, raycast ve tam yatak→Ev→Okul→mühür→bitiş.


## v0.1.12 — Olanaksız kısmi kayıtların reddi

- `DreamSaveCodec.validated`: oyun başlamadan değişmiş sigorta/mühür veya arşiv alınmadan değişmiş mühür içeren JSON kayıtlarını reddeder. Mevcut şema ve meşru oyun ilerlemesi korunur.
- Dört yeni Python statik kontrol (toplam **62/62**); üç negatif Godot motor smoke senaryosu eklendi fakat motor olmadan **çalıştırılmadı**.
- Kaynak v0.1.11 ZIP SHA-256 `3a3cebfd2f693ec7b2e9b1fc9b48a0476d9f6b34446630ad485d8258618912dd` eşleşti; manifest 28/28. GitHub DNS hatası ve motor yokluğu nedeniyle gerçek parse/Windows/GPU/FPS kanıtı hâlâ yok.
- Sonraki hedef: Godot 4.3+ gerçek import/parse ve F5/F9 kayıt kurtarma + uçtan uca oyun akışı; ardından hedef Windows donanımında FPS/frametime.


## v0.1.13 — Dikey etkileşim mesafesi kapısı

- Kaynak v0.1.12 Library ZIP SHA-256 `b158eaddfed06f8bab234418ef4601569542f3cb49446163e8f5e2a42114cfed` eşleşti; manifest 29/29. Önceki sürümler korunuyor.
- `DreamPlayer.looked_at_action`: ışının çarptığı nokta ile kamera ışın kökü arasındaki **3D** uzaklık artık `reach_m` ile karşılaştırılır. Yalnızca yatay uzaklık kontrolünün yukarı/aşağı hedeflerde yarattığı erişim açığı kapatıldı.
- 4 yeni Python statik test (toplam **66/66**), Godot smoke için 3 yeni sınama eklendi. **Motor yokluğu nedeniyle GDScript parse, fiziksel etkileşim ve gerçek oyun akışı çalıştırılmadı.**
- Sonraki öncelik: Godot 4.3+ `python3 tests/run_godot_smoke.py --require-engine`, özellikle kamera mesafesi ve yatağın gerçekten etkileşilebilir olması, F5/F9, Esc/Enter, tam yatak→Ev→Okul→mühür→bitiş. Sonra Windows export ve donanım FPS/frametime ölçümü.

## Günlük durum özeti — 14 Ekim 2026 (erken saatler)

- Kaynak sürüm zinciri v0.1.0 → v0.1.13; ağırlık kayıt güvenliği, diyalog/klavye korumaları ve fizik etkileşim sınırları üzerinde. Son turda 4 yeni statik test eklendi.
- Kritik blokaj değişmedi: gerçek Godot motoru ve Windows çalıştırma ortamı olmadan oynanabilirlik, dosya sistemi, GPU performansı ve mağaza kabulü kanıtlanamaz. Bunlar doğrulanmış özellik olarak sunulmamalıdır.

## v0.1.14 — Arka plan odağında rüya süresi

- `main.gd`: `NOTIFICATION_APPLICATION_FOCUS_OUT/IN` olaylarıyla 15 dakikalık oyun geri sayımı ve hareket/oyun kısayolları odağa bağlandı. Alt+Tab sırasında oyun zamanının boşa tüketilmesi önlenmek isteniyor; gerçek OS/motor davranışı henüz doğrulanmadı.
- Dört yeni Python **statik** regresyon testiyle toplam **70/70**. Beş yeni Godot motor smoke kontrolü yazıldı fakat motor yokluğundan çalıştırılmadı.
- Bir sonraki adım: Godot 4.3+ ile headless import ve motor smoke; ardından Windows Alt+Tab ve fiziksel klavye/GUI testi. 12 saniyelik dalış timer'ı bu sürümde duraklatılmıyor.

## v0.1.15 — Modal ve odak kaybında karakter fiziği

- `DreamPlayer._physics_process` hareket izni kapalıysa tüm hız bileşenlerini sıfırlar ve `move_and_slide()` çalıştırmaz; arka planda ya da diyalog sırasında momentum/yerçekimi sürüklenmesi kaynak düzeyinde engellenir.
- Python **74/74 statik test**; Godot smoke'a arka plan ve modal için dört konum/hız kontrolü eklendi (**motor olmadığından çalıştırılmadı**).
- Gerçek Godot 4.3+ headless parse ve Windows odak/fizik testi önceliklidir; Windows EXE, FPS, multiplayer ve mağaza kabulü yoktur.

## v0.1.16 — Dalış sırasında odak güvenliği

- 12 saniyelik yatak dalışı artık `main.gd` `_process` geri sayımında sadece uygulama odaktayken ilerler. Pencere arka plandayken otomatik Ev geçişi engellenir. `R` iptali sayacı temizler, eski token'lar yeni dalışı tamamlayamaz. Dalışın tamamlandığı karede rüya süresinden kesinti yapılmaz.
- `tests/test_dive_focus_contract.py` ile 6 yeni statik test; `tests/godot_flow_smoke.gd` içinde 8 yeni motor senaryosu. **Gerçek motor ve OS Alt+Tab testi henüz yapılmadı**; sahne/klavye/fizik/Windows EXE/FPS kabulü bekliyor.
- Kaynak v0.1.15 Library ZIP SHA-256 `1b6e9a5ee5a60ae3372f7a3692c03d23083e2fe805beb6426d866b33c45a470f` eşleşti, kaynak manifesti 32/32 PASS. Sonraki öncelik gerçek Godot 4.3+ headless smoke ve Windows pencere odağı doğrulaması.

## v0.1.17 — Odak dönüşündeki ilk kare süresi

- Kaynak v0.1.16 Library ZIP SHA-256 `bef79b261fe16873ddca887107e1cf516a8953073c5558d73f5bf063312329c0` eşleşti, önceki manifest 33/33 PASS. Eski sürümler korunuyor.
- `main.gd` odak kaybını izleyen **ilk odaklı karede** gelen `delta` değerini 0 sayar; böylece askıda kalmış kare süresi yatak dalışına veya rüya süresine yazılmaz. Sonraki kareler normal işlenir; oyuncu ilerlemesi veya checkpoint biçimi değişmez.
- 4 yeni Python statik kontrol ve Godot smoke için 2 yeni kontrol eklendi. **Gerçek motor/OS Alt+Tab henüz çalıştırılmadı.** Sonraki hedef: Godot 4.3+ `python3 tests/run_godot_smoke.py --require-engine`, F5/F9 kurtarma ve uçtan uca yatak→Ev→Okul→mühür→bitiş; sonra Windows export ve FPS ölçümü.

## v0.1.18 — F5 geçici dosya koruması ve motor hata günlüğü kapısı

- Başlangıç v0.1.17 Library ZIP SHA-256 `01171310b62ce56855b975cf26c6b321322112fd3b873817ced902bebb009292` eşleşti; proje sıfırdan kurulmadı.
- F5: doğrulanmış checkpoint JSON'u boyut denetiminden geçmeden `TEMP_FILE` WRITE ile açılmaz. Bu, başarısız kodlama/limit durumunda mevcut geçici dosyayı kesip sıfırlamayı önler. Ana/yedek rotasyonu değişmez.
- Headless runner: Godot `ERROR:`/`FATAL ERROR:` günlükleri sıfır exit ve sıfır smoke failure olsa bile kabul edilmez. 4 yeni Python runner mock testi, 3 statik save sıralama testi (toplam 91/91) ve motor bekleyen izole disk boyut kontrolü eklendi. Yeni kaynak manifesti 35/35, ZIP CRC/çıkarma sonrası tekrar testler PASS.
- Godot 4.3+ binary bu ortamda yok; gerçek import/parse, oyun akışı, F5/F9 motor dosya I/O, Windows EXE ve FPS **YAPILMADI**. İlk hedef `python3 tests/run_godot_smoke.py --require-engine`.


## v0.1.19 — Modal kapatma yetkisi

- Kaynak v0.1.18 Library ZIP SHA-256 `181a5c70e1f50f21d7221d4343d04c698e6a0e98f14aeef5ca7ba34b019735ee` doğrulandı; eski manifest 35/35 PASS.
- `_choice("close")` yalnızca `overlay.dialog_can_cancel` doğruysa işlenir; böylece prolog/bitiş zorunlu onayı doğrudan `close` callback ile geçilemez. Normal not/bulmaca kapatma yolu korunur.
- Dört yeni statik test ile Python unittest **95/95 PASS**. İki yeni Godot motor kontrolü yazıldı, ancak Godot 4.3+ binary bulunmadığından gerçek motor smoke **NOT RUN**.
- Sonraki iş: Godot 4.3+ import/parse ve modal close/Enter/Esc, F5/F9 ve yatak→Ev→Okul→mühür→bitiş motor smoke. Windows export, FPS ve multiplayer henüz doğrulanmadı.

## v0.1.20 — Arka plan doğrudan çağrı güvenliği

- Odağa bağlı `_unhandled_input` kontrolüne ek olarak, doğrudan `_interact` ve `_choice` yolları arka planda oyun ilerlemesini değiştirmez. `_load_game` sonrası `player.can_move` uygulama odağını korur.
- 4 yeni statik test (toplam **99/99 Python unittest**), 3 yeni Godot smoke senaryosu. Bu smoke senaryoları Godot motoru olmadan **çalıştırılmadı**.
- Kaynak v0.1.19 Library ZIP SHA-256 doğrulandı; önceki manifest 36/36. Godot 4.3+ `--require-engine` hâlâ NOT RUN / exit 1.
- Sonraki iş: gerçek Godot import/parse ve arka plan doğrudan callback smoke; F5/F9 dosya kurtarma ve tam yatak→Ev→Okul→mühür→bitiş akışı. Windows EXE, GPU/FPS, multiplayer yapılmadı.

## v0.1.21 — Arka planda doğrudan kayıt çağrısı koruması

- Başlangıç Library v0.1.20 ZIP SHA-256 `13fbfa310c860e057dbce86ece01708daf04c33fca8dae8de17d6d0813ce2182` doğrulandı; manifest **37/37 PASS**. Kaynak sıfırdan başlatılmadı.
- `main.gd` doğrudan `_save_game()` çağrısında da `app_has_focus` kontrolü yapar; pencere arka plandayken mevcut pending checkpoint korunur. `_load_game` arka planda programatik kurtarmayı hâlâ destekler ama oyuncu hareketini açmaz.
- Yeni statik testler ve Godot smoke'a gerçek F5/F9 dosya yazma/geri yükleme senaryoları eklendi. Bunlar **Godot motoru olmadan çalıştırılmış test değildir**. Birinci öncelik Godot 4.3+ headless import/parse ve motor smoke; ardından Windows klavye/Alt+Tab ve kayıt I/O kabulü.

## v0.1.23 — Arka planda yükleme güvenliği

- `scripts/main.gd`: `_load_game()` doğrudan çağrıldığında da `app_has_focus` kapısı kullanır. Odak yokken F9 ne kayıt durumunu değiştirir ne açık modalı kapatır ne de fare yakalamayı tetikler; odak geri gelince normal yükleme korunur.
- `tests/test_background_load_contract.py` dört yeni **statik** test; `tests/godot_flow_smoke.gd` arka plan klavye ve doğrudan yükleme reddini, odak sonrası F9 geri yüklemeyi kontrol edecek motor senaryoları içerir. Gerçek Godot motoru olmadığından bu senaryolar **çalıştırılmadı**.
- Başlangıç Library v0.1.22 SHA-256 `1509504c8fa0684d1fb4b773d9397a19cda80e56473770b486df7b1d20614eaa` eşleşti; eski manifest 39/39 PASS. Windows export, FPS ve multiplayer henüz doğrulanmadı.

## v0.1.22 — Dalış bitişinin doğrudan çağrı güvenliği

- `_finish_dive` geçerli token'a rağmen **odak yokken** veya `dive_remaining_seconds > 0.0` iken erken döner. Bu, `_process` odak korumasını atlayan doğrudan/gecikmiş çağrılarla rüyaya geçişi engellemeyi amaçlar; R iptali ve doğal sayaç bitişi korunur.
- Dört yeni Python **statik** test, Godot smoke'a iki negatif kontrol eklendi. Motor 4.3+ yokluğundan gerçek GDScript parse, fizik, OS Alt+Tab, UI ve oyun akışı **henüz doğrulanmadı**.
- Kaynak v0.1.21 Library ZIP SHA-256 `a66bd883e022ae1d3476842804bcc9725f31ac037ce11b581aa23cf87015ada1` eşleşti; manifest 38/38 PASS. Sonraki öncelik Godot headless smoke, F5/F9 disk I/O ve tam oyun akışı; Windows export ve FPS ölçümü bekliyor.

## v0.1.24 — Doğrudan dalış başlatma kapısı

- `_start_dive()` artık `_can_interact("bed")` üzerinden aynı odak/modal/oda/bitiş/geçiş şartlarını denetler. Prolog veya bulmaca açıkken, arka planda, Ev/Okul'da ve aktif dalışta doğrudan çağrı ilerlemeyi değiştirmez.
- Dört yeni Python statik regresyonu ile **115/115 PASS**; dört yeni Godot smoke kontrolü yazıldı fakat motor yokluğundan çalıştırılamadı. Kaynak manifesti paketleme sırasında yeniden üretilecek.
- v0.1.23 Library ZIP SHA-256 doğrulandı. Godot 4.3+ binary bulunamadı ve GitHub DNS başarısız; gerçek import/parse, Windows Alt+Tab, F5/F9 disk I/O, GPU/FPS ve multiplayer **YAPILMADI**. Öncelik gerçek Godot motoru ile tüm smoke senaryolarının çalıştırılmasıdır.

## v0.1.25 — Bitiş geçişi koruması (14 Ekim 2026)

- `_wake()` doğrudan çağrılırsa da Ev'deki çan etkileşiminin tüm kapıları ve çözülmüş mühür zorunludur; odak dışı, Okul, prolog/modal, dalış ve bitiş sonrası çağrılar oyun durumunu değiştirmez.
- Dört yeni Python statik test; prolog/Okul/arka plan doğrudan bitiş reddi için üç Godot smoke kontrolü yazıldı. **Motor olmadığı için Godot kontrolleri çalıştırılmadı.**
- Önceki Library v0.1.24 ZIP SHA-256 doğrulandı, manifest **41/41 PASS**. Motor import/parse, Windows F5/F9, gerçek oyun akışı, FPS ve EXE hâlâ doğrulanmadı.

## v0.1.26 — Çöküş çağrısı koruması (14 Ekim 2026)

- `_fold()` yalnızca odaklı, başlamış, modal/geçiş/bitiş dışında ve süre bitmiş veya denge sıfırlanmış oyunlarda etki eder. Doğrudan/gecikmiş çağrılar sağlıklı oyunu 3 dakikaya düşüremez.
- Dört yeni Python statik test ve Godot motoru için altı durum kontrolü eklendi. **Gerçek Godot 4.3+ motoru yok; smoke çalıştırılmadı.**
- Kaynak v0.1.25 Library ZIP SHA-256 `c05d86c76e1f2bf90f720b9917483ceb97418c3375d52e0de11c7d5a99ec2e48` eşleşti; eski manifest 42/42 PASS. Sonraki öncelik Godot import/parse, gerçek F5/F9 ve tam oyun akışı.

## v0.1.28 — Bulmaca modalı giriş kapısı

- v0.1.27 Library ZIP SHA-256 `03ca4c965a1de3d4a74ac30319608509610913dbe440aab0a3562e4dd9a46c3a` doğrulandı; önceki kaynak manifesti **44/44 PASS**.
- `_open_fuses`, `_open_locker`, `_open_seal` yalnızca odaklı, başlamış, doğru odadaki, geçişsiz/bitmemiş oyun için açılır; başka modal açıkken onu değiştiremez. Aynı bulmacanın tuşla yenilenmesi korunur.
- `tests/test_puzzle_dialog_entry_contract.py`: 4 yeni **statik** regresyon; `tests/godot_flow_smoke.gd`: 6 yeni **motor bekleyen** kontrol. Godot 4.3+ binary olmadığından gerçek parse/UI/fizik, Windows Alt+Tab, F5/F9 I/O, EXE ve FPS test edilmedi.
- Sonraki iş: gerçek Godot motoru ile `python3 tests/run_godot_smoke.py --require-engine`; özellikle modal yenileme, save/load, dalış, fizik, raycast ve tam akış.

## v0.1.27 — Yanlış cevap cezasının bağlam güvenliği (14 Ekim 2026)

- `_wrong_answer()` doğrudan/gecikmiş çağrılarda yalnızca odaklı ve doğru odadaki açık/çözülmemiş sigorta, dolap veya mühür bulmacasına ceza verir; prolog, not, arka plan ve bitiş sonrası duruma dokunmaz.
- Dört yeni Python **statik** kontrol ve beş yeni **motor bekleyen** smoke sınaması eklendi. Kaynak v0.1.26 Library ZIP SHA-256 doğrulandı, eski manifest **43/43 PASS**. Godot 4.3+ binary bulunmadığından gerçek parse/Windows/UI/fizik/save I/O/performans **YAPILMADI**.
- Sonraki adım: `python3 tests/run_godot_smoke.py --require-engine`; özellikle yeni ceza kontrolleri, F5/F9 kurtarma, yatak→Ev→Okul→mühür→bitiş.

## v0.1.29 — JSON sonrası bulmaca sayılarının tamsayılaştırılması (14 Ekim 2026)

- v0.1.28 Library ZIP SHA-256 `d8ff75452582fdc7860bd03b2f76ae481cb0cedeaed1d1e7ccc45ca0f2b45628` yeniden materialize edilerek doğrulandı; eski manifest 45/45 PASS.
- `DreamSaveCodec.validated` aralık ve ilerleme denetimlerinden sonra `fuses` ve `seal` sayılarını `int` dizilerine normalleştirir. JSON sayılarının float gelmesi halinde F9 sonrası GDScript `%` operatöründe tür hatası riski azaltılır. Legacy ve checksum'lı kayıt biçimleri değişmedi.
- Dört yeni Python **statik** test ve dört yeni Godot motor smoke kontrolü eklendi; gerçek motor olmadığından GDScript parse, kayıt I/O ve bulmaca tuşu davranışı henüz doğrulanmadı.
- Sonraki hedef: Godot 4.3+ ile `python3 tests/run_godot_smoke.py --require-engine`, özellikle F5/F9 sonrası sigorta/mühür değiştirme, checksum/rollback/backup, 16 KiB sınırı, tüm oyun akışı, Windows Alt+Tab ve gerçek FPS.

## v0.1.30 — 14 Ekim 2026 | Görsel taban bütün katmanlarda

- v0.1.29 kaynak ZIP SHA doğrulanarak üzerine uygulandı. `scripts/room_builder.gd` bütün oda yüzeylerine cache'lenmiş PBR materyal eşler; `scripts/main.gd` ve `project.godot` Forward+/ACES, kalite kademeleri ekler. Orijinal puzzle/collision rootları korunur. 15×512px generated PBR map/5 grup vardır, **8K fotogerçek tarama yoktur**. Detay: `docs/VISUAL-QUALITY-TR.md`.
- Godot kurulu olmadığından engine parse/render, Windows EXE, screenshot, FPS/VRAM/frametime testi **YAPILMADI**. İlk iş Godot import/parse ve görsel smoke; ardından 3 sahnede gerçek ekran görüntüsü ve performans ölçümü.

## v0.1.31 — Dünya ölçeğinde büyük yüzey dokusu

- `DreamRooms` tüm odalarda büyük zemin/duvar/tavan yüzeylerine dünya koordinatlı triplanar UV uygular, küçük mobilya UV'sini değiştirmez; materyal cache varyantları ayrıdır.
- Dört yeni Python statik test ve gerçek motor için zemin/duvar/yatak mapping kontrolleri eklendi. Önceki v0.1.30 ZIP SHA doğrulandı, manifest 64/64 PASS.
- Motor yokluğu nedeniyle Godot import/render/FPS/VRAM, F5/F9 I/O, Windows export ve gerçek oynanış **YAPILMADI**. Sonraki öncelik `python3 tests/run_godot_smoke.py --require-engine` ve triplanar maliyetini GPU'da ölçmek.
