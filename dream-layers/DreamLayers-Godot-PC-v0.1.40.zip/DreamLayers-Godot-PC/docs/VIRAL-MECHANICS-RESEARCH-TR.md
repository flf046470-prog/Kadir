# Dream Layers — Başarılı oyunlardan özgün tasarım çıkarımları (2026-10-14)

Bu belge resmi oyun tanıtımlarındaki gözlemlenebilir mekaniklere dayanır. Oyunların uygulama kodları, şifreli dosyaları veya ticari varlıkları sökülmedi/kopyalanmadı; üçüncü taraf ikililerin tersine mühendisliği yapılmadı. Kaynak bağlantıları araştırmayı doğrulamak içindir, satış/oyuncu sayısı iddiası değildir.

| Kamusal referans | Doğrulanan mekanik | Dream Layers için özgün çıkarım |
|---|---|---|
| R.E.P.O. — https://store.steampowered.com/app/3241660/REPO/ | 6 oyuncuya kadar fizik nesneleri taşıma ve yakınlık sesli sohbet | Uzun vadede faza özgü nesneleri iki kişinin birlikte taşıması; önce tek oyuncu fizik prototipi/otorite mimarisi gerekir |
| Lethal Company — https://store.steampowered.com/app/1966720/Lethal_Company/ | Süre ve toplanması gereken hurda kotası | Mevcut 15 dakikalık rüya baskısını görünür ve karar verilebilir risklere bağla; zorunlu grind kopyalama |
| Content Warning — https://store.steampowered.com/app/2881650/Content_Warning/ | Arkadaşlarla tehlikeli görüntüleri kaydetme, oyundaki izlenme geri bildirimi | Birbirine anlatılabilir değişken olaylar, gelecek demo için kolay erişilebilir tekrar izleme; gerçek ekran kaydı henüz yok |
| The Exit 8 — https://store.steampowered.com/app/2653790/The_Exit_8/ | Ortamdaki anomalileri dikkatle fark etme | Rüyanın altı fazındaki görsel/sözel farklılıkları oyuncuya gözlem yaptıracak özgün ipuçlarına dönüştür |
| We Were Here — https://www.wewereheregames.com/games/we-were-here | Ayrılmış iki oyuncunun farklı bilgileri sesli iletişimle birleştirmesi | Gelecek ağ mimarisinde her slotun farklı faz bilgisi görmesi; 2 oyunculu iletişim bulmacası, şu an uygulanmış değil |

## v0.1.36 kapsamında gerçekten uygulanan ilk örnek: Zaman Yankıları

- **Ev katmanında** altı farklı zaman fazına bağlı aynı noktada görünen birer fiziksel bellek işareti bulunur. Doksan saniyede bir görünür işaret ve rengi değişir; `E` ile bakıp incelemek farklı TR/EN hikâye ipucu açar.
- Gizli işaretlerin `collision_layer` değeri `0` yapılır. Godot'ta `visible=false` bir fizik cismini raycast'ten çıkarmaz; bu koruma gerçek etkileşim kusurunu önlemek için gereklidir.
- İnceleme oyunun normal `_can_interact` odak/katman/modal/geçiş engellerinden geçer, açılan pencere kapatılabilir. Denge, süre, sigorta, arşiv veya mühür durumları değişmez; yeni kayıt alanı yoktur.
- Bu, başka bir oyunun anomali cevap döngüsünün kopyası değildir; altı fazlı Dream Layers dünyasındaki isteğe bağlı, özgün hikâye yankılarıdır.

## Takip eden prototipler için ölçülebilir kapılar

1. **Motor kabulü:** Godot 4.3+ ile yeni işaretin import, raycast, görünürlük/çarpışma ve modal smoke kontrollerini çalıştır. Şu an motor ikilisi bulunamadı.
2. **UX testleri:** İlk kez oynayan 5 oyuncuyla ilk işareti bulma/etkileşme süresi, ipucu anlaşılabilirliği, dalış→mühür başarı oranı ölç. Mevcut ölçüm yok.
3. **Viral anın gözlemlenmesi:** Bir faz değişiminin oyuncuda şaşkınlık/anlatma isteği oluşturup oluşturmadığını kullanıcı testleri ve izinli kliplerle değerlendir. İddia edilen viral başarı yok.
4. **Ağ:** Önce deterministik per-slot olay modeli ve testleri; ardından host/server authority, oturum senkronizasyonu ve yakınlık sesli sohbet gizlilik ayarları.
5. **Performans:** Godot gerçek GPU FPS p50/p95, draw-call, VRAM ve 3 oda materyal/LOD karşılaştırması olmadan performans kazanımı ileri sürme.

Telifli modeller/sesler/kodlar izinsiz kullanılmaz. Kamuya açık yayın ve ücretli işlemler kullanıcı izni gerektirir.
