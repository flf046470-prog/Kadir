# Steam / Epic Games Store — ticari sürüme giden kontrol listesi

Bu paket iki mağazaya **gönderilmemiştir** ve satışa hazır değildir. İşaretlenmemiş her madde planlanmıştır.

- [ ] Ürünün temel oynanışını motor içinde bitir, gerçek Windows release build dışa aktar.
- [ ] Hak sahibi olunan model, doku, font, ses ve müzik lisans kayıtlarını tamamla.
- [ ] Uzun süreli test, hatasız açılış/kapanış, ayarlar, kayıt/geri yükleme ve dil testi yap.
- [ ] Steamworks onboarding, vergi/ödeme bilgileri, ürün başına Steam Direct ücreti ve Valve incelemesi.
- [ ] Steam Coming Soon sayfası, uygun görseller, tanıtım videosu ve gerekli yayın bekleme süreleri.
- [ ] Epic Games Developer Portal, içerik/yaş derecelendirmesi ve mağaza incelemesi.
- [ ] Online multiplayer varsa Epic'in PC mağazaları arası crossplay koşullarını ve gerekli test süresini karşıla.
- [ ] Achievements kullanılıyorsa Epic tarafındaki denk gereksinimleri doğrula.
- [ ] Yasal sözleşmeleri, vergileri, gizlilik belgelerini ve ödeme altyapısını doğrula.
- [ ] Platformların en güncel gereksinimlerini yayın gününde tekrar kontrol et.

**13.10.2026 kaynak kontrolü:**
- Steam Direct: https://partner.steamgames.com/doc/gettingstarted/appfee
- Steam release / Coming Soon: https://partner.steamgames.com/doc/store/releasing
- Epic online crossplay: https://dev.epicgames.com/docs/epic-games-store/requirements-guidelines/distribution-requirements/multiplayer-reqs
- Epic achievements: https://dev.epicgames.com/docs/epic-games-store/services/epic-achievements/achievements-setup
