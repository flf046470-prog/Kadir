extends RefCounted
class_name DreamRooms

# Shared PBR material library across Reality / House / School. Reuses imported
# textures/resources: no runtime noise generation or per-frame allocations.
const PBR_PATH := "res://assets/pbr/"
static var _material_cache: Dictionary = {}

# Cached visual-only bevel meshes. Physics remains the original BoxShape3D.
# Keep this selective: a few hero objects benefit from rounded highlights,
# while the architectural shell and small trim remain efficient BoxMesh.
static var _bevel_mesh_cache: Dictionary = {}
const BEVEL_HERO_LABELS := [
    "BedFrame", "Mattress", "Pillow", "Duvet", "Headboard", "Desk",
    "Wardrobe", "OldDesk", "Bookshelf", "FuseCabinet", "SchoolDoor",
    "SchoolDesk", "ArchiveTable", "SealPedestal", "BackDoor"
]


# World-scale texture repetition is only worth the extra shader samples on
# the six large room-shell pieces. Small furniture retains cheap box UVs.
const WORLD_MAPPED_SHELL := ["Floor", "Ceiling", "North", "South", "West", "East"]

static func _world_mapped(label: String) -> bool:
    return label in WORLD_MAPPED_SHELL

static func _surface_kind(label: String) -> String:
    var lower := label.to_lower()
    if "window" in lower or "lamp" in lower or "switch" in lower or "handle" in lower or "plate" in lower or "locker" in lower or "cabinet" in lower or "bell" in lower or "seal" in lower:
        return "metal"
    if "pillow" in lower or "duvet" in lower or "mattress" in lower:
        return "fabric"
    if "floor" in lower and "board" not in lower:
        return "wood"
    if "desk" in lower or "wardrobe" in lower or "shelf" in lower or "bedframe" in lower or "door" in lower or "frame" in lower or "board" in lower:
        return "wood"
    if "pedestal" in lower or "moulding" in lower:
        return "stone"
    return "plaster"

static func _pbr_material(label: String, tint: Color, low_cost_shell := false) -> StandardMaterial3D:
    var kind := _surface_kind(label)
    var world_mapped := _world_mapped(label)
    if low_cost_shell:
        world_mapped = false
    # Separate cached shader variants: identical colors may occur on both
    # large walls and furniture, which must not share triplanar settings.
    var key := kind + ":" + tint.to_html(false) + (":world" if world_mapped else ":uv")
    if _material_cache.has(key):
        return _material_cache[key]
    var result := StandardMaterial3D.new()
    result.albedo_color = tint
    result.metallic = 0.72 if kind == "metal" else 0.0
    result.roughness = 1.0  # Roughness texture carries the calibrated variation.
    result.albedo_texture = load(PBR_PATH + kind + "_albedo.png") as Texture2D
    result.roughness_texture = load(PBR_PATH + kind + "_roughness.png") as Texture2D
    result.normal_enabled = true
    result.normal_texture = load(PBR_PATH + kind + "_normal.png") as Texture2D
    result.normal_scale = 0.55
    result.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    result.uv1_triplanar = world_mapped
    result.uv1_world_triplanar = world_mapped
    # The shell spans 12 m; repeating a 512px tile only twice made surface
    # grain metres wide. World triplanar keeps wall/floor detail consistent
    # at roughly 0.75 texture repeats per metre across all three rooms.
    result.uv1_scale = Vector3(0.75, 0.75, 0.75) if world_mapped else Vector3(2.0, 2.0, 2.0)
    _material_cache[key] = result
    return result

# LOW graphics tier skips the triplanar shader on six room shell pieces.
# Only MeshInstance3D materials are swapped: collision, metadata and geometry
# remain untouched. MEDIUM/HIGH reuse the cached world-mapped variants.
static func set_shell_mapping(rooms: Dictionary, low_cost: bool) -> void:
    for layer in rooms.keys():
        var room: Node3D = rooms[layer]
        for label in WORLD_MAPPED_SHELL:
            var part := room.get_node_or_null(label) as Node3D
            if part == null:
                continue
            for child in part.get_children():
                if child is MeshInstance3D:
                    var mesh := child as MeshInstance3D
                    var current := mesh.material_override as StandardMaterial3D
                    if current != null:
                        mesh.material_override = _pbr_material(label, current.albedo_color, low_cost)

static func material(color: Color, metallic := 0.0, roughness := 0.86, emit := false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = roughness
    if emit:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = 0.9
    return m

# Compute a smooth, outward-facing, six-sided beveled box entirely in mesh
# space. Positions/normals are generated once per size and reused by all
# instances (including the five identical school lockers). Rounded surfaces
# provide broad, plausible specular highlights under the PBR light rig.
# IMPORTANT: this is display geometry only; collisions never use this mesh.
static func _bevel_axis(half_span: float, bevel: float) -> PackedFloat32Array:
    return PackedFloat32Array([
        -half_span, -half_span + bevel * 0.5, -half_span + bevel,
        0.0, half_span - bevel, half_span - bevel * 0.5, half_span
    ])

static func _beveled_box_mesh(size: Vector3, desired_bevel := 0.075) -> ArrayMesh:
    var half := size * 0.5
    # Avoid inverted faces on thin books, cushions and desk tops.
    var bevel := minf(desired_bevel, minf(half.x, minf(half.y, half.z)) * 0.44)
    var cache_key := str(size) + ":" + str(bevel)
    if _bevel_mesh_cache.has(cache_key):
        return _bevel_mesh_cache[cache_key]
    var face_normals := [Vector3.RIGHT, Vector3.LEFT, Vector3.UP,
        Vector3.DOWN, Vector3.BACK, Vector3.FORWARD]
    # Each local U cross V is the outward face normal (triangle winding).
    var face_u := [Vector3.FORWARD, Vector3.BACK, Vector3.RIGHT,
        Vector3.RIGHT, Vector3.RIGHT, Vector3.LEFT]
    var face_v := [Vector3.UP, Vector3.UP, Vector3.FORWARD,
        Vector3.BACK, Vector3.UP, Vector3.UP]
    var vertices := PackedVector3Array()
    var normals := PackedVector3Array()
    var uvs := PackedVector2Array()
    var triangles := PackedInt32Array()
    for face in range(6):
        var direction: Vector3 = face_normals[face]
        var axis_u: Vector3 = face_u[face]
        var axis_v: Vector3 = face_v[face]
        var width: float = axis_u.abs().dot(half)
        var height: float = axis_v.abs().dot(half)
        var u_steps := _bevel_axis(width, bevel)
        var v_steps := _bevel_axis(height, bevel)
        var row_length := u_steps.size()
        var base_index := vertices.size()
        var face_center := Vector3(direction.x * half.x,
            direction.y * half.y, direction.z * half.z)
        for v_step in v_steps:
            for u_step in u_steps:
                var box_point := face_center + axis_u * u_step + axis_v * v_step
                # Clamp to the un-beveled interior: a vector from this inner
                # box to the original cube surface is the rounded-box normal.
                var core := Vector3(
                    clampf(box_point.x, -half.x + bevel, half.x - bevel),
                    clampf(box_point.y, -half.y + bevel, half.y - bevel),
                    clampf(box_point.z, -half.z + bevel, half.z - bevel))
                var outward := (box_point - core).normalized()
                vertices.append(core + outward * bevel)
                normals.append(outward)
                uvs.append(Vector2((u_step + width) / (2.0 * width),
                    (v_step + height) / (2.0 * height)))
        for row in range(v_steps.size() - 1):
            for col in range(row_length - 1):
                var first := base_index + row * row_length + col
                # U x V points outward, but Godot ArrayMesh uses clockwise
                # front faces (opposite mathematical cross-product winding).
                # Flip both triangles so exterior faces aren't back-face culled.
                # Stored outward normals remain unchanged for PBR lighting.
                triangles.append_array(PackedInt32Array([
                    first, first + row_length, first + 1,
                    first + 1, first + row_length, first + row_length + 1]))
    var buffers := []
    buffers.resize(Mesh.ARRAY_MAX)
    buffers[Mesh.ARRAY_VERTEX] = vertices
    buffers[Mesh.ARRAY_NORMAL] = normals
    buffers[Mesh.ARRAY_TEX_UV] = uvs
    buffers[Mesh.ARRAY_INDEX] = triangles
    var result := ArrayMesh.new()
    result.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, buffers)
    _bevel_mesh_cache[cache_key] = result
    return result

static func _use_bevel_visual(label: String) -> bool:
    return label in BEVEL_HERO_LABELS or label.begins_with("Locker_")

static func cuboid(parent: Node3D, label: String, point: Vector3, size: Vector3, tint: Color, solid := true, action := "", reach := 3.8) -> Node3D:
    var root: Node3D
    if solid:
        var physics_body := StaticBody3D.new()
        physics_body.collision_layer = 1
        physics_body.collision_mask = 1
        root = physics_body
        var hit := CollisionShape3D.new()
        hit.name = "CollisionShape3D"
        var shape := BoxShape3D.new()
        shape.size = size
        hit.shape = shape
        root.add_child(hit)
    else:
        root = Node3D.new()
    root.name = label
    root.position = point
    if action != "":
        root.set_meta("action", action)
        root.set_meta("reach_m", reach)
    var mesh := MeshInstance3D.new()
    mesh.name = "Visual"
    if _use_bevel_visual(label):
        mesh.mesh = _beveled_box_mesh(size)
    else:
        var box := BoxMesh.new()
        box.size = size
        mesh.mesh = box
    mesh.material_override = _pbr_material(label, tint)
    root.add_child(mesh)
    parent.add_child(root)
    return root

# Visual-only rounded hardware. Keep gameplay hit boxes as their original
# StaticBody3D cuboids; decorative cylinders never acquire a collision shape.
static func rounded_detail(parent: Node3D, label: String, point: Vector3, radius: float, height: float, tint: Color, face_z := false) -> Node3D:
    var root := Node3D.new()
    root.name = label
    root.position = point
    root.add_to_group("dream_rounded_details")
    var mesh := MeshInstance3D.new()
    mesh.name = "Visual"
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = radius
    cylinder.bottom_radius = radius
    cylinder.height = height
    cylinder.radial_segments = 12
    mesh.mesh = cylinder
    mesh.material_override = _pbr_material(label, tint)
    if face_z:
        mesh.rotation_degrees.x = 90.0
    root.add_child(mesh)
    parent.add_child(root)
    return root

# Match small hardware silhouette cost to F3 without touching gameplay
# colliders or materials. Each rounded_detail owns a unique CylinderMesh.
# LOW=8, MEDIUM=12, HIGH=24 sides; update on quality changes, not per frame.
static func set_rounded_detail_lod(rooms: Dictionary, quality_level: int) -> void:
    var segments := 8 if quality_level == 0 else (24 if quality_level == 2 else 12)
    for layer in rooms.keys():
        var room: Node3D = rooms[layer]
        for detail in room.get_children():
            if not detail.is_in_group("dream_rounded_details"):
                continue
            var visual := detail.get_node_or_null("Visual") as MeshInstance3D
            if visual == null or not (visual.mesh is CylinderMesh):
                continue
            var cylinder := visual.mesh as CylinderMesh
            if cylinder.radial_segments != segments:
                cylinder.radial_segments = segments

static func light(parent: Node3D, point: Vector3, tint: Color, energy: float, reach: float) -> void:
    var omni := OmniLight3D.new()
    omni.position = point
    omni.light_color = tint
    omni.light_energy = energy
    omni.omni_range = reach
    omni.shadow_enabled = false
    omni.add_to_group("dream_lamps")
    parent.add_child(omni)

static func text_sign(parent: Node3D, value: String, point: Vector3, scale_value := 0.006) -> void:
    var label := Label3D.new()
    label.text = value
    label.position = point
    label.font_size = 30
    label.pixel_size = scale_value
    label.modulate = Color(0.92, 0.81, 0.64)
    parent.add_child(label)

static func common_shell(parent: Node3D, palette: Array, ceiling_height := 3.6) -> void:
    cuboid(parent, "Floor", Vector3(0, -0.15, 0), Vector3(12, 0.30, 12), palette[0])
    cuboid(parent, "Ceiling", Vector3(0, ceiling_height, 0), Vector3(12, 0.24, 12), palette[1])
    cuboid(parent, "North", Vector3(0, ceiling_height / 2.0, -6), Vector3(12, ceiling_height, 0.30), palette[1])
    cuboid(parent, "South", Vector3(0, ceiling_height / 2.0, 6), Vector3(12, ceiling_height, 0.30), palette[1])
    cuboid(parent, "West", Vector3(-6, ceiling_height / 2.0, 0), Vector3(0.30, ceiling_height, 12), palette[1])
    cuboid(parent, "East", Vector3(6, ceiling_height / 2.0, 0), Vector3(0.30, ceiling_height, 12), palette[1])
    # Continuous skirting, upper cornices and vertical seams: geometry stays
    # decorative so puzzle collision / reach / player navigation are unchanged.
    for side in [-1.0, 1.0]:
        cuboid(parent, "SkirtingX", Vector3(0, 0.13, side * 5.81), Vector3(11.65, 0.25, 0.12), palette[2], false)
        cuboid(parent, "SkirtingZ", Vector3(side * 5.81, 0.13, 0), Vector3(0.12, 0.25, 11.65), palette[2], false)
        cuboid(parent, "CorniceX", Vector3(0, ceiling_height - 0.12, side * 5.81), Vector3(11.65, 0.14, 0.15), palette[2], false)
        cuboid(parent, "CorniceZ", Vector3(side * 5.81, ceiling_height - 0.12, 0), Vector3(0.15, 0.14, 11.65), palette[2], false)
    for x in [-5.5, 5.5]:
        for z in [-5.5, 5.5]:
            cuboid(parent, "Moulding", Vector3(x, 0.08, z), Vector3(0.18, 0.16, 0.18), palette[2], false)

static func build_reality() -> Node3D:
    var room := Node3D.new()
    room.name = "RealityRoom"
    common_shell(room, [Color("a79b8c"), Color("d1c6b7"), Color("b3a38f")])
    cuboid(room, "Window", Vector3(0, 2.1, -5.79), Vector3(3.3, 1.5, 0.16), Color("203642"), false)
    cuboid(room, "WindowFrame", Vector3(0, 2.1, -5.65), Vector3(0.09, 1.6, 0.08), Color("b0a28d"), false)
    cuboid(room, "WindowMullion", Vector3(0, 2.1, -5.56), Vector3(3.35, 0.05, 0.06), Color("8e8981"), false)
    cuboid(room, "WindowSill", Vector3(0, 1.31, -5.53), Vector3(3.6, 0.11, 0.3), Color("aba398"), false)
    cuboid(room, "BedFrame", Vector3(-2.55, 0.40, -2.30), Vector3(2.6, 0.72, 4.0), Color("45342d"), true, "bed", 2.4)
    cuboid(room, "Mattress", Vector3(-2.55, 0.81, -2.30), Vector3(2.35, 0.23, 3.65), Color("9ca6aa"), false)
    cuboid(room, "Pillow", Vector3(-2.55, 0.99, -3.68), Vector3(1.28, 0.14, 0.65), Color("e3d8ca"), false)
    cuboid(room, "Duvet", Vector3(-2.55, 1.00, -1.72), Vector3(2.35, 0.14, 2.1), Color("7b8079"), false)
    cuboid(room, "ThrowBlanket", Vector3(-2.55, 1.088, -0.91), Vector3(2.30, 0.035, 0.45), Color("696451"), false)
    cuboid(room, "Headboard", Vector3(-2.55, 1.35, -4.29), Vector3(2.65, 1.14, 0.16), Color("aaa095"), false)
    for bx in [-3.65, -1.45]:
        cuboid(room, "BedLeg", Vector3(bx, 0.22, -0.6), Vector3(0.12, 0.35, 0.12), Color("44392e"), false)
    cuboid(room, "Desk", Vector3(3.25, 0.77, -3), Vector3(2.5, 0.18, 1.25), Color("483b32"))
    cuboid(room, "DeskLeg", Vector3(4.28, 0.35, -3.40), Vector3(0.14, 0.75, 0.14), Color("382c26"))
    # Optional first-person objective: a clock is the player's reality anchor.
    # Its visible face/hand are decorative, only the clock body is interactive.
    cuboid(room, "PrologueClock", Vector3(2.60, 1.00, -3.0),
        Vector3(0.48, 0.28, 0.28), Color("725d47"), true, "prologue_clock", 2.3)
    rounded_detail(room, "ClockFace", Vector3(2.60, 1.04, -2.82),
        0.16, 0.035, Color("d5c4a4"), true)
    cuboid(room, "ClockHand", Vector3(2.60, 1.06, -2.78),
        Vector3(0.028, 0.14, 0.018), Color("473d38"), false)
    cuboid(room, "Wardrobe", Vector3(4.8, 1.55, 1.75), Vector3(1.5, 2.95, 2.65), Color("453c36"))
    cuboid(room, "WardrobeHandle", Vector3(3.97, 1.6, 1.7), Vector3(0.06, 0.42, 0.10), Color("b4a282"), false)
    cuboid(room, "LampShade", Vector3(3.20, 1.32, -3.0), Vector3(0.55, 0.32, 0.55), Color("e8ce9b"), false)
    rounded_detail(room, "LampBaseRound", Vector3(3.20, 0.89, -3.0), 0.19, 0.06, Color("91867a"))
    rounded_detail(room, "LampStemRound", Vector3(3.20, 1.11, -3.0), 0.025, 0.40, Color("91867a"))
    light(room, Vector3(3.0, 2.7, -2.5), Color("ffe0af"), 1.1, 8.0)
    light(room, Vector3(-1, 2.8, 0.7), Color("d8e1e5"), 0.5, 6.5)
    text_sign(room, "DREAM LAYERS", Vector3(0, 2.6, -5.58))
    return room

static func build_house() -> Node3D:
    var room := Node3D.new()
    room.name = "HouseRoom"
    common_shell(room, [Color("806b58"), Color("b5a18a"), Color("765f4d")])
    for idx in range(7):
        cuboid(room, "Floorboard_%d" % idx, Vector3(-5.0 + idx * 1.65, 0.015, 0), Vector3(0.025, 0.01, 11.6), Color("241f1c"), false)
    cuboid(room, "FuseCabinet", Vector3(4.65, 1.52, -4.7), Vector3(1.95, 1.50, 0.45), Color("828384"), true, "fuses")
    for idx in range(3):
        cuboid(room, "FuseSwitch_%d" % idx, Vector3(4.12 + idx * 0.54, 1.65, -4.42), Vector3(0.18, 0.50, 0.15), Color("cf9e46"), false)
    cuboid(room, "OldDesk", Vector3(-3.8, 0.82, -3.15), Vector3(2.6, 0.20, 1.5), Color("4f3026"))
    cuboid(room, "ClueBook", Vector3(-3.8, 1.00, -3.10), Vector3(0.95, 0.14, 0.77), Color("a87a45"), true, "house_note")
    cuboid(room, "Bookshelf", Vector3(-5.2, 1.5, 1.2), Vector3(1.3, 3.0, 3.1), Color("3f271e"))
    for r in range(3):
        cuboid(room, "Shelf%d" % r, Vector3(-4.44, 0.62 + r * 0.84, 1.2), Vector3(0.13, 0.09, 2.85), Color("bd9a75"), false)
    cuboid(room, "SchoolDoor", Vector3(1.65, 1.47, -5.69), Vector3(2.2, 2.95, 0.27), Color("625b52"), true, "school_door")
    cuboid(room, "DoorHandle", Vector3(2.38, 1.03, -5.43), Vector3(0.20, 0.05, 0.12), Color("a8a29a"), false)
    cuboid(room, "DoorPlate", Vector3(1.65, 2.65, -5.48), Vector3(1.2, 0.24, 0.04), Color("a68d63"), false)
    cuboid(room, "WakeBell", Vector3(4.6, 0.88, 3.4), Vector3(0.80, 1.7, 0.80), Color("bb9a60"), true, "wake_bell", 1.5)
    rounded_detail(room, "BellButtonRound", Vector3(4.6, 1.79, 3.4), 0.18, 0.12, Color("cfb47d"))
    rounded_detail(room, "DoorKnobRound", Vector3(2.38, 1.03, -5.31), 0.09, 0.13, Color("b4aa92"), true)
    light(room, Vector3(-2.0, 2.8, -2.7), Color("ffc88c"), 1.1, 8.0)
    light(room, Vector3(4.4, 2.8, 3.5), Color("f1e9db"), 0.6, 5.5)
    text_sign(room, "HOUSE / EV", Vector3(-0.4, 2.8, -5.56))
    return room

static func build_school() -> Node3D:
    var room := Node3D.new()
    room.name = "SchoolRoom"
    common_shell(room, [Color("8a8985"), Color("c6c2b9"), Color("b9afa1")], 4.0)
    for index in range(5):
        cuboid(room, "Locker_%d" % index, Vector3(-5.0 + index * 1.0, 1.25, -5.25), Vector3(0.85, 2.45, 0.68), Color("657879"), true, "locker" if index == 2 else "")
    for index in range(5):
        rounded_detail(room, "LockerKnobRound_%d" % index,
            Vector3(-5.0 + index * 1.0, 1.35, -4.85), 0.055, 0.10,
            Color("adb3ad"), true)
    for index in range(5):
        var vent_x := -5.0 + index * 1.0
        for vent_y in [1.98, 2.07, 2.16]:
            cuboid(room, "LockerVent", Vector3(vent_x, vent_y, -4.888), Vector3(0.45, 0.012, 0.016), Color("464d49"), false)
    for x in [-3.1, 0.2, 3.4]:
        cuboid(room, "SchoolDesk", Vector3(x, 0.78, 0.0), Vector3(2.2, 0.14, 1.1), Color("87775f"))
        cuboid(room, "DeskBase", Vector3(x, 0.37, 0.1), Vector3(0.13, 0.74, 0.9), Color("545b5c"), false)
    cuboid(room, "ArchiveTable", Vector3(3.95, 0.80, -3.5), Vector3(2.6, 0.20, 1.5), Color("857052"))
    cuboid(room, "ArchiveJournal", Vector3(3.95, 0.98, -3.5), Vector3(0.80, 0.16, 0.62), Color("b69a69"), true, "archive")
    cuboid(room, "SealPedestal", Vector3(4.5, 0.83, 3.9), Vector3(1.3, 1.6, 1.2), Color("626267"), true, "seal")
    rounded_detail(room, "SealDialRound", Vector3(4.5, 1.69, 3.9), 0.36, 0.10, Color("b3a17b"))
    cuboid(room, "BackDoor", Vector3(0.0, 1.48, 5.68), Vector3(2.20, 2.94, 0.28), Color("4b423e"), true, "return_house")
    light(room, Vector3(0.0, 3.25, 0.0), Color("d3e3ef"), 1.25, 10.5)
    light(room, Vector3(4.2, 2.9, -3.4), Color("f0f0e7"), 0.8, 5.5)
    text_sign(room, "ARCHIVE / ARSIV", Vector3(2.8, 3.0, -5.51))
    return room

static func add_personal_phase_props(room: Node3D) -> Array[Node3D]:
    var variants: Array[Node3D] = []
    var tones := [Color("c5a16f"), Color("92b4b1"), Color("9890b5"), Color("c9a3a0"), Color("6f97a7"), Color("a6bc80")]
    for index in range(6):
        # One interactable, physical marker per phase; inactive markers have
        # their collision layers disabled by main._update_phase().  All use
        # the same position, never creating six overlapping raycast targets.
        var item := cuboid(room, "TemporalVariant_%d" % index,
            Vector3(-0.8, 1.2, -4.9), Vector3(0.8 + index * 0.035, 1.1 + index * 0.05, 0.28),
            tones[index], true, "phase_echo", 2.7)
        item.visible = index == 0
        item.collision_layer = 1 if index == 0 else 0
        variants.append(item)
    return variants
