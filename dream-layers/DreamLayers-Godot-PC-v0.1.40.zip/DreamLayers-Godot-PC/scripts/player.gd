extends CharacterBody3D
class_name DreamPlayer

const WALK_SPEED := 4.4
const SPRINT_SPEED := 6.4
const MOUSE_SENSITIVITY := 0.0019
const INTERACT_RANGE := 3.8

var can_move := true
var gravity_force := 20.0
var camera: Camera3D
var ray: RayCast3D
var eye: Node3D

func _ready() -> void:
    name = "DreamPlayer"
    collision_layer = 1
    collision_mask = 1
    var capsule := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.30
    shape.height = 1.75
    capsule.shape = shape
    capsule.position.y = 0.91
    add_child(capsule)

    eye = Node3D.new()
    eye.position.y = 1.57
    add_child(eye)
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 77.0
    eye.add_child(camera)
    ray = RayCast3D.new()
    ray.enabled = true
    ray.target_position = Vector3(0.0, 0.0, -INTERACT_RANGE)
    ray.collision_mask = 1
    camera.add_child(ray)
    # The camera/ray are nested under Eye, not directly under the physics body.
    # Explicitly exclude our capsule so the interaction ray only hits the world.
    ray.add_exception(self)

func _unhandled_input(event: InputEvent) -> void:
    if not can_move:
        return
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * MOUSE_SENSITIVITY)
        eye.rotate_x(-event.relative.y * MOUSE_SENSITIVITY)
        eye.rotation.x = clampf(eye.rotation.x, deg_to_rad(-82.0), deg_to_rad(82.0))

func _physics_process(delta: float) -> void:
    # A dialog, background window, transition or completed game freezes the
    # body itself, not just keyboard input. Otherwise residual horizontal
    # velocity and gravity can move the player while controls are disabled.
    if not can_move:
        velocity = Vector3.ZERO
        return
    if not is_on_floor():
        velocity.y -= gravity_force * delta
    else:
        velocity.y = 0.0
    var direction := Vector3.ZERO
    if can_move:
        var x := float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A))
        var z := float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W))
        direction = (global_transform.basis * Vector3(x, 0.0, z)).normalized()
    var target_speed := SPRINT_SPEED if Input.is_key_pressed(KEY_SHIFT) else WALK_SPEED
    var target := direction * target_speed
    var blend := minf(1.0, 12.0 * delta)
    velocity.x = lerpf(velocity.x, target.x, blend)
    velocity.z = lerpf(velocity.z, target.z, blend)
    move_and_slide()

func looked_at_action() -> String:
    ray.force_raycast_update()
    if not ray.is_colliding():
        return ""
    var body := ray.get_collider() as CollisionObject3D
    if body == null:
        return ""
    var action := str(body.get_meta("action", ""))
    if action == "":
        return ""
    # Measure to the visible ray hit, not the centre of a large object (e.g. the bed).
    # The ray itself is limited to INTERACT_RANGE and blocks through-wall use.
    var hit_point := ray.get_collision_point()
    var allowed := float(body.get_meta("reach_m", INTERACT_RANGE))
    if not _hit_within_reach(hit_point, allowed):
        return ""
    return action

func _hit_within_reach(hit_point: Vector3, allowed: float) -> bool:
    # Measure the actual 3D camera-to-hit distance. A horizontal-only check
    # allowed objects far above/below the player to bypass their reach limit.
    return allowed >= 0.0 and ray.global_position.distance_to(hit_point) <= allowed
