extends Node3D

# Prototype gameplay controller. The original v0.9.1 game parity is NOT claimed.
const EPOCH_SECONDS := 90.0
const INITIAL_SECONDS := 900.0
const DIVE_SECONDS := 12.0
const PROLOGUE_SHIFT_SECONDS := 2.2
const FOLD_SECONDS := 180.0
const SAVE_FILE := "user://dream_layers_save_v1.json"
const BACKUP_FILE := "user://dream_layers_save_v1.bak.json"
const TEMP_FILE := "user://dream_layers_save_v1.tmp.json"
const MAX_SAVE_BYTES := 16384
const ACTION_LAYERS := {
    "bed": "reality", "prologue_clock": "reality",
    "house_note": "house", "fuses": "house", "school_door": "house", "wake_bell": "house",
    "phase_echo": "house",
    "locker": "school", "archive": "school", "seal": "school", "return_house": "school"
}

var rooms: Dictionary = {}
var temporal_props: Array[Node3D] = []
var player: DreamPlayer
var overlay: DreamOverlay
var current_layer := "reality"
var language := "tr"
var player_slot := 0
var elapsed_seconds := 0.0
var remaining_seconds := INITIAL_SECONDS
var stability := 100
var collapse_count := 0
var current_phase := -1
var run_started := false
var game_complete := false
var transitioning := false
var dive_remaining_seconds := 0.0
var app_has_focus := true
var discard_next_focused_delta := false
var transition_token := 0
var active_dialog := ""
var fuse_values := [1, 1, 1]
var seal_values := [0, 0, 0, 0]
var power_on := false
var locker_open := false
var archive_found := false
var seal_open := false
var quality := 1
var rng_seed := 4271
# Single-player, optional cinematic onboarding; not part of the checkpoint schema.
var prologue_step := 0
var prologue_shift_remaining := 0.0

func loc(turkish: String, english: String) -> String:
    return turkish if language == "tr" else english

func _ready() -> void:
    _setup_environment()
    rooms["reality"] = DreamRooms.build_reality()
    rooms["house"] = DreamRooms.build_house()
    rooms["school"] = DreamRooms.build_school()
    add_child(rooms["reality"])
    add_child(rooms["house"])
    add_child(rooms["school"])
    rooms["reality"].position = Vector3(0, 0, 0)
    rooms["house"].position = Vector3(30, 0, 0)
    rooms["school"].position = Vector3(60, 0, 0)
    temporal_props = DreamRooms.add_personal_phase_props(rooms["house"])
    player = DreamPlayer.new()
    add_child(player)
    _move_to("reality")
    overlay = DreamOverlay.new()
    add_child(overlay)
    _apply_quality()
    _intro()

func _setup_environment() -> void:
    var env := WorldEnvironment.new()
    var background := Environment.new()
    background.background_mode = Environment.BG_COLOR
    background.background_color = Color(0.015, 0.022, 0.028)
    background.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    background.ambient_light_color = Color(0.56, 0.56, 0.55)
    background.ambient_light_energy = 0.45
    # ACES filmic highlight rolloff prevents harsh clipped warm lights.
    background.tonemap_mode = Environment.TONE_MAPPER_ACES
    background.tonemap_exposure = 0.85
    background.tonemap_white = 6.0
    background.ssao_radius = 1.0
    background.ssao_intensity = 1.25
    background.ssil_intensity = 0.4
    env.environment = background
    add_child(env)
    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-50, -26, 0)
    light.light_color = Color(0.58, 0.69, 0.79)
    light.light_energy = 0.30
    light.shadow_enabled = false
    add_child(light)

func _intro() -> void:
    # GTA-style: teach the first interaction inside a playable objective,
    # not a long menu tutorial. Inception-inspired: an ordinary room is subtly wrong.
    _dialog("DREAM LAYERS · 01:47", loc(
        "PROLOG — Saat bir dakika geri gitti. Oysa hiçbir şey durmadı.\n\nÖnce masadaki saati incele. Sonra yatağa git.\n\nWASD: yürü · Fare: bak · Shift: koş · E: incele · Esc: imleç",
        "PROLOGUE — The clock lost a minute. Nothing else stopped.\n\nInspect the clock on the desk. Then reach the bed.\n\nWASD: move · Mouse: look · Shift: run · E: inspect · Esc: cursor"),
        [{"id":"intro_start", "label":loc("Odaya gir", "Enter the room")}], "intro")

func _inspect_prologue_clock() -> void:
    # Every callback has to be valid in the current scene and foreground.
    if not _can_interact("prologue_clock") or prologue_step != 1 or run_started:
        return
    prologue_step = 2
    _dialog(loc("01:47 → 01:46", "01:47 → 01:46"), loc(
        "Akrep ters yönde ilerledi. Pencerenin yansıması ise hâlâ eski saati gösteriyor.\n\nBu odada gördüğün her şey doğru olmayabilir. Gözlerini yataktan ayırma.",
        "The hour hand moved backward, but its reflection kept the old time.\n\nNot everything in this room can be trusted. Find the bed."),
        [{"id":"close", "label":loc("Odaya bak", "Look around")}], "prologue_clock")

func _begin_prologue_shift() -> void:
    # Only decoration moves; keep camera, physics, and player controls untouched.
    if current_layer != "reality" or prologue_step != 2 or not app_has_focus or run_started:
        return
    prologue_shift_remaining = PROLOGUE_SHIFT_SECONDS

func _tick_prologue_shift(delta: float) -> void:
    # Freeze the effect on Alt+Tab; no camera shake, forced viewpoint, or collision.
    if not app_has_focus or current_layer != "reality" or prologue_shift_remaining <= 0.0:
        return
    prologue_shift_remaining = maxf(0.0, prologue_shift_remaining - maxf(0.0, delta))
    var t := 1.0 - prologue_shift_remaining / PROLOGUE_SHIFT_SECONDS
    var eased := t * t * (3.0 - 2.0 * t)
    var room: Node3D = rooms["reality"]
    (room.get_node("WindowMullion") as Node3D).rotation.z = deg_to_rad(8.0) * eased
    (room.get_node("ClockHand") as Node3D).rotation.z = deg_to_rad(-100.0) * eased
    (room.get_node("LampShade") as Node3D).rotation.z = deg_to_rad(-5.0) * eased

func _move_to(layer_name: String) -> void:
    current_layer = layer_name
    for key in rooms.keys():
        var room: Node3D = rooms[key]
        room.visible = key == layer_name
    var destination: Node3D = rooms[layer_name]
    player.global_position = destination.global_position + Vector3(0, 0.15, 3.0)
    player.velocity = Vector3.ZERO
    player.rotation = Vector3.ZERO
    player.eye.rotation = Vector3.ZERO
    if current_layer == "house":
        _update_phase(true)

func _notification(what: int) -> void:
    # Godot may keep processing frames while the window is in the background.
    # Do not consume the player's timed dream or accept gameplay keys then.
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        app_has_focus = false
        # The first frame after returning may include background wall-clock time.
        discard_next_focused_delta = true
        if player != null:
            player.can_move = false
    elif what == NOTIFICATION_APPLICATION_FOCUS_IN:
        app_has_focus = true

func _process(delta: float) -> void:
    var focused_delta := maxf(0.0, delta)
    if app_has_focus and discard_next_focused_delta:
        # Ignore one potentially oversized resume frame; subsequent frames
        # resume normal countdowns without charging time spent in another app.
        focused_delta = 0.0
        discard_next_focused_delta = false
    _tick_prologue_shift(focused_delta)
    # Count focused play time, not wall-clock time. The dive must not finish
    # while Windows is switched away from the game (Alt+Tab / focus loss).
    var was_transitioning := transitioning
    if transitioning and app_has_focus:
        dive_remaining_seconds = maxf(0.0, dive_remaining_seconds - focused_delta)
        if dive_remaining_seconds <= 0.0:
            _finish_dive(transition_token)
    # Do not charge the dream clock for the frame that finishes a dive.
    if run_started and app_has_focus and not was_transitioning and not game_complete and not overlay.is_dialog_open and not transitioning:
        elapsed_seconds += focused_delta
        remaining_seconds = maxf(0.0, remaining_seconds - focused_delta)
        _update_phase()
        if remaining_seconds <= 0.0 or stability <= 0:
            _fold()
    player.can_move = app_has_focus and not overlay.is_dialog_open and not transitioning and not game_complete
    var action := ""
    if player.can_move:
        action = player.looked_at_action()
    var title := loc("GERÇEKLİK", "REALITY")
    if current_layer == "house":
        title = loc("EV", "HOUSE")
    elif current_layer == "school":
        title = loc("OKUL", "SCHOOL")
    var stats := "%s  |  %02d:%02d  |  %s: %d  |  %s: %d/6  |  FPS: %d" % [
        title, int(remaining_seconds / 60.0), int(remaining_seconds) % 60,
        loc("Denge", "Stability"), stability, loc("Faz", "Phase"), current_phase + 1,
        Engine.get_frames_per_second()]
    var hint := ""
    if action != "":
        hint = loc("[E] Etkileşim: ", "[E] Interact: ") + _action_name(action)
    if current_layer == "reality" and not run_started and not overlay.is_dialog_open and hint == "":
        if prologue_step == 1:
            hint = loc("GÖREV 1/2 — Masadaki saati incele [E]", "OBJECTIVE 1/2 — Inspect the desk clock [E]")
        elif prologue_step == 2:
            hint = loc("GÖREV 2/2 — Yatağa git [E]", "OBJECTIVE 2/2 — Reach the bed [E]")
    overlay.set_hud(stats, hint)

func _unhandled_input(event: InputEvent) -> void:
    if event is not InputEventKey or not event.pressed or event.echo:
        return
    if not app_has_focus:
        return
    if event.keycode == KEY_F5:
        _save_game()
        return
    if event.keycode == KEY_F9:
        _load_game()
        return
    if event.keycode == KEY_F2:
        language = "en" if language == "tr" else "tr"
        overlay.toast(loc("Dil: Türkçe", "Language: English"))
        return
    if event.keycode == KEY_F3:
        quality = (quality + 1) % 3
        _apply_quality()
        return
    if event.keycode == KEY_ESCAPE:
        if overlay.is_dialog_open:
            return
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
        return
    if overlay.is_dialog_open:
        return
    if event.keycode == KEY_R and transitioning:
        transition_token += 1
        transitioning = false
        dive_remaining_seconds = 0.0
        overlay.toast(loc("Dalış iptal edildi", "Dive canceled"))
        return
    if event.keycode == KEY_E and not transitioning and not game_complete:
        _interact(player.looked_at_action())

func _save_game() -> void:
    # Reject direct/stale save calls while the window is unfocused too. The
    # keyboard F5 handler already has this gate, but callers can invoke the
    # method without passing through _unhandled_input.
    if not app_has_focus:
        return
    if transitioning or overlay.is_dialog_open:
        overlay.toast(loc("Pencere veya dalış açıkken kaydedilemez", "Cannot save during a dialog or dive"))
        return
    var payload := DreamSaveCodec.validated(DreamSaveCodec.capture(self))
    if payload.is_empty():
        overlay.toast(loc("Geçersiz oyun durumu: kayıt iptal", "Invalid game state: save canceled"))
        return
    # Validate and bound the complete serialized checkpoint before opening
    # WRITE mode, which truncates any pre-existing pending file immediately.
    var encoded := DreamSaveCodec.encode_checkpoint(payload)
    if encoded.is_empty() or encoded.to_utf8_buffer().size() > MAX_SAVE_BYTES:
        overlay.toast(loc("Kayıt boyutu veya içeriği geçersiz", "Invalid save size or content"))
        return
    var file := FileAccess.open(TEMP_FILE, FileAccess.WRITE)
    if file == null:
        overlay.toast(loc("Kayıt dosyası açılamadı", "Could not open save file"))
        return
    file.store_string(encoded)
    file.flush()
    var write_error := file.get_error()
    file.close()
    if write_error != OK:
        overlay.toast(loc("Kayıt yazılamadı", "Save write failed"))
        return
    # Verify the bytes on disk before touching the previous checkpoint.
    if _read_checkpoint(TEMP_FILE).is_empty():
        overlay.toast(loc("Yeni kayıt doğrulanamadı", "New checkpoint failed verification"))
        return
    var target := ProjectSettings.globalize_path(SAVE_FILE)
    var backup := ProjectSettings.globalize_path(BACKUP_FILE)
    var temporary := ProjectSettings.globalize_path(TEMP_FILE)
    var primary_valid := not _read_checkpoint(SAVE_FILE).is_empty()
    if not _promote_checkpoint(temporary, target, backup, primary_valid):
        overlay.toast(loc("Kayıt tamamlanamadı", "Save could not be finalized"))
        return
    overlay.toast(loc("Kontrol noktası kaydedildi (F9: yükle)", "Checkpoint saved (F9: load)"))

func _promote_checkpoint(temporary: String, target: String, backup: String, primary_valid: bool) -> bool:
    # Keep the last valid backup until a *verified* new primary exists.
    # target + ".rollback" holds the previous valid primary during promotion;
    # it also survives a process crash between the two renames.
    var rollback := target + ".rollback"
    var staged := false
    if FileAccess.file_exists(target):
        if primary_valid:
            # A valid primary makes an abandoned rollback safe to retire.
            if FileAccess.file_exists(rollback) and DirAccess.remove_absolute(rollback) != OK:
                return false
            if DirAccess.rename_absolute(target, rollback) != OK:
                return false
            staged = true
        elif DirAccess.remove_absolute(target) != OK:
            return false
    if DirAccess.rename_absolute(temporary, target) != OK:
        # Never consume the older backup while recovering from a failed write.
        if staged and not FileAccess.file_exists(target):
            DirAccess.rename_absolute(rollback, target)
        return false
    if _read_checkpoint(target).is_empty():
        # A rename succeeding does not prove that the destination is readable.
        DirAccess.remove_absolute(target)
        if staged:
            DirAccess.rename_absolute(rollback, target)
        return false
    if staged:
        # Only now is it safe to replace the previous backup. If either step
        # fails, the valid new primary and the staged rollback both survive.
        if FileAccess.file_exists(backup) and DirAccess.remove_absolute(backup) != OK:
            return true
        DirAccess.rename_absolute(rollback, backup)
    return true

func _read_recovery_checkpoint(primary: String, rollback: String, backup: String) -> Dictionary:
    # Prefer the interrupted transaction's previous primary over an older backup.
    for path in [primary, rollback, backup]:
        var state := _read_checkpoint(path)
        if not state.is_empty():
            return state
    return {}

func _read_checkpoint(path: String) -> Dictionary:
    if not FileAccess.file_exists(path):
        return {}
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return {}
    if file.get_length() > MAX_SAVE_BYTES:
        file.close()
        return {}
    var contents := file.get_as_text()
    file.close()
    return DreamSaveCodec.decode_checkpoint(contents)

func _load_game() -> void:
    # A direct/stale F9 callback must not change the world or dismiss a modal
    # while the application is unfocused. Keyboard input already has this gate.
    if not app_has_focus:
        return
    if transitioning:
        overlay.toast(loc("Dalış sırasında yüklenemez", "Cannot load during a dive"))
        return
    var state := _read_recovery_checkpoint(SAVE_FILE, SAVE_FILE + ".rollback", BACKUP_FILE)
    if state.is_empty():
        overlay.toast(loc("Geçerli kayıt bulunamadı", "No valid checkpoint found"))
        return
    transition_token += 1
    transitioning = false
    dive_remaining_seconds = 0.0
    overlay.dismiss()
    active_dialog = ""
    language = str(state["language"])
    player_slot = int(state["slot"])
    elapsed_seconds = float(state["elapsed"])
    remaining_seconds = float(state["remaining"])
    stability = int(state["stability"])
    collapse_count = int(state["collapse_count"])
    run_started = bool(state["run_started"])
    game_complete = bool(state["game_complete"])
    fuse_values = state["fuses"].duplicate()
    seal_values = state["seal"].duplicate()
    power_on = bool(state["power_on"])
    locker_open = bool(state["locker_open"])
    archive_found = bool(state["archive_found"])
    seal_open = bool(state["seal_open"])
    quality = int(state["quality"])
    _move_to(str(state["layer"]))
    _update_phase(true)
    _apply_quality()
    # Direct/programmatic loads must not re-enable controls in a background window.
    player.can_move = app_has_focus and not game_complete
    overlay.toast(loc("Kontrol noktası yüklendi", "Checkpoint loaded"))

func _apply_quality() -> void:
    # Forward+ realism profiles. Each toggle is reversible at runtime with F3.
    # LOW also drops costly world triplanar texture sampling on large shells.
    DreamRooms.set_shell_mapping(rooms, quality == 0)
    DreamRooms.set_rounded_detail_lod(rooms, quality)
    # Screen-space effects complement materials; they are not global illumination.
    var shadow_on := quality == 2
    for lamp in get_tree().get_nodes_in_group("dream_lamps"):
        if lamp is Light3D:
            lamp.shadow_enabled = shadow_on
    for world in get_children():
        if world is WorldEnvironment and world.environment != null:
            var env: Environment = world.environment
            env.ssao_enabled = quality >= 1
            env.ssil_enabled = quality == 2
            env.glow_enabled = false  # Avoid synthetic bloom / CGI halos.
    get_viewport().msaa_3d = Viewport.MSAA_DISABLED if quality == 0 else (Viewport.MSAA_4X if quality == 2 else Viewport.MSAA_2X)
    overlay.toast(loc("Görsel kalite: ", "Graphics quality: ") + ["LOW", "MEDIUM", "HIGH"][quality])

func _action_name(action: String) -> String:
    var labels := {
        "bed": ["Yatak", "Bed"], "prologue_clock": ["Bozuk saat", "Broken clock"], "fuses": ["Sigorta paneli", "Fuse panel"],
        "house_note": ["Eski defter", "Old notebook"],
        "phase_echo": ["Zaman yankısı", "Memory echo"],
        "school_door": ["Okul kapısı", "School door"],
        "wake_bell": ["Uyanış çanı", "Waking bell"],
        "locker": ["Kilitli dolap", "Locked locker"],
        "archive": ["Arşiv defteri", "Archive journal"],
        "seal": ["Mühür", "Seal"], "return_house": ["Ev'e dönüş", "Back to house"]
    }
    if not labels.has(action):
        return ""
    return labels[action][0 if language == "tr" else 1]

func _can_interact(action: String) -> bool:
    # Apply the focus gate to direct calls too, not only keyboard events.
    if not app_has_focus or game_complete or transitioning or overlay.is_dialog_open:
        return false
    if not ACTION_LAYERS.has(action) or ACTION_LAYERS[action] != current_layer:
        return false
    if action == "prologue_clock":
        return prologue_step == 1 and not run_started
    return action == "bed" or run_started

func _interact(action: String) -> void:
    if not _can_interact(action):
        return
    match action:
        "bed":
            _start_dive()
        "prologue_clock":
            _inspect_prologue_clock()
        "house_note":
            _dialog(loc("SOLMUŞ NOT", "FADED NOTE"), loc(
                "Sigorta anahtarları: 3 - 1 - 4\nOkul dolabı: 4812\n\nAltı zamanın hepsi aynı değil.",
                "Fuse switches: 3 - 1 - 4\nSchool locker: 4812\n\nNot all six times are the same."),
                [{"id":"close", "label":loc("Kapat", "Close")}], "note")
        "phase_echo":
            _inspect_phase_echo()
        "fuses":
            _open_fuses()
        "school_door":
            if power_on:
                _move_to("school")
                overlay.toast(loc("Okula girdin", "You entered the school"))
            else:
                overlay.toast(loc("Elektrik olmadan kapı açılmıyor", "The door needs power"))
        "locker":
            _open_locker()
        "archive":
            if not locker_open:
                overlay.toast(loc("Önce dolabı aç", "Open the locker first"))
            else:
                archive_found = true
                overlay.toast(loc("Arşiv kaydı alındı", "Archive entry collected"))
        "seal":
            _open_seal()
        "return_house":
            _move_to("house")
        "wake_bell":
            if seal_open:
                _wake()
            else:
                overlay.toast(loc("Önce mührü çözmen gerek", "You must solve the seal first"))

func _dialog(title: String, text: String, choices: Array[Dictionary], context := "") -> void:
    active_dialog = context
    overlay.dialog(title, text, choices, _choice)

func _choice(id: String) -> void:
    # Guard delayed UI callbacks as well as normal player interaction.
    # Background-window callbacks must not advance the prologue or puzzles.
    if not app_has_focus or not overlay.is_dialog_open:
        return
    # A direct/stale "close" callback must not dismiss a mandatory prologue or
    # ending confirmation. Only dialogs that offered Close may be cancelled.
    if id == "close" and not overlay.dialog_can_cancel:
        return
    # A callback must belong to the currently displayed puzzle, not just the room.
    var required_context := ""
    if id == "intro_start":
        required_context = "intro"
    elif id == "ending":
        required_context = "ending"
    elif id == "fuse_submit" or id.begins_with("fuse_"):
        required_context = "fuses"
    elif id == "seal_submit" or id.begins_with("seal_"):
        required_context = "seal"
    elif id.begins_with("locker_submit:"):
        required_context = "locker"
    elif id != "close":
        return
    if required_context != "" and active_dialog != required_context:
        return
    if id == "fuse_submit" or id.begins_with("fuse_"):
        if current_layer != "house" or not run_started or power_on or game_complete:
            return
    if id == "seal_submit" or id.begins_with("seal_"):
        if current_layer != "school" or not run_started or not archive_found or seal_open or game_complete:
            return
    if id.begins_with("locker_submit:"):
        if current_layer != "school" or not run_started or not power_on or locker_open or game_complete:
            return
    match id:
        "intro_start":
            overlay.dismiss()
            prologue_step = 1
            overlay.toast(loc("Masadaki saati bul ve E ile incele", "Find the desk clock and inspect it with E"), 5.0)
        "close":
            var was_prologue_clock := active_dialog == "prologue_clock"
            overlay.dismiss()
            if was_prologue_clock:
                _begin_prologue_shift()
        "fuse_submit":
            if fuse_values == [3, 1, 4]:
                if not power_on:
                    power_on = true
                    stability = mini(100, stability + 7)
                overlay.dismiss()
                overlay.toast(loc("Elektrik geri geldi. Okul kapısı açık.", "Power restored. School door unlocked."), 5.0)
            else:
                _wrong_answer()
                _open_fuses()
        "seal_submit":
            if seal_values == [0, 1, 2, 3]:
                seal_open = true
                stability = mini(100, stability + 7)
                overlay.dismiss()
                overlay.toast(loc("Mühür açıldı. Eve dön ve çanı bul.", "Seal broken. Return home and find the bell."), 6.0)
            else:
                _wrong_answer()
                _open_seal()
        "ending":
            overlay.dismiss()
            game_complete = true
            player.can_move = false
        _:
            if id.begins_with("fuse_"):
                var index_text := id.trim_prefix("fuse_")
                if not index_text.is_valid_int():
                    return
                var idx := int(index_text)
                if idx < 0 or idx >= fuse_values.size():
                    return
                fuse_values[idx] = 1 + (fuse_values[idx] % 6)
                _open_fuses()
            elif id.begins_with("seal_"):
                var index_text := id.trim_prefix("seal_")
                if not index_text.is_valid_int():
                    return
                var idx := int(index_text)
                if idx < 0 or idx >= seal_values.size():
                    return
                seal_values[idx] = (seal_values[idx] + 1) % 6
                _open_seal()
            elif id.begins_with("locker_submit:"):
                var entered_code := id.trim_prefix("locker_submit:")
                if entered_code.length() != 4 or not entered_code.is_valid_int() or entered_code.begins_with("-") or entered_code.begins_with("+"):
                    overlay.toast(loc("Dört rakam gir.", "Enter exactly four digits."))
                    return
                if entered_code == "4812":
                    if not locker_open:
                        locker_open = true
                        stability = mini(100, stability + 7)
                    overlay.dismiss()
                    overlay.toast(loc("Dolap açıldı. Arşivi incele.", "Locker opened. Read the archive."), 4.0)
                else:
                    _wrong_answer()
                    _open_locker()
            else:
                overlay.dismiss()

func _can_open_puzzle(action: String, context: String) -> bool:
    # Direct or delayed dialog builders must obey the same room/focus gates
    # as interaction. Only the currently open puzzle may redraw its own modal
    # after a button press; it cannot replace a note or another puzzle.
    if not app_has_focus or not run_started or game_complete or transitioning:
        return false
    if ACTION_LAYERS.get(action, "") != current_layer:
        return false
    return not overlay.is_dialog_open or active_dialog == context

func _open_fuses() -> void:
    if not _can_open_puzzle("fuses", "fuses"):
        return
    if power_on:
        overlay.toast(loc("Sigortalar zaten etkin", "Fuses already active"))
        overlay.dismiss()
        return
    var choices: Array[Dictionary] = []
    for idx in range(3):
        choices.append({"id":"fuse_%d" % idx, "label": "%d. %s → %d" % [idx + 1, loc("anahtar", "switch"), fuse_values[idx]]})
    choices.append({"id":"fuse_submit", "label":loc("Sigortayı test et", "Test the fuses")})
    choices.append({"id":"close", "label":loc("Kapat", "Close")})
    _dialog(loc("SİGORTA KUTUSU", "FUSE BOX"), loc(
        "Defterdeki üçlü diziyi ayarla. Her anahtar 1–6 arasında döner. Yanlış test dengeyi 9 azaltır.",
        "Enter the three-number sequence from the notebook. Each switch cycles 1–6. A wrong test costs 9 stability."), choices, "fuses")

func _open_locker() -> void:
    if not _can_open_puzzle("locker", "locker"):
        return
    if locker_open:
        overlay.toast(loc("Dolap zaten açık", "The locker is already open"))
        return
    active_dialog = "locker"
    overlay.dialog_code(loc("OKUL DOLABI", "SCHOOL LOCKER"), loc(
        "Dört haneli kilit. Evde bulduğun nottaki kodu yaz.",
        "A four-digit lock. Type the code from the notebook in the house."),
        loc("4 rakam", "4 digits"), loc("Kodu dene", "Try code"),
        loc("Kapat", "Close"), _choice)

func _open_seal() -> void:
    if not _can_open_puzzle("seal", "seal"):
        return
    if seal_open:
        overlay.toast(loc("Mühür zaten açık", "Seal already opened"))
        return
    if not archive_found:
        overlay.toast(loc("Arşivi bulmadan mühür çözülemez", "Find the archive before attempting the seal"))
        return
    var symbols := ["SUN", "MOON", "WAVE", "EYE", "LEAF", "STAR"]
    var choices: Array[Dictionary] = []
    for idx in range(4):
        choices.append({"id":"seal_%d" % idx, "label":"%d: %s" % [idx + 1, symbols[seal_values[idx]]]})
    choices.append({"id":"seal_submit", "label":loc("Mührü doğrula", "Validate seal")})
    choices.append({"id":"close", "label":loc("Kapat", "Close")})
    _dialog(loc("DÖRT İŞARET", "FOUR SIGNS"), loc(
        "Arşiv sayfasındaki sıralama: SUN • MOON • WAVE • EYE\nHer bir işarete basarak sembolünü değiştir.",
        "The archive's sequence: SUN • MOON • WAVE • EYE\nPress each sign to cycle the symbol."), choices, "seal")

func _wrong_answer() -> void:
    # A delayed/direct penalty must not damage the player after its puzzle
    # closes, in another room, or while the application is unfocused.
    if not app_has_focus or not run_started or game_complete or transitioning or not overlay.is_dialog_open:
        return
    var active_puzzle := active_dialog == "fuses" and current_layer == "house" and not power_on
    active_puzzle = active_puzzle or (active_dialog == "locker" and current_layer == "school" and power_on and not locker_open)
    active_puzzle = active_puzzle or (active_dialog == "seal" and current_layer == "school" and archive_found and not seal_open)
    if not active_puzzle:
        return
    stability = maxi(0, stability - 9)
    overlay.toast(loc("Yanlış cevap. Denge -9", "Wrong answer. Stability -9"))

# Small, observational hook inspired by co-op mystery games: each 90-second
# phase has a distinct, optional memory. No rewards or save-schema fields are
# added, so checkpoint compatibility and the main puzzle path remain intact.
func _inspect_phase_echo() -> void:
    if not _can_interact("phase_echo"):
        return
    if current_phase < 0 or current_phase >= temporal_props.size():
        return
    var lines_tr := [
        "Yatağın kenarında altı iz var. Biri bu evi daha önce yaşamış.",
        "Duvardaki sessizlik değişti. Sigortaların sırası tesadüf değil.",
        "Aynı koridor, başka bir an. Okul kapısı bir şey bekliyor.",
        "Dolapların metalinde bir çocuk sesi yankılanıyor: dört rakam.",
        "Arşiv bir cevap değil; hatırlamayı sağlayan bir anahtar.",
        "Çan, ancak mühür kırıldıktan sonra gerçeğe çağırabilir."
    ]
    var lines_en := [
        "Six marks line the bedside. Someone lived this house before.",
        "The silence in the wall has changed. The fuse order is no accident.",
        "Same hallway, another moment. The school door is waiting.",
        "A child's voice rings through the lockers: four digits.",
        "The archive is not an answer, but a key to remembering.",
        "Only a broken seal lets the bell call you back to reality."
    ]
    var phase_number := current_phase + 1
    _dialog(loc("ZAMAN YANKISI", "MEMORY ECHO") + "  %d/6" % phase_number,
        lines_tr[current_phase] if language == "tr" else lines_en[current_phase],
        [{"id": "close", "label": loc("Kapat", "Close")}], "echo")

func _update_phase(force := false) -> void:
    var phase := (int(floorf(elapsed_seconds / EPOCH_SECONDS)) + player_slot) % 6
    if phase == current_phase and not force:
        return
    current_phase = phase
    for idx in range(temporal_props.size()):
        var echo := temporal_props[idx]
        echo.visible = idx == phase
        # Invisible CollisionObject3D bodies still block raycasts in Godot.
        # Only the active echo can collide / be aimed at; inactive phases
        # never obstruct the notebook or other interaction targets.
        var echo_body := echo as CollisionObject3D
        if echo_body != null:
            echo_body.collision_layer = 1 if idx == phase else 0

func _start_dive() -> void:
    # Keep direct/stale callers behind the same bed interaction gate as E:
    # reality only, focused, no modal, no active dive, no completed game.
    if not _can_interact("bed"):
        return
    transitioning = true
    transition_token += 1
    dive_remaining_seconds = DIVE_SECONDS
    overlay.toast(loc("Gözlerini kapatıyorsun... (12 saniye)", "Closing your eyes... (12 seconds)"), DIVE_SECONDS)
    # _process advances only while focused. No pending SceneTreeTimer can
    # complete the dive behind an unfocused window or after cancellation.

func _finish_dive(token: int) -> void:
    # A direct/delayed completion callback cannot skip the focused 12-second
    # countdown, even if it still carries the current transition token.
    if token != transition_token or not transitioning or not is_inside_tree() or not app_has_focus:
        return
    if dive_remaining_seconds > 0.0:
        return
    transitioning = false
    dive_remaining_seconds = 0.0
    run_started = true
    _move_to("house")
    overlay.toast(loc("Ev rüyasına hoş geldin. Defteri ara.", "Welcome to the House dream. Find the notebook."), 6.0)

func _fold() -> void:
    # A direct/stale fold callback must obey the same active-play conditions
    # as the timer in _process. Only an exhausted clock or zero stability
    # may collapse the dream; never during a modal or background focus loss.
    if not run_started or not app_has_focus or transitioning or game_complete or overlay.is_dialog_open:
        return
    if remaining_seconds > 0.0 and stability > 0:
        return
    collapse_count += 1
    stability = 35
    remaining_seconds = FOLD_SECONDS
    _move_to("house")
    overlay.toast(loc("Rüya çöktü. Günlük korunuyor; 3 dakika kaldı.", "Dream collapsed. Journal preserved; 3 minutes remain."), 6.0)

func _wake() -> void:
    # A direct/stale callback cannot skip the school seal or complete the game
    # from another room, while a modal is open, or without window focus.
    if not _can_interact("wake_bell") or not seal_open:
        return
    _move_to("reality")
    game_complete = true
    _dialog(loc("İLK UYANIŞ — DEMO TAMAMLANDI", "FIRST AWAKENING — DEMO COMPLETE"), loc(
        "Eve, okula ve yeniden gerçekliğe döndün. Ancak altı farklı zamanın sırrı henüz çözülmedi.\n\nBu ilk oynanabilir taslaktır; tam Dream Layers hikâyesi ve çok oyunculu sistem henüz geliştirilmedi.",
        "You traveled from home to school and back to reality. But the secret of six separate timelines remains.\n\nThis is an initial gameplay prototype. The full story and multiplayer are not implemented."),
        [{"id":"ending", "label":loc("Devam et", "Continue")}], "ending")
