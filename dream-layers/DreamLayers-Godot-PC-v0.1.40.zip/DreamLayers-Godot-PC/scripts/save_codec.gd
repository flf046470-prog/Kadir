extends RefCounted
class_name DreamSaveCodec

# Local single-player checkpoint format. Do not deserialize nodes or executable data.
const SCHEMA_VERSION := 1
const MAX_ELAPSED := 100000000.0
const ENVELOPE_FORMAT := "DL_CHECKPOINT_SHA256_V1"

static func capture(game: Node) -> Dictionary:
    return {
        "schema": SCHEMA_VERSION,
        "layer": game.current_layer,
        "language": game.language,
        "slot": game.player_slot,
        "elapsed": game.elapsed_seconds,
        "remaining": game.remaining_seconds,
        "stability": game.stability,
        "collapse_count": game.collapse_count,
        "run_started": game.run_started,
        "game_complete": game.game_complete,
        "fuses": game.fuse_values.duplicate(),
        "seal": game.seal_values.duplicate(),
        "power_on": game.power_on,
        "locker_open": game.locker_open,
        "archive_found": game.archive_found,
        "seal_open": game.seal_open,
        "quality": game.quality
    }

static func _integer(value: Variant, minimum: int, maximum: int) -> bool:
    if typeof(value) != TYPE_INT and typeof(value) != TYPE_FLOAT:
        return false
    var number := float(value)
    return number >= float(minimum) and number <= float(maximum) and floorf(number) == number

static func _number(value: Variant, minimum: float, maximum: float) -> bool:
    if typeof(value) != TYPE_INT and typeof(value) != TYPE_FLOAT:
        return false
    var number := float(value)
    return number >= minimum and number <= maximum

static func validated(raw: Variant) -> Dictionary:
    if typeof(raw) != TYPE_DICTIONARY:
        return {}
    var required := ["schema", "layer", "language", "slot", "elapsed", "remaining",
        "stability", "collapse_count", "run_started", "game_complete", "fuses", "seal",
        "power_on", "locker_open", "archive_found", "seal_open", "quality"]
    for key in required:
        if not raw.has(key):
            return {}
    if not _integer(raw["schema"], SCHEMA_VERSION, SCHEMA_VERSION):
        return {}
    if typeof(raw["layer"]) != TYPE_STRING or not (raw["layer"] in ["reality", "house", "school"]):
        return {}
    if typeof(raw["language"]) != TYPE_STRING or not (raw["language"] in ["tr", "en"]):
        return {}
    if not _integer(raw["slot"], 0, 5) or not _integer(raw["quality"], 0, 2):
        return {}
    if not _number(raw["elapsed"], 0.0, MAX_ELAPSED) or not _number(raw["remaining"], 0.0, 900.0):
        return {}
    if not _integer(raw["stability"], 0, 100) or not _integer(raw["collapse_count"], 0, 1000000):
        return {}
    for key in ["run_started", "game_complete", "power_on", "locker_open", "archive_found", "seal_open"]:
        if typeof(raw[key]) != TYPE_BOOL:
            return {}
    if typeof(raw["fuses"]) != TYPE_ARRAY or raw["fuses"].size() != 3:
        return {}
    for value in raw["fuses"]:
        if not _integer(value, 1, 6):
            return {}
    if typeof(raw["seal"]) != TYPE_ARRAY or raw["seal"].size() != 4:
        return {}
    for value in raw["seal"]:
        if not _integer(value, 0, 5):
            return {}
    # JSON numeric values can be floating-point even when mathematically
    # integral, and Godot 4 Array equality is type-strict ([3.0] != [3]).
    # Normalize the validated arrays to int BEFORE the progress comparisons
    # below; puzzle controls also use the integer-only % operator after F9.
    var fuses: Array[int] = []
    for value in raw["fuses"]:
        fuses.append(int(value))
    var seal: Array[int] = []
    for value in raw["seal"]:
        seal.append(int(value))
    # Reject impossible progress combinations; never repair untrusted data silently.
    if not raw["run_started"]:
        if raw["layer"] != "reality" or raw["game_complete"] or raw["power_on"] or raw["locker_open"] or raw["archive_found"] or raw["seal_open"]:
            return {}
        if float(raw["elapsed"]) != 0.0 or float(raw["remaining"]) != 900.0 or float(raw["stability"]) != 100.0 or float(raw["collapse_count"]) != 0.0:
            return {}
        # Before the first bed dive, neither puzzle has been interactable.
        # Do not accept a pre-run checkpoint with fabricated partial progress.
        if fuses != [1, 1, 1] or seal != [0, 0, 0, 0]:
            return {}
    elif raw["layer"] == "reality" and not raw["game_complete"]:
        return {}
    if raw["layer"] == "school" and not raw["power_on"]:
        return {}
    if raw["power_on"] and fuses != [3, 1, 4]:
        return {}
    if raw["locker_open"] and not raw["power_on"]:
        return {}
    if raw["archive_found"] and not raw["locker_open"]:
        return {}
    # Seal controls cannot be reached before collecting the archive entry.
    # The zeroed seal is the only legitimate state until that interaction.
    if not raw["archive_found"] and seal != [0, 0, 0, 0]:
        return {}
    if raw["seal_open"] and (not raw["archive_found"] or seal != [0, 1, 2, 3]):
        return {}
    if raw["game_complete"] and (not raw["run_started"] or not raw["seal_open"] or raw["layer"] != "reality"):
        return {}
    var state: Dictionary = raw.duplicate(true)
    state["fuses"] = fuses
    state["seal"] = seal
    return state

# A checksum detects accidental corruption of otherwise plausible JSON values.
# This is NOT authentication: anyone editing the file can recompute SHA-256.
# The inner JSON is stored as a string so its bytes do not change when the
# outer envelope is parsed (Godot can normalize JSON number representations).
static func encode_checkpoint(raw: Dictionary) -> String:
    var state := validated(raw)
    if state.is_empty():
        return ""
    var data := JSON.stringify(state)
    return JSON.stringify({"format": ENVELOPE_FORMAT, "data": data, "sha256": data.sha256_text()})

# Corrupt checkpoints are an expected recovery path (rollback/backup), so
# parse silently: JSON.parse_string() logs an engine ERROR on bad input.
static func _parse_json(text: String) -> Variant:
    var parser := JSON.new()
    if parser.parse(text) != OK:
        return null
    return parser.data

static func decode_checkpoint(text: String) -> Dictionary:
    var raw: Variant = _parse_json(text)
    if typeof(raw) != TYPE_DICTIONARY:
        return {}
    # Strictly reject damaged envelopes. Do not fall back to the inner data
    # when a checksum or any other envelope field is missing or invalid.
    if raw.has("format") or raw.has("data") or raw.has("sha256"):
        if raw.size() != 3 or raw.get("format") != ENVELOPE_FORMAT:
            return {}
        if typeof(raw.get("data")) != TYPE_STRING or typeof(raw.get("sha256")) != TYPE_STRING:
            return {}
        var data: String = raw["data"]
        if raw["sha256"] != data.sha256_text():
            return {}
        return validated(_parse_json(data))
    # Existing v0.1.4-v0.1.6 checkpoints remain loadable (legacy v1 JSON).
    return validated(raw)
