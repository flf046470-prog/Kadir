extends CanvasLayer
class_name DreamOverlay

var hud: Control
var stats_label: Label
var aim_label: Label
var hint_label: Label
var notify_label: Label
var modal_shade: ColorRect
var modal_panel: PanelContainer
var modal_title: Label
var modal_body: Label
var modal_buttons: VBoxContainer
var modal_code: LineEdit
var modal_callback: Callable
var is_dialog_open := false
var dialog_generation := 0
var dialog_can_cancel := false
var _message_seconds := 0.0

func _ready() -> void:
    hud = Control.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(hud)

    stats_label = Label.new()
    stats_label.position = Vector2(22, 18)
    stats_label.add_theme_font_size_override("font_size", 18)
    stats_label.add_theme_color_override("font_color", Color(0.84, 0.91, 0.94))
    hud.add_child(stats_label)

    aim_label = Label.new()
    aim_label.set_anchors_preset(Control.PRESET_CENTER)
    aim_label.offset_left = -8
    aim_label.offset_top = -14
    aim_label.text = "+"
    aim_label.add_theme_font_size_override("font_size", 23)
    aim_label.add_theme_color_override("font_color", Color(0.96, 0.83, 0.63))
    hud.add_child(aim_label)

    hint_label = Label.new()
    hint_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    hint_label.offset_left = -330
    hint_label.offset_right = 330
    hint_label.offset_top = -84
    hint_label.offset_bottom = -50
    hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint_label.add_theme_font_size_override("font_size", 22)
    hud.add_child(hint_label)

    notify_label = Label.new()
    notify_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    notify_label.offset_left = -440
    notify_label.offset_right = 440
    notify_label.offset_top = -135
    notify_label.offset_bottom = -95
    notify_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    notify_label.add_theme_font_size_override("font_size", 21)
    notify_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.50))
    hud.add_child(notify_label)

    modal_shade = ColorRect.new()
    modal_shade.color = Color(0.012, 0.025, 0.038, 0.88)
    modal_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    modal_shade.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(modal_shade)

    modal_panel = PanelContainer.new()
    modal_panel.set_anchors_preset(Control.PRESET_CENTER)
    modal_panel.offset_left = -330
    modal_panel.offset_right = 330
    modal_panel.offset_top = -245
    modal_panel.offset_bottom = 245
    modal_shade.add_child(modal_panel)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.055, 0.077, 0.097, 0.98)
    style.border_color = Color(0.37, 0.49, 0.54)
    style.set_border_width_all(1)
    style.set_corner_radius_all(9)
    style.set_content_margin_all(24)
    modal_panel.add_theme_stylebox_override("panel", style)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 16)
    modal_panel.add_child(layout)
    modal_title = Label.new()
    modal_title.add_theme_font_size_override("font_size", 29)
    modal_title.add_theme_color_override("font_color", Color(0.98, 0.82, 0.58))
    layout.add_child(modal_title)
    modal_body = Label.new()
    modal_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    modal_body.custom_minimum_size = Vector2(570, 105)
    modal_body.add_theme_font_size_override("font_size", 18)
    layout.add_child(modal_body)
    modal_code = LineEdit.new()
    modal_code.max_length = 4
    modal_code.custom_minimum_size = Vector2(0, 42)
    modal_code.hide()
    layout.add_child(modal_code)
    # Enter submits the locker code without requiring a mouse click.
    modal_code.text_submitted.connect(_submit_locker_from_keyboard)
    var line := HSeparator.new()
    layout.add_child(line)
    modal_buttons = VBoxContainer.new()
    modal_buttons.add_theme_constant_override("separation", 7)
    layout.add_child(modal_buttons)
    modal_shade.hide()

func _process(delta: float) -> void:
    if _message_seconds > 0.0:
        _message_seconds -= delta
        if _message_seconds <= 0.0:
            notify_label.text = ""

func set_hud(status: String, hint: String) -> void:
    # Called every render frame. Avoid reassigning unchanged Control properties:
    # text changes can invalidate the label layout even when nothing changed.
    if stats_label.text != status:
        stats_label.text = status
    var shown_hint := hint if not is_dialog_open else ""
    if hint_label.text != shown_hint:
        hint_label.text = shown_hint
    var show_aim := not is_dialog_open
    if aim_label.visible != show_aim:
        aim_label.visible = show_aim

func toast(message: String, seconds := 3.0) -> void:
    notify_label.text = message
    _message_seconds = seconds

func dialog(title: String, body: String, choices: Array[Dictionary], callback: Callable) -> void:
    dialog_generation += 1
    modal_code.hide()
    modal_title.text = title
    modal_body.text = body
    modal_callback = callback
    # Only puzzle/note windows with an explicit Close choice are cancellable.
    # Prologue and ending require their intentional confirmation action.
    dialog_can_cancel = false
    for choice in choices:
        if str(choice.get("id", "")) == "close":
            dialog_can_cancel = true
            break
    for child in modal_buttons.get_children():
        child.queue_free()
        modal_buttons.remove_child(child)
    var first_button: Button = null
    for choice in choices:
        var button := Button.new()
        button.text = str(choice.get("label", "Continue"))
        button.custom_minimum_size = Vector2(0, 38)
        button.pressed.connect(_choose.bind(str(choice.get("id", "")), dialog_generation))
        modal_buttons.add_child(button)
        if first_button == null:
            first_button = button
    is_dialog_open = true
    modal_shade.show()
    # Show before grabbing focus; the first choice is usable with Enter/Space.
    if first_button != null:
        first_button.grab_focus()
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func dialog_code(title: String, body: String, placeholder: String, submit_label: String, close_label: String, callback: Callable) -> void:
    dialog(title, body, [
        {"id": "locker_submit", "label": submit_label},
        {"id": "close", "label": close_label}
    ], callback)
    modal_code.text = ""
    modal_code.placeholder_text = placeholder
    modal_code.show()
    # Override the generic first-button focus for numeric code entry.
    modal_code.grab_focus()

func _input(event: InputEvent) -> void:
    # Handle Escape before focused Controls consume the key. Preserve the
    # generation-guarded callback path instead of dismissing the UI directly.
    if not is_dialog_open or not dialog_can_cancel:
        return
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        _choose("close", dialog_generation)
        get_viewport().set_input_as_handled()

func _submit_locker_from_keyboard(_submitted_text: String) -> void:
    if is_dialog_open and modal_code.visible:
        # Reuse the generation-guarded button path; never bypass validation.
        _choose("locker_submit", dialog_generation)

func _choose(id: String, generation: int) -> void:
    if generation != dialog_generation or not is_dialog_open:
        return
    if not modal_callback.is_valid():
        return
    if id == "locker_submit" and modal_code.visible:
        modal_callback.call("locker_submit:" + modal_code.text)
    else:
        modal_callback.call(id)

func dismiss() -> void:
    dialog_generation += 1
    is_dialog_open = false
    dialog_can_cancel = false
    modal_shade.hide()
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
