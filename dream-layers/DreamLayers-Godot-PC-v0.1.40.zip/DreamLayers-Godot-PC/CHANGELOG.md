## v0.1.40 — 16 Ekim 2026 | Gerçek giriş ve raycast motor testi

- Yeni `tests/godot_input_smoke.gd`: olaylar `Input.parse_input_event` → Viewport → `_unhandled_input` yolundan geçer, etkileşim gerçek fizik `RayCast3D` ile, yürüme `_physics_process` ile ölçülür. 13 kontrol: intro açıkken E yok sayılır; saate 1,4 m'den bakıp E → 2. görev; 3,2 m'de saat menzil dışı; W ile ~0,5 s yürüme (ölçülen 2,20 m), zeminde kalma; yatağa bakıp E → dalış, R → iptal; F2 dil, F3 kalite.
- Testin gerçekten başarısız olabildiği kasıtlı bozma ile doğrulandı (2 bozulmuş kontrol → 2 FAIL).
- `tests/run_godot_smoke.py` üçüncü adım olarak bu testi çalıştırır ve kendi özet satırını (`DREAM LAYERS INPUT SMOKE`) ister. Runner birim testleri güncellendi, 1 yeni test.
- Oyun kodu değişmedi; testte hata bulunmadı. Python 191/191 PASS; motor: 232/0 + 13/0.
- Hâlâ YAPILMADI: GPU görüntüsü, gerçek fare (yakalanmış imleç) bakışı, Windows EXE, FPS.

## v0.1.39 — 16 Ekim 2026 | İlk gerçek Godot motor testi ve bulunan hataların düzeltmesi

- İlk kez gerçek **Godot 4.3-stable (Linux, headless)** ile `python3 tests/run_godot_smoke.py --require-engine` çalıştırıldı. v0.1.38 **hiç parse edilmiyordu**; bulunan tüm hatalar düzeltildi, sonuç: **PASS — 232 motor kontrolü, 0 hata, sıfır engine ERROR satırı**.
- `scripts/main.gd`: `func tr(String, String)` Godot'un `Object.tr(StringName, StringName)` metodunu farklı imzayla eziyordu → parse hatası, oyun açılmıyordu. Yerelleştirme yardımcısı `loc()` olarak yeniden adlandırıldı (60 çağrı). Metinler/davranış aynı.
- `scripts/save_codec.gd` (**gerçek kayıt hatası**): JSON'dan okunan diziler float olur ve Godot 4'te `[3.0, 1.0, 4.0] != [3, 1, 4]`. Bu yüzden ilerleme içeren **her F9 yüklemesi reddediliyordu**. Diziler artık ilerleme kontrollerinden *önce* int'e normalize ediliyor; kurallar aynı. Ayrıca tip çıkarımı parse hatası (`var state: Dictionary`) düzeltildi.
- `scripts/save_codec.gd`: Bozuk kayıt dosyaları beklenen bir kurtarma yolu; `JSON.parse_string()` her seferinde engine ERROR yazıyordu. Sessiz `JSON.new().parse()` kullanılıyor; reddetme davranışı aynı.
- `scripts/room_builder.gd`: `cuboid()` alt düğümlerine sabit adlar (`CollisionShape3D`, `Visual`) verildi; Godot otomatik `@CollisionShape3D@123` adları veriyordu ve smoke testi yatak collider'ını bulamıyordu.
- `tests/godot_flow_smoke.gd`: 6 tip çıkarımı parse hatası, typed array çağrısı ve Godot 4.3 headless dummy renderer'ın kapanışta yazdığı `mesh_get_surface_count: Parameter "m" is null` hatasını önleyen temiz kapanış (mesh'ler serbest bırakılmadan önce ayrılır). Runner'ın katı "engine error yok" kapısı gevşetilmedi.
- Statik testler hatalı metni sabitlediği için güncellendi; `tests/test_engine_parse_fixes_contract.py` 5 yeni regresyon testi + 1 yeni int-dizi testi. Python **190/190 PASS**.
- `tools/package_source.py`: `--godot-runtime-tested` bayrağı; manifest `godot_runtime_tested: true` yalnızca motor PASS sonrası.
- Hâlâ YAPILMADI: GPU render/görüntü, gerçek klavye/fare/raycast girişi, Windows EXE, FPS/VRAM, multiplayer. Headless dummy renderer görüntü üretmez.

## v0.1.38 — 14 Ekim 2026 | Özgün sinematik prolog ve davranışsal oyun araştırması

- `scripts/room_builder.gd`: Gerçeklik masasındaki fiziksel `PrologueClock`, dekoratif PBR yüzey/ibre. Diğer oda etkileşimleri ve çarpışmaları korunur.
- `scripts/main.gd`: GTA V'in eylemle öğretme prensibinden esinlenen kısa TR/EN prolog; 2 aşamalı oynanabilir görev HUD; saat etkileşimi odak/oda/modal/prolog korumalı. Inception'ın gündelik dünyadaki imkânsızlık hissinden esinlenen 2,2 saniyelik küçük görsel kayma; kamera/oyuncu fiziği etkilenmez ve Alt+Tab sırasında durur. Saat isteğe bağlı, mevcut yatak dalışı korunur.
- `tests/test_cinematic_prologue_contract.py`: 6 yeni statik kaynak testi; `tests/godot_flow_smoke.gd`: saat/animasyon/odak/etkileşim motor senaryoları eklendi (Godot olmadan çalıştırılmadı).
- `docs/PROLOGUE-CINEMATIC-DESIGN-TR.md`: GTA V / Inception mekanik/sinematografi çözümlemesi ve telif sınırları.
- `docs/STEAM-VIRAL-REVERSE-ENGINEERING-TR.md`, `tools/viral_loop_lab.py`, `tests/test_viral_loop_lab.py`: 7 viral oyun davranışsal araştırması ve 7 deterministik Python model testi. Oyun içine entegre edilmiş bir direktör sistemi değildir.
- Python 184/184 statik/model testleri; gerçek Godot GDScript import, görüntü, fiziki etkileşim, Windows EXE, FPS ve multiplayer **YAPILMADI**.

## v0.1.37 — 14 Ekim 2026 | Yuvarlatılmış mesh yüzey yönü düzeltmesi

- En güncel Library v0.1.36 ZIP (`ab731c00efc54d44785ef9f1ace1ef25da38ce1145eb56acf4c71cc3b951f05d`) yeniden indirilip SHA-256 ile doğrulandı. Önceki sürümün 166/166 statik testleri ve 71/71 kaynak manifesti geçti.
- `scripts/room_builder.gd` `_beveled_box_mesh()` içindeki her iki üçgenin indeks sırası, Godot ArrayMesh'in saat yönündeki ön yüz kuralına göre ters çevrildi. Önceki U×V matematiksel yüz normaline paralel üçgen yönü, Godot'ta dışarıdan ters yüz/backface culling riski taşıyordu. Vertex normal, UV, materyal, cache ve çarpışma biçimi aynı kaldı.
- `tests/test_bevel_winding_contract.py` 5 yeni statik/geometri testi; `tests/godot_flow_smoke.gd` tüm 6 yüzün iç üçgenlerinin yönü ve BoxShape3D kimliği için motor kabul kontrolü eklendi. Gerçek Godot çalıştırıcısı yoksa motor kontrolleri çalışmış sayılmaz; render/FPS/Windows EXE kabulü bekler.

## v0.1.36 — Zaman Yankıları (viral oyun mekanik araştırması)

- R.E.P.O., Lethal Company, Content Warning, The Exit 8 ve We Were Here resmi materyalleri incelendi; özgün çıkarımlar `docs/VIRAL-MECHANICS-RESEARCH-TR.md` içinde belgelendi. Üçüncü taraf ikili/varlık tersine mühendisliği yapılmadı.
- Ev katmanında 6 faz boyunca incelenebilir, TR/EN anlatı yankıları; faz dışı fizik katmanları kapalı. Eylem doğrulaması, prolog/modal/arka plan korumaları ve mevcut kayıt şeması korunur.
- 5 yeni Python statik regresyon testi, ek Godot smoke senaryoları. Gerçek Godot motor/FPS/Windows export testi motor yokluğundan bekliyor.

## v0.1.35 — 14 Ekim 2026 | Seçili büyük mobilyalarda bevel + mevcut F3 donanım LOD korunuyor

- Library v0.1.34 SHA-256 `9e2f37ad37823118c3c23ab68a6821e6d3c1ec41093128be9078f4074e5b189e` doğrulanarak mevcut LOD geliştirmesi üzerine ilerlenmiştir; v0.1.33'e geri dönülmedi. Önceki `set_rounded_detail_lod` HIGH/MEDIUM/LOW değişiklikleri korunmuştur.
- `scripts/room_builder.gd`: Gerçeklik, Ev ve Okul'da seçili yatak, masa, kapı ve dolap görselleri için 294 köşe ve 432 üçgenden oluşan, normal vektörleri yuvarlanmış indeksli ArrayMesh'ler. Aynı boyuttakiler paylaşılan cache kullanır. Duvar/zemin ve küçük pervazlar mevcut BoxMesh kalır.
- Fizik `BoxShape3D` ve etkileşim metadata'sı değiştirilmez. `tests/test_bevel_visual_contract.py` ile 5 yeni kaynak/matematik testi, motor kabulü için `tests/godot_flow_smoke.gd` 3 oda görsel/collision/cache kontrolü eklendi.
- Kaynak Python testleri ve ZIP/manifest, gerçek Godot import/render, GPU/FPS veya Windows EXE kanıtı değildir. Motor çalıştırıcısı hâlâ mevcut değil; 8K/fotogrametri yoktur.

## v0.1.34 — 14 Ekim 2026 | F3 ile dekoratif geometri LOD

- v0.1.33 Library ZIP SHA-256 `4263d1c2050a0c2675588360ce1cadd7f2ceb1a3ed50c78883b0ed84d7a33337` eşleşti; önceki manifest 67/67 PASS.
- `DreamRooms.set_rounded_detail_lod(rooms, quality)` üç katmandaki dekoratif silindirleri F3 LOW/MEDIUM/HIGH için sırasıyla 8/12/24 segmentle günceller. Yalnızca benzersiz CylinderMesh kaynakları değiştirilir; collider/etkileşim/oyun durumu değişmez. Geri dönüşler event-driven, kare başına işlem yok.
- `tests/test_rounded_lod_contract.py`: dört yeni statik test; `tests/godot_flow_smoke.gd`: her odada HIGH→LOW→MEDIUM geometri ve yatak collider kimliği kontrolleri eklendi (gerçek motor çalıştırılamadı).
- Godot 4.3+ binary yok; gerçek import/render/Windows/GPU/FPS/F5-F9 motor I/O hâlâ **YAPILMADI**. Düşük geometri maliyeti beklenebilir ama performans ölçülmedi.

## v0.1.33 — 14 Ekim 2026 | Üç odada yuvarlatılmış görsel donanım

- `scripts/room_builder.gd`: `rounded_detail()` görsel-only 12 dilimli `CylinderMesh` + paylaşılan PBR materyal ekler. Gerçeklik lambasının tabanı/gövdesi, Ev çan düğmesi/kapı topuzu ve Okul dolap topuzları/mühür kadranı artık silindirik ayrıntı içerir.
- Dekoratif parçalar `Node3D` altındadır, **yeni fizik gövdesi/çarpışma/etkileşim metadata'sı yoktur**. Yatak, çan ve mühür orijinal etkileşim hitbox'larını korur; gerçek Godot kabulü bekleniyor.
- `tests/test_rounded_hardware_contract.py`: dört yeni statik kontrol; `tests/godot_flow_smoke.gd`: üç odada silindir/çarpışmasız dekor ve ana aksiyon koruma kontrolleri (motor olmadan çalıştırılamadı).
- v0.1.32 Library ZIP SHA-256 `26c849ed2e90d1eceb7bb272e532bce1402e806602aa734b6960b80fb3aed31c` eşleşti, eski manifest 66/66 PASS. Gerçek Godot 4.3+ import, Windows EXE, render ve FPS/VRAM **YAPILMADI**. 8K/fotogrametri hâlâ yok.

## v0.1.32 — 14 Ekim 2026

- F3 LOW artık üç odanın altı büyük kabuk yüzeyinde triplanar yerine standart UV materyal varyantı kullanır. MEDIUM/HIGH world triplanar varyantını geri getirir; paylaşılan PBR cache korunur. Triplanar'ın ek doku örneklemesini düşük kalite için kaldırmak amaçlanır; FPS kazanımı ölçülmedi.
- `tests/test_quality_shell_mapping_contract.py` 4 statik test ve `tests/godot_flow_smoke.gd` HIGH→LOW→MEDIUM materyal/çarpışma koruma motor kontrolleri. Godot motoru olmadan motor kontrolleri çalıştırılamadı.


## v0.1.31 — 14 Ekim 2026 | Dünya ölçeğinde PBR UV

- `scripts/room_builder.gd`: Gerçeklik/Ev/Okul'daki altı büyük oda kabuğu yüzeyinde dünya koordinatlı triplanar UV (0,75 tekrar/metre) kullanılır. 12 metrelik yüzeyde yalnızca iki tekrar nedeniyle büyüyen doku ölçeği azaltıldı; küçük mobilyalar daha ucuz standart UV yolunda kaldı.
- Önbellek anahtarı UV ve triplanar shader varyantlarını ayırır; fizik, etkileşim, oda yerleşimi ve kayıt biçimi değişmedi. Triplanar GPU'da daha çok doku örnekler; gerçek FPS/VRAM henüz ölçülmedi.
- `tests/test_world_scale_uv_contract.py`: 4 yeni **statik** kontrol; `tests/godot_flow_smoke.gd`: üç odada zemin/duvar mapping ve yatakta normal UV için motor doğrulama kontrolleri (Godot yok, çalıştırılmadı).
- Önceki v0.1.30 Library ZIP SHA-256 `1cb2590c48cfe865a8a58e01493928a27cc3898994f0336867b5951f12428a91` eşleşti, eski manifest 64/64 PASS. Godot 4.3+ gerçek parse/render, Windows EXE, GPU/FPS ve F5/F9 I/O hâlâ doğrulanmadı.

## v0.1.30 — 14 Ekim 2026 | Bütün katmanlarda PBR/ACES görsel temel

- Gerçeklik, Ev, Okul ortak PBR yüzeyleri: 5 tür albedo/normal/roughness haritası, toplam 15 özgün 512px doku; paylaşılan materyal/texture cache.
- Forward+ ve ACES tonemap, F3 üç kademeli SSAO/SSIL/gölge/MSAA, yapay glow kapalı. Dekoratif mimari ve fizik/collision değiştirmeyen detaylar eklendi.
- `tools/build_pbr_textures.py`, `tests/test_global_pbr_contract.py`, `docs/VISUAL-QUALITY-TR.md` ve motor görsel kaynak smoke denetimleri eklendi.
- **8K, gerçek fotogrametri, görsel/performans motor kabulü YOK.** Bu aşama bir temeldir; bütün oyunda ileri seviye fotogerçekçilik tamamlandı demek değildir.

## v0.1.29 — 14 Ekim 2026

- `scripts/save_codec.gd`: doğrulanmış JSON kayıtlarından dönen `fuses` ve `seal` dizileri artık `int` öğelere dönüştürülür. Godot JSON sayılarını `float` olarak ayrıştırsa bile F9 sonrası bulmaca düğmelerinin `%` işlemi tamsayılarla çalışır; mevcut aralık/ilerleme doğrulaması önce uygulanır. Yeni kayıt şeması veya dosya biçimi yoktur.
- `tests/test_checkpoint_integer_arrays_contract.py`: dört yeni **statik** regresyon testi. `tests/godot_flow_smoke.gd`: checksum/legacy kayıt çözümü ve F9 benzeri durumdan sonra sigorta döndürme için dört yeni motor kontrolü (motor yokluğundan çalıştırılmadı).
- Önceki Library v0.1.28 ZIP SHA-256 `d8ff75452582fdc7860bd03b2f76ae481cb0cedeaed1d1e7ccc45ca0f2b45628` **eşleşti**; eski manifest **45/45 PASS**. Godot 4.3+ binary yok; gerçek import/parse, UI, Windows Alt+Tab, F5/F9 I/O, Windows EXE, FPS ve multiplayer **YAPILMADI**.

## v0.1.28 — 14 Ekim 2026

- `scripts/main.gd`: `_open_fuses`, `_open_locker` ve `_open_seal` doğrudan/gecikmiş çağrılarda artık oda, odak, aktif oyun, dalış/bitiş ve açık modal bağlamını doğrular. Prolog/not/başka bulmaca üstüne yeni modal açılmaz; aktif bulmacanın kendi tuşlarıyla yenilenmesi korunur.
- `tests/test_puzzle_dialog_entry_contract.py`: 4 yeni **statik** test; `tests/godot_flow_smoke.gd`: 6 yeni motor kontrolü (prolog, not, oda, arka plan ve meşru yenileme), motor yoksa **çalıştırılamaz**.
- Kaynak v0.1.27 Library ZIP SHA-256 `03ca4c965a1de3d4a74ac30319608509610913dbe440aab0a3562e4dd9a46c3a` doğrulandı; önceki manifest **44/44 PASS**. Gerçek Godot import/parse, Windows UI, F5/F9 I/O, EXE, GPU/FPS ve multiplayer kabulü bekler.

## v0.1.27 — 14 Ekim 2026

- `scripts/main.gd`: `_wrong_answer()` artık doğrudan/gecikmiş çağrılarda yalnızca odaklı, aktif, modal açık ve doğru odadaki **henüz çözülmemiş** sigorta/dolap/mühür bulmacasında denge azaltır. Prolog, not, arka plan, kapatılmış bulmaca ve oyun bitişi cezalandırılamaz; normal yanlış cevap -9 korunur.
- `tests/test_wrong_answer_guard_contract.py`: 4 yeni **statik** Python testi. `tests/godot_flow_smoke.gd`: 5 yeni motor senaryosu yazıldı, ancak Godot 4.3+ çalıştırıcısı bulunmadığından **çalıştırılmadı**.
- Önceki Library v0.1.26 ZIP SHA-256 `2a434d1d4481c656d66c58200dca711d4cf8b5d379d6fe142dbcf65d55b7fdce` doğrulandı; eski manifest **43/43 PASS**. Gerçek Windows oynanış/Alt+Tab, F5/F9 I/O, EXE ve FPS kabulü bekliyor.

## v0.1.26 — 14 Ekim 2026

- `scripts/main.gd`: `_fold()` doğrudan/gecikmiş çağrılarda yalnızca odaklı, başlamış, modalsız, devam eden oyunda **süre bitmişse veya denge sıfırlanmışsa** çalışır. Sağlıklı oyun, prolog, Alt+Tab, modal, dalış ve tamamlanmış oyun durumunda erken çöküş engellenir. Meşru çöküşün 3 dakikalık kurtarma süresi korunur.
- `tests/test_fold_guard_contract.py`: 4 yeni **statik** regresyon testi. `tests/godot_flow_smoke.gd`: 6 yeni motor kontrolü (prolog, sağlıklı durum, odak kaybı, modal, meşru çöküş, bitiş sonrası); gerçek Godot motoru olmadan **çalıştırılmadı**.
- Başlangıç Library v0.1.25 SHA-256 `c05d86c76e1f2bf90f720b9917483ceb97418c3375d52e0de11c7d5a99ec2e48` doğrulandı, eski manifest **42/42 PASS**. Windows EXE, FPS ve multiplayer doğrulanmadı.

## v0.1.25 — 14 Ekim 2026

- `scripts/main.gd`: `_wake()` doğrudan/gecikmiş çağrılarda artık `_can_interact("wake_bell")` ve `seal_open` koşullarını yeniden denetler. Okuldan, çözülmemiş mühürle, odak dışındayken veya açık modal sırasında bitişe atlanamaz; meşru Ev çanı akışı korunur.
- `tests/test_wake_guard_contract.py`: dört yeni **statik** regresyon testi. `tests/godot_flow_smoke.gd`: prologda, Okulda ve arka planda doğrudan bitişin reddi için üç **motor bekleyen** senaryo.
- Kaynak v0.1.24 Library ZIP SHA-256 `05da5695a4d7fd098a636d1ea16c97b1924ba84f0979506881e9320a760372f2` eşleşti; eski manifest **41/41 PASS**. Gerçek Godot 4.3+ motor kabulü hâlâ bekliyor.

## v0.1.24 — 14 Ekim 2026

- `scripts/main.gd`: doğrudan/gecikmiş `_start_dive()` çağrısı artık E ile yatak etkileşiminin kullandığı `_can_interact("bed")` kapısından geçer. Odak dışı, prolog/bulmaca modalı açık, dalış sürüyor, oyun bitmiş veya oyuncu Gerçeklik dışında ise dalış başlatılmaz; devam eden 12 saniyelik sayaç ve token sıfırlanmaz.
- `tests/test_dive_start_contract.py`: dört yeni **statik** regresyon testi; `tests/godot_flow_smoke.gd`: dört yeni doğrudan başlangıç senaryosu (gerçek motor kabulü bekler).
- Önceki v0.1.23 Library ZIP SHA-256 `21a06c9013b5b73a647e8136be59ee9e951d9e8f420f8614c63a0494a5759563` eşleşti, önceki manifest **40/40 PASS**. Godot 4.3+ binary yok; GitHub DNS başarısız. Motor/Windows/GPU doğrulaması yapılmadı.

## v0.1.23 — 14 Ekim 2026

- `scripts/main.gd`: doğrudan/gecikmiş `_load_game()` (F9) çağrısı pencere odak dışındayken artık diski okumadan ve açık modalı kapatmadan döner. Klavye F9 zaten odağa bağlıydı; böylece programatik yükleme de aynı kapıdan geçer.
- `tests/test_background_load_contract.py`: dört yeni **statik** sözleşme testi. `tests/godot_flow_smoke.gd`: izole F5 checkpoint'i üzerinde arka plan klavye/doğrudan F9 reddi ve odak geri gelince normal F9 geri yükleme senaryoları (motor kabulü bekler).
- Kaynak v0.1.22 Library ZIP SHA-256 `1509504c8fa0684d1fb4b773d9397a19cda80e56473770b486df7b1d20614eaa` doğrulandı; eski manifest **39/39 PASS**. Godot 4.3+ motor testi henüz yok.

## v0.1.22 — 14 Ekim 2026

- `scripts/main.gd`: `_finish_dive` artık geçerli token taşıyan doğrudan/gecikmiş çağrılarda da pencere odağını ve **sıfırlanmış** 12 saniyelik geri sayımı doğrular. Arka planda veya erken gelen callback ile Ev'e geçiş engellenir; normal odaklı bitiş ve R iptali korunur.
- `tests/test_dive_completion_contract.py`: dört yeni **statik** kaynak testi. `tests/godot_flow_smoke.gd`: geçerli token'la erken bitiş ve arka planda sıfır sayaçla doğrudan bitişin reddi için iki motor kontrolü (motor yokluğundan henüz çalıştırılmadı).
- Önceki v0.1.21 Library ZIP SHA-256 `a66bd883e022ae1d3476842804bcc9725f31ac037ce11b581aa23cf87015ada1` eşleşti; önceki kaynak manifesti 38/38. Godot 4.3+ motor kabulü, Windows EXE ve GPU/FPS hâlâ bekliyor.

## v0.1.21 — 14 Ekim 2026

- `scripts/main.gd`: doğrudan `_save_game()` çağrısı da pencere odağı yokken hiçbir geçici/ana/yedek kayıt dosyasına dokunmadan döner; mevcut klavye F5 odağı ve atomik kayıt akışı korunur.
- `tests/test_background_save_contract.py`: 4 yeni Python **statik** kontrol; `tests/godot_flow_smoke.gd`: izole `user://` içinde pending sentinel, gerçek F5 yazma ve F9 yükleme için yeni motor kontrolleri. Motor olmadığından bu kontroller **çalıştırılmadı**.
- Önceki v0.1.20 Library ZIP SHA-256 `13fbfa310c860e057dbce86ece01708daf04c33fca8dae8de17d6d0813ce2182` eşleşti, kaynak manifesti 37/37. Gerçek Godot import/parse, Windows export ve FPS henüz doğrulanmadı.

# Dream Layers — Değişiklik geçmişi

## v0.1.20 — 14 Ekim 2026

- `scripts/main.gd`: `_can_interact` ve `_choice` artık arka plan odağında doğrudan etkileşim / modal callback çağrılarını reddeder. `_load_game` başarılı olursa hareket izni odağa bağlı kalır.
- `tests/test_background_action_contract.py`: dört yeni Python **statik** sözleşme testi; `tests/test_action_gate_contract.py` mevcut beklentisi güncellendi. `tests/godot_flow_smoke.gd`: prolog, yatak ve sigorta için üç yeni **motor bekleyen** senaryo.
- Başlangıç Library v0.1.19 SHA-256 `51b7345c793ed5dba37f0e5dd77fb72fc93f24418dd6f0c512443c029fdae416` doğrulandı; önceki manifest **36/36 PASS**. Godot 4.3+ çalıştırıcısı yok; gerçek parser/UI/Windows Alt+Tab/F5-F9 I/O/EXE/FPS **YAPILMADI**.

## v0.1.19 — 14 Ekim 2026

- `scripts/main.gd`: yalnızca modal gerçekten `close` seçeneği sunuyorsa `_choice("close")` kabul edilir. Prolog/bitiş onayını doğrudan veya eski callback ile atlatma riski azaltıldı.
- `tests/test_modal_close_contract.py`: 4 yeni statik Python testi; `tests/godot_flow_smoke.gd`: prolog ve bitiş için 2 motor smoke kontrolü.
- Önceki v0.1.18 Library ZIP SHA-256 `181a5c70e1f50f21d7221d4343d04c698e6a0e98f14aeef5ca7ba34b019735ee` eşleşti; gerçek Godot binary bulunamadı.

## v0.1.18 — 14 Ekim 2026

- `scripts/main.gd`: F5 kaydında checksum'lı JSON zarfını **geçici dosyayı WRITE modunda açmadan önce** oluşturup 16 KiB sınırını kontrol eder. Böylece geçersiz/büyük içerik eski bekleyen geçici dosyayı boşaltmaz; mevcut ana kayıt/yedek rotasyonu değişmez.
- `tests/run_godot_smoke.py`: sıfır çıkış kodu ve başarılı smoke özetine rağmen Godot `ERROR:` / `FATAL ERROR:` günlüklerini de başarısız sayar; mevcut `SCRIPT ERROR:` ve `Parse Error:` reddi korunur.
- `tests/test_engine_runner.py`: dört yeni **gerçek Python mock runner testi** (toplam Python 91/91); `tests/test_save_write_order_contract.py`: üç yeni **statik kaynak testi**. `tests/godot_flow_smoke.gd`: izole disk klasöründe 16 KiB üstü checkpoint'i reddetme kontrolü (Godot motoru yokluğundan henüz çalıştırılmadı).
- Kaynak v0.1.17 Library ZIP SHA-256 `01171310b62ce56855b975cf26c6b321322112fd3b873817ced902bebb009292` **eşleşti**. Gerçek Godot import/parse, kayıt I/O, Windows EXE, GPU/FPS ve multiplayer **YAPILMADI**.

## v0.1.17 — 14 Ekim 2026

- `scripts/main.gd`: Alt+Tab veya başka uygulamaya geçiş sonrası ilk odaklı `_process` karesinin büyük `delta` değerini **bir kez yok sayar**. Böylece arka planda geçen süre ilk dönüş karesinde 12 saniyelik dalışa veya 15 dakikalık rüya sayacına yanlışlıkla eklenmez; sonraki odaklı kareler normal ilerler.
- `tests/test_focus_resume_delta_contract.py`: 4 yeni Python **statik** test (toplam **84/84**). `tests/test_dive_focus_contract.py`: yeni korumalı zaman değişkenine uyarlanmış önceki beklenti. `tests/godot_flow_smoke.gd`: dalış ve rüya zamanlayıcısı için iki yeni **motor bekleyen** ilk-dönüş-karesi kontrolü.
- Başlangıç Library v0.1.16 ZIP SHA-256 `bef79b261fe16873ddca887107e1cf516a8953073c5558d73f5bf063312329c0` **eşleşti**, önceki manifest 33/33 PASS. Godot 4.3+ çalıştırıcısı yok: gerçek import/parse, Windows Alt+Tab, kayıt I/O, EXE, FPS/GPU ve multiplayer **YAPILMADI**.

## v0.1.16 — 14 Ekim 2026

- `scripts/main.gd`: 12 saniyelik yatak dalışı artık `SceneTreeTimer` ile duvar saatinde değil, `_process` içinde **yalnızca pencere odaktayken** ilerleyen geri sayımla tamamlanır. Alt+Tab sırasında dalış otomatik bitmez; R ile iptal sayacı sıfırlar ve eski `transition_token` tamamlamaları reddedilir. Dalışın bittiği karede 15 dakikalık rüya süresi tüketilmez.
- `tests/test_dive_focus_contract.py`: 6 yeni **statik** sözleşme testi (toplam **80** Python testi); `tests/godot_flow_smoke.gd`: yatakla başlatma, odak duraklatma, R iptali, eski token reddi, devam/bitiş ve rüya süresi için 8 **motor bekleyen** kontrol. Eski `create_timer(12.0)` varsayımı kullanan üç statik test güncellendi.
- Başlangıç v0.1.15 Library ZIP SHA-256 `1b6e9a5ee5a60ae3372f7a3692c03d23083e2fe805beb6426d866b33c45a470f` **eşleşti**, kaynak manifesti **32/32 PASS**. Gerçek Godot 4.3+ import/parse, Alt+Tab, oyun, Windows EXE ve GPU/FPS testi motor yokluğundan **YAPILMADI**.

## v0.1.15 — 14 Ekim 2026

- `scripts/player.gd`: hareket izni kapalıyken `_physics_process` artık yerçekimi ve `move_and_slide()` çağırmaz; tüm `velocity` bileşenlerini sıfırlar. Böylece odak kaybı, modal diyalog, geçiş veya bitiş sırasında birikmiş momentumun oyuncuyu sürüklemesi önlenmek istenir.
- `tests/test_player_freeze_contract.py`: dört yeni **statik** kaynak sözleşmesi testi. `tests/godot_flow_smoke.gd`: arka plan ve açık modal sırasında konum/momentum için dört yeni **motor bekleyen** kontrol.
- Önceki Library v0.1.14 ZIP SHA-256 `00815bcce9edfdcc580ec584e7e73dc02d469aa511def7a53028ea8a6e9b2ee4` **eşleşti**, eski manifest **31/31 PASS**. Python statik regresyonları **74/74 PASS**. Godot binary bulunamadı: gerçek GDScript import, CharacterBody3D fizik, Alt+Tab, Windows EXE, GPU/FPS **YAPILMADI**.

## v0.1.14 — 14 Ekim 2026

- `scripts/main.gd`: uygulama odak kaybında rüya geri sayımını durdurma, oyuncu hareketini kapatma ve arka plan oyun kısayollarını reddetme; odak geri gelince sürdürme. 12 saniyelik dalış animasyonu zamanlayıcısı değiştirilmedi.
- `tests/test_focus_pause_contract.py`: 4 yeni **statik** sözleşme testi; `tests/test_interaction_contract.py` odak-kapısı sonrası hareket beklentisini günceller; `tests/godot_flow_smoke.gd` 5 yeni **henüz çalıştırılmamış motor** kontrolü (odak kaybı/geri gelişi ve zaman/tuşlar).
- v0.1.13 Library ZIP SHA-256 `46ca5ad794652e1afdc6f58b1ffa616a342b2d8a90f1c0498e11a85035d1ad6b` doğrulandı; eski kaynak manifesti 30/30. Python statik regresyonları **70/70 PASS**. Godot binary yok: gerçek uygulama odağı/Alt+Tab, GDScript import, Windows EXE, GPU/FPS **YAPILMADI**.

## v0.1.13 — 14 Ekim 2026

- `scripts/player.gd`: özel `reach_m` sınırı için yatay X/Z mesafesi yerine kamera ışın başlangıcından çarpma noktasına 3D uzaklık kontrolü (`_hit_within_reach`); negatif erişim sınırını reddetme. Mevcut RayCast3D çarpışma kapısı ve öz-gövde istisnası korunur.
- `tests/test_reach_3d_contract.py`: 4 yeni **statik** kontrol; `tests/test_interaction_contract.py`: eski yatay erişim varsayımı yeni sözleşmeye uyarlandı. `tests/godot_flow_smoke.gd`: dikey uzaklık, yakın hedef ve negatif sınır için 3 yeni **henüz çalıştırılmamış motor** senaryosu.
- v0.1.12 Library ZIP SHA-256 `b158eaddfed06f8bab234418ef4601569542f3cb49446163e8f5e2a42114cfed` doğrulandı; eski manifest 29/29. Python kaynak testleri **66/66 PASS**. Godot binary bulunamadığından gerçek GDScript parse/fizik/Windows EXE/GPU FPS **YAPILMADI**.

## v0.1.12 — 14 Ekim 2026

- `scripts/save_codec.gd`: ilk yatak dalışından önce sigorta/mühür değerlerinin başlangıç düzeninden sapmasını reddet; arşiv bulunmadan mühür simgelerinin değiştirilmiş olduğu kayıtları reddet. Meşru oyun akışı ve mevcut kayıt biçimi değişmedi.
- `tests/test_checkpoint_progress_contract.py`: dört yeni **statik** sözleşme testi; `tests/godot_flow_smoke.gd`: üç yeni **henüz çalıştırılmamış motor** negatif senaryosu.
- v0.1.11 Library ZIP SHA-256 `3a3cebfd2f693ec7b2e9b1fc9b48a0476d9f6b34446630ad485d8258618912dd` doğrulandı; önceki manifest 28/28. Python kaynak testleri 62/62. Godot 4.3+ binary bulunamadı ve GitHub DNS çözümlenemedi: gerçek parser/import, save/load, Windows EXE ve GPU/FPS **YAPILMADI**.

## v0.1.11 — 14 Ekim 2026

- `scripts/overlay.gd`: yalnızca açık `close` seçeneği olan modal pencerelerde Esc ile iptal; odaklanmış UI elemanı tüketmeden `_input` seviyesinde yakalama, mevcut nesil-korumalı `_choose("close", dialog_generation)` yolunu kullanma; prolog/bitiş zorunlu onayını koruma.
- `tests/test_keyboard_cancel_contract.py`: dört yeni **statik** kaynak regresyonu. `tests/godot_flow_smoke.gd`: prologun Esc ile geçilememesi, sigorta/dolap iptali ve eski callback/Enter reddi için gelecekteki motor kontrolleri.
- v0.1.10 Library ZIP SHA-256 `2bea7973acc9a0f56b638104ad9ae5ab45350d3699c0e4c143bc256ac0fd90b6` doğrulandı; kaynak manifesti 27/27. Godot 4.3+ binary yok: gerçek GDScript parse/klavye/fizik/Windows EXE/FPS **YAPILMADI**.

## v0.1.10 — 14 Ekim 2026

- `scripts/overlay.gd`: modal açılışında ilk düğmeye klavye odağı verilir; dolap penceresinde odağı kod alanı devralır. LineEdit Enter sinyali, mevcut dialog-generation korumalı `_choose()` yolundan gönderilir.
- `tests/test_keyboard_access_contract.py`: 4 yeni statik sözleşme testi. `tests/godot_flow_smoke.gd`: prolog/dolap odağı, Enter ile dolap çözümü, kapanıştan sonra yinelenen Enter koruması.
- v0.1.9 ZIP SHA-256 `8481f23238065aaac291f2734de65a52fd7ba8a8f3a39e2e2949448565d87d6f` doğrulandı. Gerçek Godot UI/Windows/performans kabulü henüz yok.

## v0.1.9 — 13 Ekim 2026

- `scripts/player.gd`: RayCast3D oyuncu kapsülünü açıkça hariç tutar; iç içe kamera/eye düğümlerinin `exclude_parent` davranışına güvenilmez.
- `scripts/overlay.gd`: değişmeyen HUD metinleri ve nişangâh görünürlüğü yeniden atanmaz; UI layout invalidation olasılığı azaltılır.
- `tests/test_runtime_safety_contract.py`: üç yeni Python **statik** kontrol. `tests/godot_flow_smoke.gd`: motor mevcut olduğunda kapsül içinden kısa raycast ile oyuncunun kendi gövdesini görmediğini sınar.
- Godot 4.3+ motoru erişilebilir olmadığından gerçek raycast, GDScript parser, oyun açılışı, Windows EXE ve GPU/FPS ölçümü **YAPILMADI**.

## v0.1.8 — 13 Ekim 2026

- `tests/run_godot_smoke.py`: Godot 4.3+ sürüm kapısı, `--version` doğrulaması, sıfırdan büyük kontrol sayısı ve sıfır hata içeren zorunlu smoke kapanış işareti; eksik işaretle sıfır çıkış kodunu bile başarısız sayma. Geçici HOME/XDG/APPDATA kökleriyle kullanıcı kayıtlarına erişimi sınırla.
- `tests/godot_flow_smoke.gd`: `PackedScene.instantiate()` sonucu `Node` olarak statik çıkarılıp dinamik oyun script üyelerine erişimi engellemesin diye Variant üzerinden çağır.
- `tests/test_engine_runner.py`: 6 gerçek Python testinde sürüm reddi, eksik smoke işareti, parse hatası, geçici dizinler ve dinamik çağrı sözleşmesi.
- Godot motoru kurulamadığı için **gerçek import/parse, oyun, Windows EXE ve GPU/FPS kabulü yapılmadı**. Runner'ın kendi Python testleri motor kanıtı değildir.

## v0.1.7 — 13 Ekim 2026

- `scripts/save_codec.gd`: SHA-256 kontrollü checkpoint zarfı (`format`, iç JSON `data`, `sha256`) kodlama/çözme. Geçerli görünümlü ama değiştirilmiş JSON yüklenmez; eksik/bozuk zarf sessizce eski biçim olarak yorumlanmaz.
- `scripts/main.gd`: F5 yeni checksum'lı biçimi yazar; diskteki geçici dosya tekrar okunup checksum doğrulanmadan ana kayıt/yedek değiştirilmez. F9 önceki v0.1.4–v0.1.6 şemasız JSON kayıtlarını da okuyabilir.
- `tests/test_checksum_contract.py`: 6 yeni **statik** regresyon testi (toplam 41). `tests/godot_flow_smoke.gd`: checksum round-trip, değiştirilmiş veri, eksik checksum, eski kayıt ve izole disk dosyası senaryoları eklendi (**motor olmadığından çalıştırılmadı**).
- SHA-256 yalnızca tesadüfi veri bozulmasını tespit eder; dosyaya erişen saldırgana karşı kimlik doğrulama değildir. Gerçek Godot/Windows kabulü, FPS ve `.exe` hâlâ bekliyor.

## v0.1.6 — 13 Ekim 2026

- `scripts/main.gd`: geçerli ana kaydı önce `.rollback` aşamasına taşıyarak eski `.bak` dosyasını yeni ana kayıt doğrulanana kadar koru; başarısız terfide staged ana kaydı geri yüklemeyi dene.
- `scripts/main.gd`: F9 kurtarma sırası artık ana kayıt → kesintiye uğramış rollback → eski yedek.
- `tests/godot_flow_smoke.gd`: izole test dizininde yarıda kesilmiş rotasyon ve doğrulanmış yeni ana kayıt sonrası backup güncelleme senaryoları.
- `tests/test_backup_recovery_contract.py`: iki yeni kaynak sözleşmesi testi; mevcut kayıt testleri yeni işlem sırasına göre güncellendi.
- Godot 4.3+ binary bulunamadığından gerçek motor, Windows EXE ve FPS kabulü yapılmadı.

## v0.1.5 — 13 Ekim 2026

- `scripts/main.gd`: yeni geçici checkpoint'i diskten doğrulamadan mevcut kayıt/yedeği değiştirmeme; bozuk ana kaydı sağlam `.bak` üzerine taşımama.
- `tests/godot_flow_smoke.gd`: yalnızca izole `user://dream_layers_smoke_checkpoint_v015` klasöründe bozuk ana kayıt + sağlam yedek + yeni kayıt terfi senaryosu; test sonunda dosyaları temizler.
- `tests/test_backup_recovery_contract.py`: beş yeni statik sözleşme testi. Godot motoru mevcut olmadığından gerçek dosya sistemi senaryosu henüz çalıştırılmadı.

## v0.1.4 — 13 Ekim 2026

- `scripts/save_codec.gd`: sürümlü, sınırlandırılmış yerel checkpoint şeması ve ilerleme tutarlılığı doğrulaması.
- `scripts/main.gd`: F5/F9 ile yerel kayıt/yükleme; geçici dosya, yedek, bozuk kayıt reddi ve yüklemede sahne/phase yenileme.
- `tests/test_save_contract.py`: 8 statik sözleşme testi; motor smoke'a 5 codec senaryosu eklendi.
- Kaynak testleri ve SHA manifesti yenilendi. Gerçek Godot/Windows çalıştırma testi henüz yapılmadı.

## v0.1.3 — 13 Ekim 2026

- `scripts/main.gd`: aktif diyalog bağlamı (`intro`, `note`, `fuses`, `locker`, `seal`, `ending`) kontrolü; başka bir pencereden gelen puzzle submit/turn olayları reddedilir.
- `scripts/overlay.gd`: her yeni modal/dismiss işleminde artan nesil sayacı; eski modal düğmelerinin callback'leri geçersizdir.
- `tests/godot_flow_smoke.gd`: farklı diyalogdan gelen bulmaca callback'i ve eski modal nesli için yeni motor smoke adımları (Godot olmadığı için çalıştırılmadı).
- `tests/test_dialog_context_contract.py`: 4 yeni statik regresyon kontrolü (toplam 20).
- `tests/verify_manifest.py`: ZIP içindeki kaynak dosya envanterini ve SHA-256 hash'lerini tekrar doğrulama.
- `README-TR.md`, `docs/PROJECT-STATE-TR.md`, `docs/TEST-REPORT-TR.md`, `docs/MANIFEST.json`: sürüm, test ve devir notları güncellendi.

## v0.1.2 — 13 Ekim 2026

- `scripts/main.gd`: 9 etkileşim için katman ve lifecycle kapısı; çözülmüş bulmacalarda gecikmiş callback koruması; sigorta/mühür düğme indeks doğrulaması.
- `tests/test_action_gate_contract.py`: 7 statik regresyon testi; toplam 16 statik test.
- `tests/run_godot_smoke.py` ve `tests/godot_flow_smoke.gd`: Godot kurulduğunda gerçek motor import/parse ve bulmaca durum akışı smoke testi için çalıştırıcı (bu ortamda **çalıştırılmadı**).
- `README-TR.md`, `docs/TEST-REPORT-TR.md`, `docs/PROJECT-STATE-TR.md`, `docs/MANIFEST.json`: durum ve kaynak manifesti.

## v0.1.1 — 13 Ekim 2026

- `scripts/main.gd`: dolap için elle kod doğrulama; geçersiz girdide cezasız reddetme; bitişte hareket kilidi.
- `scripts/overlay.gd`: modal pencerede dört karakterlik kod girişi.
- `scripts/player.gd`: etkileşim mesafesi hedef merkezinden ray çarpma noktasına taşındı.
- `tests/test_interaction_contract.py`: dokuz statik regresyon testi.
- `README-TR.md`, `docs/TEST-REPORT-TR.md`, `docs/MANIFEST.json`, `docs/PROJECT-STATE-TR.md`: test ve devam kaydı.

## v0.1.0 — 13 Ekim 2026

- İlk Godot 4 kaynak prototipi. 3 oda, birinci şahıs hareket, TR/EN prolog, dört etkileşim ve faz/çöküş taslağı.
