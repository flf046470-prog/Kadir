"""Executable Python tests for the Godot smoke runner (NOT Godot engine tests)."""
import importlib.util
import contextlib
import io
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

RUNNER = Path(__file__).with_name("run_godot_smoke.py")
spec = importlib.util.spec_from_file_location("dreamlayers_godot_runner", RUNNER)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
SMOKE = Path(__file__).with_name("godot_flow_smoke.gd").read_text(encoding="utf-8")


def fake_result(out: str, code: int = 0):
    return subprocess.CompletedProcess(args=[], returncode=code, stdout=out, stderr="")


class EngineRunnerTests(unittest.TestCase):
    def test_reject_old_and_unrelated_executables(self):
        for text in ("3.6.stable.official", "4.2.2.stable.official", "not an engine", "5.0.stable"):
            self.assertFalse(runner.supported_version(text), text)
        for text in ("4.3.stable.official", "4.4.1.stable.official", "Godot Engine v4.5"):
            self.assertTrue(runner.supported_version(text), text)

    def test_exit_zero_without_assertion_is_not_a_pass(self):
        self.assertFalse(runner.valid_smoke_result("Game started, exit code 0"))
        self.assertFalse(runner.valid_smoke_result("DREAM LAYERS ENGINE SMOKE: 0 checks, 0 failures"))
        self.assertFalse(runner.valid_smoke_result("DREAM LAYERS ENGINE SMOKE: 22 checks, 1 failures"))
        self.assertTrue(runner.valid_smoke_result("DREAM LAYERS ENGINE SMOKE: 22 checks, 0 failures"))

    def test_runner_requires_version_and_smoke_marker(self):
        with patch.object(runner.subprocess, "run", side_effect=[
            fake_result("4.4.1.stable.official"), fake_result("import completed"), fake_result("no smoke summary")
        ]) as call:
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.run_engine("/fake/godot"), 1)
            self.assertEqual(call.call_count, 3)
        with patch.object(runner.subprocess, "run", side_effect=[
            fake_result("4.4.1.stable.official"), fake_result("import completed"),
            fake_result("DREAM LAYERS ENGINE SMOKE: 33 checks, 0 failures")
        ]):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.run_engine("/fake/godot"), 0)

    def test_runner_rejects_engine_parse_errors_even_if_exit_zero(self):
        with patch.object(runner.subprocess, "run", side_effect=[
            fake_result("4.4.1.stable.official"), fake_result("Parse Error: broken script")
        ]):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.run_engine("/fake/godot"), 1)

    def test_engine_error_log_rejected_even_with_zero_exit(self):
        with patch.object(runner.subprocess, "run", side_effect=[
            fake_result("4.4.1.stable.official"), fake_result("ERROR: Cannot open script\n")
        ]):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.run_engine("/fake/godot"), 1)

    def test_smoke_error_log_rejected_despite_green_summary(self):
        with patch.object(runner.subprocess, "run", side_effect=[
            fake_result("4.4.1.stable.official"), fake_result("import completed"),
            fake_result("ERROR: Broken scene\nDREAM LAYERS ENGINE SMOKE: 40 checks, 0 failures")
        ]):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.run_engine("/fake/godot"), 1)

    def test_engine_stderr_error_rejected(self):
        with patch.object(runner.subprocess, "run", side_effect=[
            fake_result("4.4.1.stable.official"),
            subprocess.CompletedProcess(args=[], returncode=0, stdout="imported", stderr="  ERROR: Failed to load resource")
        ]):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.run_engine("/fake/godot"), 1)

    def test_warnings_are_not_fatal_without_engine_errors(self):
        with patch.object(runner.subprocess, "run", side_effect=[
            fake_result("4.4.1.stable.official"), fake_result("WARNING: Editor hint"),
            fake_result("WARNING: harmless\nDREAM LAYERS ENGINE SMOKE: 40 checks, 0 failures")
        ]):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(runner.run_engine("/fake/godot"), 0)

    def test_isolated_user_data_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            env = runner.isolated_environment(Path(temp))
            for key in ("HOME", "XDG_DATA_HOME", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "APPDATA", "LOCALAPPDATA"):
                self.assertTrue(Path(env[key]).is_dir())
                self.assertTrue(Path(env[key]).is_relative_to(Path(temp)))

    def test_smoke_game_uses_dynamic_dispatch(self):
        self.assertIn("var game = scene.instantiate()", SMOKE)
        self.assertNotIn("var game := scene.instantiate()", SMOKE)


if __name__ == "__main__":
    unittest.main()
