"""Run the real Godot 4.3+ import and gameplay smoke, rejecting false-green runs.

Python unit tests for this runner are NOT substitutes for an installed Godot.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SMOKE_RESULT = re.compile(r"DREAM LAYERS ENGINE SMOKE:\s*(\d+) checks,\s*(\d+) failures")
VERSION = re.compile(r"(?<!\d)4\.(\d+)(?:\.\d+)?\b")
ENGINE_ERROR_LINE = re.compile(r"(?mi)^\s*(?:ERROR:|FATAL ERROR:)")


def supported_version(output: str) -> bool:
    """Only Godot 4.3+ is supported; reject Godot 3.x and unrelated executables."""
    match = VERSION.search(output.strip())
    return match is not None and int(match.group(1)) >= 3


def valid_smoke_result(output: str) -> bool:
    """An exit code of zero without the smoke's final assertion is NOT a pass."""
    matches = SMOKE_RESULT.findall(output)
    return len(matches) == 1 and int(matches[0][0]) > 0 and int(matches[0][1]) == 0


def has_engine_errors(output: str) -> bool:
    """Reject logged Godot errors even when the process exits successfully."""
    return ("SCRIPT ERROR:" in output or "Parse Error:" in output
            or ENGINE_ERROR_LINE.search(output) is not None)


def isolated_environment(directory: Path) -> dict[str, str]:
    """Redirect user-data roots so smoke cannot modify normal player saves."""
    env = os.environ.copy()
    for key, dirname in {
        "HOME": "home", "XDG_DATA_HOME": "data", "XDG_CONFIG_HOME": "config",
        "XDG_CACHE_HOME": "cache", "APPDATA": "appdata", "LOCALAPPDATA": "localappdata",
    }.items():
        path = directory / dirname
        path.mkdir(parents=True, exist_ok=True)
        env[key] = str(path)
    return env


def run_engine(engine: str) -> int:
    try:
        version = subprocess.run([engine, "--version"], capture_output=True, text=True, timeout=15, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        print(f"FAIL: Godot version check could not run: {error}")
        return 1
    version_text = version.stdout + "\n" + version.stderr
    if version.returncode != 0 or not supported_version(version_text):
        print(f"FAIL: Godot 4.3+ required; got {version_text.strip()!r}")
        return 1

    with tempfile.TemporaryDirectory(prefix="dreamlayers-godot-user-") as tmp:
        env = isolated_environment(Path(tmp))
        commands = [
            ("import/parse", [engine, "--headless", "--path", str(ROOT), "--editor", "--import", "--quit"]),
            ("gameplay state flow", [engine, "--headless", "--path", str(ROOT), "--script", "res://tests/godot_flow_smoke.gd"]),
        ]
        for label, command in commands:
            print("RUN:", label, flush=True)
            try:
                result = subprocess.run(command, capture_output=True, text=True, timeout=120, check=False, env=env)
            except (OSError, subprocess.TimeoutExpired) as error:
                print(f"FAIL {label}: {error}")
                return 1
            combined = result.stdout + "\n" + result.stderr
            print(combined[-10000:])
            if result.returncode != 0 or has_engine_errors(combined):
                print(f"FAIL {label}: return code {result.returncode}; engine errors detected: {has_engine_errors(combined)}")
                return 1
            if label == "gameplay state flow" and not valid_smoke_result(combined):
                print("FAIL gameplay state flow: missing or invalid smoke assertion summary")
                return 1
    print("PASS: real Godot 4.3+ headless import and gameplay state flow")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-engine", action="store_true", help="Fail if Godot is not installed")
    args = parser.parse_args()
    candidate = os.environ.get("GODOT_BIN", "")
    if candidate:
        if not Path(candidate).is_file():
            print(f"FAIL: GODOT_BIN does not point to a file: {candidate}")
            return 1
        engine = candidate
    else:
        engine = shutil.which("godot") or shutil.which("godot4")
    if engine is None:
        print("NOT RUN: Godot 4.3+ executable is unavailable; no engine test was performed")
        return 1 if args.require_engine else 2
    return run_engine(engine)


if __name__ == "__main__":
    sys.exit(main())
