## v0.1.39 — Oyun artık Godot 4.3'te gerçekten açılıyor ve kayıtlar yükleniyor

İlk gerçek motor testi iki kritik hata buldu: `main.gd` parse edilmiyordu (oyun hiç açılmıyordu) ve F9, ilerleme içeren her kaydı reddediyordu. İkisi de düzeltildi; headless motor smoke 232 kontrol, 0 hata ile geçiyor. Doğrulamak için: `GODOT_BIN=/godot/yolu python3 tests/run_godot_smoke.py --require-engine`.

## v0.1.38 — Oynanabilir sinematik prolog ve viral tasarım laboratuvarı

Gerçeklik katmanındaki prolog artık kısa bir TR/EN açılıştan sonra oyuncuya **masadaki saati incele → yatakta dalış** görevlerini verir. İsteğe bağlı saat etkileşimi penceredeki yansıma, saat ibresi ve lambada 2,2 saniyelik dekoratif, odak kaybında duran bir kaymayı tetikler; kamera, karakter ve çarpışma şekilleri oynatılmaz. Yatağa doğrudan girme geriye dönük uyumluluk için korunur. `docs/PROLOGUE-CINEMATIC-DESIGN-TR.md` GTA V / Inception *tasarım ilkelerini* özgün uygulamadan ayırır. `docs/STEAM-VIRAL-REVERSE-ENGINEERING-TR.md` ve `tools/viral_loop_lab.py` ise çevrim dışı hipotez modelidir, oyun içinde çalışan rastgele olay yöneticisi değildir. Godot motor testi bekleniyor.

## v0.1.36 — Zaman Yankıları (ilk özgün gözlem mekaniği)

Ev katmanındaki değişen renkli işarete bakıp **E** ile etkileş: her 90 saniyelik faz farklı Türkçe/İngilizce bellek ipucu gösterir. İsteğe bağlıdır; ana bulmacayı, dengeyi veya F5/F9 kayıt biçimini değiştirmez. Gizli fazların fizik çarpışması/raycast maskesi kapatılır. Tasarım ilhamları ve sonraki ölçüm kapıları `docs/VIRAL-MECHANICS-RESEARCH-TR.md` belgesinde; bu bir multiplayer/viral başarı iddiası değildir. Motor smoke hâlâ bekliyor.

## v0.1.35 — Görsel bevel mesh ve F3 donanım LOD birlikte

Gerçeklik, Ev ve Okul katmanlarında seçili yatak, dolap, masa ve kapı mesh'lerinin kenarları yuvarlatıldı. Önceki v0.1.34'teki F3 silindir donanım LOD ayarı korunuyor. Çarpışmalar, bulmacalar ve kayıt sistemi değiştirilmedi; gerçek Godot motor/render testi bekliyor. Fotogrametri veya 8K üretimi değildir.

## v0.1.34 — F3 dekoratif LOD

Üç katmandaki yuvarlak donanım artık F3 LOW/MEDIUM/HIGH'da 8/12/24 kenarlı silindir mesh kullanır. Görsel detay ve potansiyel mesh maliyeti kaliteye göre değişir; etkileşim/çarpışma kaynakları aynı kalır. Godot motorunda görüntüleme ve FPS henüz doğrulanmadı.

## v0.1.33 — Üç katmanda yuvarlak dekoratif ayrıntılar

Gerçeklik, Ev ve Okul'da görsel-only PBR silindir donanım eklendi; bulmaca ve etkileşim çarpışmaları korunur. Gerçek Godot motoru olmadan görsel/FPS doğrulanmadı.

## v0.1.32 — F3 kalite optimizasyonu

F3 LOW: Gerçeklik, Ev ve Okul'un büyük yüzeylerinde daha az doku örneklemeli standart UV PBR; MEDIUM/HIGH: dünya ölçekli triplanar PBR. Kayıtlar, fizik ve bulmacalar değişmedi. Motor/FPS doğrulaması bekliyor.

# Dream Layers — First Awakening / İlk Uyanış

**14 Ekim 2026 | kaynak prototip v0.1.37 | Unreal Engine gerekmez**

Bu klasör **Godot 4.3+** ile açılmak üzere yazılmış özgün bir Windows/PC oyun başlangıcıdır. Kullanıcının paylaştığı belgeler (Dream Layers eski JS referans sürümü 0.9.1, native C++ kaynak sürümü 0.3.1) esas alınarak *oyun fikirleri* uyarlanmıştır. Bunlar oyunun tam kaynaklarının yerine geçmez. Buradaki sayısal bulmaca çözümleri ve oda geometrisi **ilk prototip tasarımlarıdır; eski oyunla tam davranış eşliği iddia edilmez**.

## İlk prototipin kapsamı

- Basit prosedürel 3D oda geometrisi: **Gerçeklik, Ev ve Okul**.
- Birinci şahıs yürüme, fareyle bakma, koşma, fizik tabanlı çarpışma.
- TR/EN prolog, TR/EN etkileşim metinleri; F2 ile dil değiştirme.
- Yatakla **12 saniyelik giriş beklemesi**, ardından Ev'e geçiş (tam kamera animasyonu yok). Dalışın erken/doğrudan tamamlanması reddedilir; doğrudan başlangıç da yalnızca Gerçeklikte, odaklı ve modal yokken mümkündür. Aktif dalış yeniden başlatılarak sayaç sıfırlanamaz (motor kabulü bekler).
- Evde not ve üç anahtarlı sigorta; Okulda dört rakamı kendin girdiğin dolap, arşiv ve dört işaretli mühür.
- Bulmaca modalını açan doğrudan/gecikmiş çağrılar da oda, pencere odağı ve mevcut modal bağlamından geçer; başka bir pencereyi değiştirmez (gerçek motor kabulü bekler).
- Mühürden sonra Ev'deki çan ile Gerçekliğe dönüş ve demo bitişi.
- 90 saniyede bir değişen altı görsel zaman varyantı. Bu prototip **yalnızca yerel slot 0**'ı gösterir.
- Denge/yanlış cevap cezası, süre, çöküş sonrası süre uzatımı ve FPS göstergesi. Pencere odağı kaybolduğunda oyun süresi durur; hareket ve oyun kısayolları geçici olarak devre dışı kalır. Odak kaybı veya modal pencere sırasında karakterin fiziksel sürüklenmesi de kaynak düzeyinde engellenir (motor kabulü bekler).
- F5 ile yerel kontrol noktası kaydetme, F9 ile yükleme (şema ve ilerleme doğrulaması, yedekli yazma). Kodlama/boyut kontrolü geçmeden geçici kayıt WRITE modunda açılmaz. Arka plan penceresinde doğrudan etkileşim, modal callback, F5 kayıt ve F9 yükleme çağrıları reddedilir; açık diyalog ve oyun durumu korunur. Motor smoke dosyasında izole kullanıcı klasöründe gerçek F5/F9 disk geri yükleme senaryosu yazıldı, ancak motor olmadan çalıştırılmadı.
- F3 ile üç grafik kalite kademesi. Bu ayarlar **gerçek GPU performans kabulü değildir**.

### Oynanış

1. Godot 4.3+ uygulamasında `project.godot` dosyasını içe aktar ve **F6/F5** ile ana sahneyi çalıştır.
2. Prolog penceresinde **Rüyayı başlat** düğmesine tıkla veya odaklanmış düğmede **Enter** kullan.
3. **WASD** yürür, **fare** bakar, **Shift** koşar. Ekranın ortasını objeye çevirip **E** ile etkileş.
4. Gerçeklikte yatağa yaklaş, **E**'ye bas. 12 saniyenin sonunda Ev'e geç.
5. Evde eski defteri bul; sigorta panelini çöz ve Okul kapısından geç.
6. Okulda dolap, arşiv ve mühürü çöz. Dolap kodunu yazıp **Enter** ile gönderebilirsin; diğer pencerelerde ilk düğme klavye odağı alır. Not ve bulmaca pencerelerini **Esc** ile kapatabilirsin. Eve dön, çanı çal ve bitişi gör.
7. **F2** dil, **F3** kalite, **F5** kayıt, **F9** yükleme, **Esc** açık not/bulmaca penceresini kapatma veya fare yakalama/bırakma. **R**, sürmekte olan dalışı iptal eder.

### Bilinen kısıtlar

- Bu pakette `.exe` yoktur. Windows çıktısı için **Godot export templates** ve Windows export ayarı gerekir. `project.godot` editörde çalıştırılabilir kaynak prototipidir.
- Bu ortamda Godot çalıştırılabilir dosyası bulunmadığı için **GDScript editör derlemesi, görsel test, gerçek FPS, Windows paketleme ve multiplayer testi yapılamadı**. `tests/check_project.py` ve `tests/test_*contract.py` yalnızca dosya ve kaynak sözleşmelerini denetler; oyun motorunda çalıştırma yerine geçmez. `tests/run_godot_smoke.py` gerçek Godot kurulu olduğunda motor import ve durum-akışı smoke testi çalıştırır; bu ortamda çalıştırılamadı.
- Üç odada 512px özgün prosedürel PBR albedo/normal/roughness yüzeyleri, ACES/Forward+ ve 3 kalite kademesi v0.1.30 ile eklendi. Ancak modeller hâlâ low-poly yer tutucudur; gerçek fotogrametri, 8K, LOD/occlusion, profesyonel animasyon ve ses bankası henüz üretilmedi. `docs/VISUAL-QUALITY-TR.md` belgesine bakın.
- Multiplayer, ağ güvenliği, sahipli RPC, 6 farklı gerçek oyuncu, save/load motor kabulü, erişilebilirlik testi ve orijinal puzzle/oracle eşliği henüz yoktur.
- Steam/Epic ürün veya demo sayfası oluşturulmadı, yayın hesabı bağlanmadı ve herhangi bir mağazaya içerik gönderilmedi.

## Geliştirme disiplinleri

Sürümün kullanıcıların satın alabileceği bir PC oyununa dönüşmesi için öncelikle Godot editörünü kullanarak çalışır oyun döngüsünü, karakter çarpışmasını, sahne yüklemesini ve UI etkileşimlerini kabul etmeliyiz. Daha sonra orijinal `ReferenceSource` ve native C++ çekirdeğiyle test fikstürleri taşınmalı; sahne varlıkları uygun kaynak/lisanslarla üretilebilir. Gerçek GPU'da frametime p50/p95, VRAM, GPU/CPU darboğazı ve kalite kademe testleri yapılmalıdır.

Detaylı yol haritası `docs/ROADMAP-TR.md` ve test sınırları `docs/TEST-REPORT-TR.md` içinde.

## v0.1.1 değişiklikleri (13 Ekim 2026)

- Okul dolabı artık doğru kodu seçeneklerde göstermez; oyuncu dört rakamı kendisi yazar.
- Boş/bozuk kod cezasız reddedilir; yanlış ama biçimi geçerli kod dengeyi 9 düşürür.
- Yatak gibi büyük objelerde etkileşim mesafesi merkezden değil ışının çarptığı noktadan ölçülür.
- Demo tamamlandıktan sonra hareketin yanlışlıkla tekrar açılması engellendi.
- Kaynak düzeyinde 9 ek regresyon kontrolü eklendi; Godot runtime testi henüz yapılmadı.

## v0.1.2 değişiklikleri (13 Ekim 2026)

- Etkileşimler tek bir `ACTION_LAYERS` tablosuyla ilgili Gerçeklik/Ev/Okul katmanına sınırlandı.
- Dalış sırasında, modal açıkken ve demo bittikten sonra gelen etkileşim istekleri reddedilir.
- Eski veya yinelenen bulmaca UI callback'leri, çözülmüş mekanizmalar ve geçersiz buton indeksleri korunur.
- `tests/test_action_gate_contract.py` ile 7 yeni **statik** kontrol (toplam 16); `tests/run_godot_smoke.py` ve `tests/godot_flow_smoke.gd` ile motor mevcut olduğunda import ve oyun durum-akışı smoke testi için çalıştırıcı eklendi.
- **Gerçek Godot motoru bu ortamda yoktur**: headless import/parse, UI, fizik ve GPU/FPS henüz doğrulanmadı. Komut: `python3 tests/run_godot_smoke.py --require-engine`.

## v0.1.3 değişiklikleri (13 Ekim 2026)

- Başka bir açık pencereden gelen sigorta/mühür/dolap callback'leri artık işlenmez; her puzzle girdisi aktif diyalog bağlamına bağlıdır.
- Modal düğmeleri açılış nesliyle etiketlenir; eski düğme sinyalleri yeni pencerede geçersizdir.
- `python3 tests/verify_manifest.py` ile paket dosya listesi ve SHA-256 bütünlüğü denetlenebilir.
- Statik regresyonlar **20/20 geçti**; gerçek Godot import/oyun akışı, Windows `.exe` ve GPU/FPS hâlâ **yapılmadı**.

## v0.1.5 değişiklikleri (13 Ekim 2026)

- `scripts/save_codec.gd`: yerel tek oyuncu kontrol noktası şeması; katman, ilerleme, sayaç, sigorta/mühür ve kalite verilerinin tür/aralık/tutarlılık doğrulaması.
- `scripts/main.gd`: F5 kayıt / F9 yükleme, geçici dosyaya yazma, önceki kaydı `.bak.json` olarak koruma, bozuk ana kayıtta yedeğe dönme; yüklemeden önce doğrulama. Konum tam olarak saklanmaz: oda girişine yerleştirilir.
- `tests/test_save_contract.py`: 8 yeni **statik** sözleşme kontrolü; `tests/godot_flow_smoke.gd`: motor mevcut olduğunda 5 codec senaryosu.
- **Motor testi hâlâ yoktur.** Godot 4.3+ ile JSON dosya okuma/yazma, yükleme sonrası sahne durumu, yedekten kurtarma ve Windows davranışı ayrıca doğrulanmalıdır.

## v0.1.6 — Kesintiye dayanıklı checkpoint döndürme

Geçerli ana kayıt yeni bir kayda yer açarken önce `.rollback` konumuna alınır. Yeni ana kayıt diskte tekrar doğrulanmadan önceki `.bak.json` silinmez. İşlem yarıda kalırsa F9 sırasıyla ana kayıt, kesintiye uğramış `.rollback`, eski `.bak.json` dosyasını dener. Gerçek Godot/Windows dosya sistemi kabulü beklenir.


## v0.1.7 — Kontrol noktası checksum'ı

Yeni F5 kayıtları, iç JSON metninin SHA-256 özetiyle doğrulanan bir zarf kullanır. Böylece geçerli görünümlü ama yanlışlıkla değişmiş kayıt içeriği F9 sırasında reddedilir ve mevcut `.rollback` / `.bak` kurtarma akışı denenir. Eski v0.1.4–v0.1.6 JSON checkpoint dosyaları okunmaya devam eder. **SHA-256 bir güvenlik imzası değildir;** dosyayı değiştirebilen kişi checksum'ı da yeniden hesaplayabilir. Yeni motor testleri kaynakta vardır ancak Godot bulunmadığından henüz çalıştırılmadı.


## v0.1.8 — Motor smoke güvenilirliği

- `tests/run_godot_smoke.py` artık Godot 4.3+ sürümünü kontrol eder ve motor smoke'unun **pozitif kontrol sayısı / sıfır hata** kapanış satırını zorunlu tutar. Sadece sıfır çıkış kodu, başarılı oyun testi sayılmaz.
- Headless testler geçici kullanıcı veri dizinleriyle çalıştırılır; normal kayıt dizinlerini korumak hedeflenir. Windows'ta kullanıcı dizini yönlendirmesi gerçek Godot ile ayrıca doğrulanmalıdır.
- `tests/godot_flow_smoke.gd` içinde dinamik sahne script özellikleri için Node yerine Variant çağrı kullanılır.
- `tests/test_engine_runner.py` Python runner davranışını sınar; **Godot motorunu taklit ederek oynanabilirlik kanıtı üretmez**.


## v0.1.9 — Etkileşim ışını ve HUD güncelleme

- Oyuncu kapsülünü, kamera altındaki RayCast3D ışınından `ray.add_exception(self)` ile açıkça hariç tut. Böylece kendi fizik gövdesinin etkileşimleri engelleme riski azaltılır.
- HUD istatistik, etkileşim ipucu ve nişangâh görünürlüğü yalnızca değer değiştiğinde güncellenir. Gereksiz Control özellik yazmaları azaltılır; gerçek FPS farkı henüz ölçülmedi.
- Üç yeni Python kaynak sözleşmesi testi ve Godot smoke betiğine kapsülün içinden kısa ışınla öz-kesişim kontrolü eklendi. Godot motoru mevcut olmadığından fiziksel raycast ve UI performansı **henüz doğrulanmadı**.


## v0.1.10 — Klavye ile bulmaca etkileşimi (14 Ekim 2026)

- Diyalog açılınca ilk düğme odaklanır; klavyeden Enter/Space ile etkinleştirilebilir.
- Dolap penceresinde ilk düğme yerine kod giriş alanı odaklanır; kod **Enter** ile gönderilir.
- Enter, mevcut nesil kontrollü `_choose()` yolunu kullanır; kapanmış pencereyi yeniden işleme veya çift ödül üretme engellenir.
- Dört yeni Python statik regresyon testi ve Godot smoke'a klavye odak/Enter senaryoları eklendi. **Godot motoru bulunmadığından gerçek UI davranışı henüz doğrulanmadı.**


## v0.1.11 — Esc ile güvenli diyalog kapatma (14 Ekim 2026)

- Açıkça **Kapat** seçeneği bulunan not, sigorta, dolap ve mühür pencereleri artık **Esc** ile kapanabilir. Prolog ve bitiş pencerelerindeki zorunlu onay Esc ile atlanmaz.
- Esc, `_choose("close", dialog_generation)` üzerinden işlendiği için eski pencere callback korumaları korunur; kapanan dolap penceresindeki Enter kodu çalıştırılmaz.
- Dört yeni Python **statik** regresyon testi ve Godot smoke için iptal/sonradan gelen girdi senaryoları eklendi. **Godot motoru mevcut olmadığından gerçek klavye UI testi yapılmadı.**


## v0.1.12 — Kayıt ilerleme tutarlılığı (14 Ekim 2026)

- Henüz yatağa girilmemiş kayıtlar, başlangıç sigorta/mühür değerleri dışında bir bulmaca durumu taşıyamaz.
- Arşiv alınmadan mühür sembolleri değiştirilmiş görünen kayıtlar reddedilir. Böylece elle düzenlenmiş veya bozulmuş ama geçerli JSON kayıtlarının olanaksız kısmi ilerleme yüklemesi azaltılır.
- Dört yeni **statik** test ve gelecekte gerçek Godot ile çalıştırılacak üç negatif smoke senaryosu eklendi. Motor olmadığı için oyun içinde test edilmedi.


## v0.1.13 — Üç boyutlu etkileşim erişimi (14 Ekim 2026)

- `scripts/player.gd`: özel erişim mesafesi artık oyuncunun ayaklarından yatay X/Z uzaklığına göre değil, kameradaki ışın başlangıcından **ışının çarptığı noktaya gerçek 3D mesafeyle** hesaplanır. Bu, yukarıda/aşağıda bulunan hedeflerin erişim sınırını aşmasını önler.
- Negatif erişim sınırları reddedilir; yakındaki geçerli hedefler korunur. `tests/test_reach_3d_contract.py` dört yeni **statik** test, `tests/godot_flow_smoke.gd` üç **henüz çalıştırılmamış motor** sınaması içerir.
- Godot 4.3+ çalıştırıcısı bu ortamda yok: gerçek fizik, kamera/raycast, oyun akışı, Windows `.exe` ve FPS **doğrulanmadı**.

## v0.1.14 — Arka planda zamanın durması (14 Ekim 2026)

- Oyun penceresi odağı kaybettiğinde 15 dakikalık rüya süresi artık ilerlemez. Oyun tuşları ve karakter hareketi devre dışı kalır; odak geri geldiğinde devam eder. Bu **uygulama odak bildirimi** çözümüdür, işletim sistemi Alt+Tab testi henüz yapılmadı.
- `tests/test_focus_pause_contract.py` dört statik test ve `tests/godot_flow_smoke.gd` beş motor kontrolü içerir. Gerçek motor henüz çalıştırılamadı.
- v0.1.16 ile 12 saniyelik yatak dalışı da odak kaybında duraklar; arka planda Ev'e geçiş gerçekleşmez. R ile iptal edilebilir; gerçek Windows Alt+Tab kabulü bekler.

## v0.1.15 — Fiziksel hareket dondurma (14 Ekim 2026)

- `DreamPlayer._physics_process` artık `can_move` kapalıyken tüm hızı sıfırlayıp hareket/fizik adımını atlar. Bu; odak kaybı, modal pencere, geçiş ve bitişte yerçekimi veya önceki hız nedeniyle sürüklenmeyi önlemeye yöneliktir.
- Dört yeni **statik** regresyon testi ve dört **henüz çalıştırılmamış Godot motor** kontrolü eklendi. Gerçek Windows Alt+Tab ve Godot fizik davranışı henüz doğrulanmadı.

### v0.1.16 — Yatak dalışının arka planda duraklatılması

- Yatağa E ile etkileşim sonrası 12 saniyelik dalış, yalnızca oyun penceresi odaktayken ilerler. Alt+Tab ile başka pencereye geçildiğinde dalış durur, dönüşte kaldığı yerden sürer.
- Dalış sırasında **R** iptal eder; eski iptal edilmiş dalışın gecikmiş tamamlaması yeni dalışı etkilemez. Dalış bitiş karesi 15 dakikalık oyun süresinden düşülmez.
- 6 yeni Python **statik** regresyon testi ve 8 yeni **henüz çalıştırılmamış Godot motor** kontrolü. Gerçek Windows odağı, GDScript import/parse, GPU/FPS, Windows EXE hâlâ doğrulanmadı.

## v0.1.17 — Odak dönüşünde zamanlama koruması

- Pencere başka uygulamadan geri geldiğinde ilk `_process` karesinin büyük zaman farkı yok sayılır; dalış ve rüya sayacı sonraki odaklı karelerde normal devam eder. Gerçek Windows Alt+Tab davranışı Godot 4.3+ üzerinde henüz doğrulanmadı.
- 4 yeni Python **statik** test ve 2 yeni **motor bekleyen** smoke kontrolü. Windows EXE, GPU/FPS ve oynanabilirlik kabulü yapılmadı.


## v0.1.19 — Zorunlu onay pencerelerinde kapatma koruması

- `scripts/main.gd` artık doğrudan veya gecikmiş `close` callback'ini yalnızca açık diyalog **Kapat** seçeneği sunuyorsa kabul eder. Prolog ve bitiş onayları bu yolla atlanamaz.
- `tests/test_modal_close_contract.py`: 4 yeni Python statik kontrol; `tests/godot_flow_smoke.gd`: prolog ve bitişte doğrudan kapatma reddi için 2 motor senaryosu.
- Python statik kontrolleri Godot motorunda davranış kanıtı değildir; gerçek import/parse, UI, Windows ve FPS testi bekliyor.

## v0.1.20 — Arka plan etkileşim yetkilendirmesi (14 Ekim 2026)

- `_can_interact` ve `_choice` artık sadece klavye kapısından değil, doğrudan kod çağrılarında da uygulama odağını denetler. Arka plandaki pencere prologu, yatağı veya açık bulmacayı değiştiremez.
- Başarılı F9 yüklemesinden sonra `player.can_move` odağı dikkate alır; arka planda doğrudan yükleme hareketi açmaz.
- Dört yeni **statik** Python testi ve üç **henüz motor çalıştırılmamış** smoke kontrolü eklendi. Gerçek Godot/Windows odağı, FPS ve kayıt I/O kabulü bekliyor.

## v0.1.25 — Bitiş güvenliği

- Ev'deki çanla demo bitişi yalnızca mühür çözülmüşse ve oyun odaklı/etkileşime açık durumdaysa çalışır. Doğrudan `_wake()` çağrısı da bu koşulları atlayamaz. Dört yeni statik test ve üç motor bekleyen kontrol eklendi; gerçek Godot kabulü henüz yapılmadı.

### v0.1.26 kaynak güncellemesi

`_fold()` artık doğrudan çağrıldığında da yalnızca aktif, odaklı ve gerçekten tükenmiş rüya durumunda çalışır; prolog, modal, arka plan, sağlıklı rüya ve bitiş sonrası erken çöküşü engeller. Bu **kaynak düzeyi** değişikliktir: Godot 4.3+ motor kabulü ve Windows oynanabilirlik testi henüz yapılmadı.

### v0.1.27 kaynak güncellemesi

Yanlış cevap cezası, yalnızca doğru odadaki açık ve çözülmemiş bulmaca bağlamında uygulanır. Doğrudan/gecikmiş çağrılar prolog, not, arka plan veya oyun bitişi sonrasında dengeyi düşüremez. Normal yanlış cevap -9 korunur. Godot 4.3+ motor testi hâlâ bekliyor.

### v0.1.29 — Kayıt yükleme sonrası bulmaca tür güvenliği

F9/JSON kayıt çözümünden sonra sigorta ve mühür dizileri doğrulanmış tamsayı değerler içerir; sigorta/mühür döngü düğmeleri Godot `%` işlemi için tamsayı öğeler alır. Kaydedilmiş eski v1 dosyalarına uyumluluk korunur. Dört yeni statik test ve Godot motoru bekleyen dört kontrol eklendi. Gerçek motor/Windows testi hâlâ yapılmadı.

**v0.1.31:** Büyük oda yüzeylerinde dünya ölçekli triplanar UV; küçük mobilyalarda standart UV. Godot/GPU doğrulaması bekler.
